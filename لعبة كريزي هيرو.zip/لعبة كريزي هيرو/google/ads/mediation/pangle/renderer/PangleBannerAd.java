package com.google.ads.mediation.pangle.renderer;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;
import com.bytedance.sdk.openadsdk.api.banner.PAGBannerAd;
import com.bytedance.sdk.openadsdk.api.banner.PAGBannerAdInteractionListener;
import com.bytedance.sdk.openadsdk.api.banner.PAGBannerAdLoadListener;
import com.bytedance.sdk.openadsdk.api.banner.PAGBannerRequest;
import com.bytedance.sdk.openadsdk.api.banner.PAGBannerSize;
import com.google.ads.mediation.pangle.PangleConstants;
import com.google.ads.mediation.pangle.PangleInitializer;
import com.google.ads.mediation.pangle.PangleMediationAdapter;
import com.google.ads.mediation.pangle.PanglePrivacyConfig;
import com.google.ads.mediation.pangle.PangleSdkWrapper;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.MediationUtils;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationBannerAd;
import com.google.android.gms.ads.mediation.MediationBannerAdCallback;
import com.google.android.gms.ads.mediation.MediationBannerAdConfiguration;
import java.util.ArrayList;

public class PangleBannerAd implements MediationBannerAd, PAGBannerAdInteractionListener {
    @VisibleForTesting
    public static final String ERROR_MESSAGE_BANNER_SIZE_MISMATCH = "Failed to request banner ad from Pangle. Invalid banner size.";
    /* access modifiers changed from: private */
    public final MediationBannerAdConfiguration adConfiguration;
    /* access modifiers changed from: private */
    public final MediationAdLoadCallback<MediationBannerAd, MediationBannerAdCallback> adLoadCallback;
    /* access modifiers changed from: private */
    public MediationBannerAdCallback bannerAdCallback;
    private final PangleInitializer pangleInitializer;
    private final PanglePrivacyConfig panglePrivacyConfig;
    /* access modifiers changed from: private */
    public final PangleSdkWrapper pangleSdkWrapper;
    /* access modifiers changed from: private */
    public FrameLayout wrappedAdView;

    public class a implements PangleInitializer.Listener {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ Context f13408a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ String f13409b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ String f13410c;

        /* renamed from: com.google.ads.mediation.pangle.renderer.PangleBannerAd$a$a  reason: collision with other inner class name */
        public class C0207a implements PAGBannerAdLoadListener {
            public C0207a() {
            }

            public void onAdLoaded(Object obj) {
                PAGBannerAd pAGBannerAd = (PAGBannerAd) obj;
                pAGBannerAd.setAdInteractionListener(PangleBannerAd.this);
                PangleBannerAd.this.wrappedAdView.addView(pAGBannerAd.getBannerView());
                PangleBannerAd pangleBannerAd = PangleBannerAd.this;
                MediationBannerAdCallback unused = pangleBannerAd.bannerAdCallback = (MediationBannerAdCallback) pangleBannerAd.adLoadCallback.onSuccess(PangleBannerAd.this);
            }

            public void onError(int i10, String str) {
                AdError createSdkError = PangleConstants.createSdkError(i10, str);
                Log.w(PangleMediationAdapter.TAG, createSdkError.toString());
                PangleBannerAd.this.adLoadCallback.onFailure(createSdkError);
            }
        }

        public a(Context context, String str, String str2) {
            this.f13408a = context;
            this.f13409b = str;
            this.f13410c = str2;
        }

        public void onInitializeError(@NonNull AdError adError) {
            Log.w(PangleMediationAdapter.TAG, adError.toString());
            PangleBannerAd.this.adLoadCallback.onFailure(adError);
        }

        public void onInitializeSuccess() {
            ArrayList arrayList = new ArrayList(3);
            arrayList.add(new AdSize(320, 50));
            arrayList.add(new AdSize(300, 250));
            arrayList.add(new AdSize(728, 90));
            AdSize findClosestSize = MediationUtils.findClosestSize(this.f13408a, PangleBannerAd.this.adConfiguration.getAdSize(), arrayList);
            if (findClosestSize == null) {
                AdError createAdapterError = PangleConstants.createAdapterError(102, PangleBannerAd.ERROR_MESSAGE_BANNER_SIZE_MISMATCH);
                Log.w(PangleMediationAdapter.TAG, createAdapterError.toString());
                PangleBannerAd.this.adLoadCallback.onFailure(createAdapterError);
                return;
            }
            FrameLayout unused = PangleBannerAd.this.wrappedAdView = new FrameLayout(this.f13408a);
            PAGBannerRequest pAGBannerRequest = new PAGBannerRequest(new PAGBannerSize(findClosestSize.getWidth(), findClosestSize.getHeight()));
            pAGBannerRequest.setAdString(this.f13409b);
            PangleBannerAd.this.pangleSdkWrapper.loadBannerAd(this.f13410c, pAGBannerRequest, new C0207a());
        }
    }

    public PangleBannerAd(@NonNull MediationBannerAdConfiguration mediationBannerAdConfiguration, @NonNull MediationAdLoadCallback<MediationBannerAd, MediationBannerAdCallback> mediationAdLoadCallback, @NonNull PangleInitializer pangleInitializer2, @NonNull PangleSdkWrapper pangleSdkWrapper2, PanglePrivacyConfig panglePrivacyConfig2) {
        this.adConfiguration = mediationBannerAdConfiguration;
        this.adLoadCallback = mediationAdLoadCallback;
        this.pangleInitializer = pangleInitializer2;
        this.pangleSdkWrapper = pangleSdkWrapper2;
        this.panglePrivacyConfig = panglePrivacyConfig2;
    }

    @NonNull
    public View getView() {
        return this.wrappedAdView;
    }

    public void onAdClicked() {
        MediationBannerAdCallback mediationBannerAdCallback = this.bannerAdCallback;
        if (mediationBannerAdCallback != null) {
            mediationBannerAdCallback.reportAdClicked();
        }
    }

    public void onAdDismissed() {
    }

    public void onAdShowed() {
        MediationBannerAdCallback mediationBannerAdCallback = this.bannerAdCallback;
        if (mediationBannerAdCallback != null) {
            mediationBannerAdCallback.reportAdImpression();
        }
    }

    public void render() {
        this.panglePrivacyConfig.setCoppa(this.adConfiguration.taggedForChildDirectedTreatment());
        Bundle serverParameters = this.adConfiguration.getServerParameters();
        String string = serverParameters.getString(PangleConstants.PLACEMENT_ID);
        if (TextUtils.isEmpty(string)) {
            AdError createAdapterError = PangleConstants.createAdapterError(101, "Failed to load banner ad from Pangle. Missing or invalid Placement ID.");
            Log.e(PangleMediationAdapter.TAG, createAdapterError.toString());
            this.adLoadCallback.onFailure(createAdapterError);
            return;
        }
        String bidResponse = this.adConfiguration.getBidResponse();
        Context context = this.adConfiguration.getContext();
        this.pangleInitializer.initialize(context, serverParameters.getString("appid"), new a(context, bidResponse, string));
    }
}
