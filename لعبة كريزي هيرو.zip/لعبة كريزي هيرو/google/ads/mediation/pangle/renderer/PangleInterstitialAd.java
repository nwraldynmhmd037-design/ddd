package com.google.ads.mediation.pangle.renderer;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.NonNull;
import com.bytedance.sdk.openadsdk.api.interstitial.PAGInterstitialAd;
import com.bytedance.sdk.openadsdk.api.interstitial.PAGInterstitialAdInteractionListener;
import com.bytedance.sdk.openadsdk.api.interstitial.PAGInterstitialAdLoadListener;
import com.bytedance.sdk.openadsdk.api.interstitial.PAGInterstitialRequest;
import com.google.ads.mediation.pangle.PangleConstants;
import com.google.ads.mediation.pangle.PangleInitializer;
import com.google.ads.mediation.pangle.PangleMediationAdapter;
import com.google.ads.mediation.pangle.PanglePrivacyConfig;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationInterstitialAd;
import com.google.android.gms.ads.mediation.MediationInterstitialAdCallback;
import com.google.android.gms.ads.mediation.MediationInterstitialAdConfiguration;

public class PangleInterstitialAd implements MediationInterstitialAd {
    private final MediationInterstitialAdConfiguration adConfiguration;
    /* access modifiers changed from: private */
    public final MediationAdLoadCallback<MediationInterstitialAd, MediationInterstitialAdCallback> adLoadCallback;
    /* access modifiers changed from: private */
    public MediationInterstitialAdCallback interstitialAdCallback;
    /* access modifiers changed from: private */
    public PAGInterstitialAd pagInterstitialAd;
    private final PanglePrivacyConfig panglePrivacyConfig;

    public class a implements PangleInitializer.Listener {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ String f13413a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ String f13414b;

        /* renamed from: com.google.ads.mediation.pangle.renderer.PangleInterstitialAd$a$a  reason: collision with other inner class name */
        public class C0208a implements PAGInterstitialAdLoadListener {
            public C0208a() {
            }

            public void onAdLoaded(Object obj) {
                PangleInterstitialAd pangleInterstitialAd = PangleInterstitialAd.this;
                MediationInterstitialAdCallback unused = pangleInterstitialAd.interstitialAdCallback = (MediationInterstitialAdCallback) pangleInterstitialAd.adLoadCallback.onSuccess(PangleInterstitialAd.this);
                PAGInterstitialAd unused2 = PangleInterstitialAd.this.pagInterstitialAd = (PAGInterstitialAd) obj;
            }

            public void onError(int i10, String str) {
                AdError createSdkError = PangleConstants.createSdkError(i10, str);
                Log.w(PangleMediationAdapter.TAG, createSdkError.toString());
                PangleInterstitialAd.this.adLoadCallback.onFailure(createSdkError);
            }
        }

        public a(String str, String str2) {
            this.f13413a = str;
            this.f13414b = str2;
        }

        public void onInitializeError(@NonNull AdError adError) {
            Log.w(PangleMediationAdapter.TAG, adError.toString());
            PangleInterstitialAd.this.adLoadCallback.onFailure(adError);
        }

        public void onInitializeSuccess() {
            PAGInterstitialRequest pAGInterstitialRequest = new PAGInterstitialRequest();
            pAGInterstitialRequest.setAdString(this.f13413a);
            PAGInterstitialAd.loadAd(this.f13414b, pAGInterstitialRequest, (PAGInterstitialAdLoadListener) new C0208a());
        }
    }

    public class b implements PAGInterstitialAdInteractionListener {
        public b() {
        }

        public void onAdClicked() {
            if (PangleInterstitialAd.this.interstitialAdCallback != null) {
                PangleInterstitialAd.this.interstitialAdCallback.reportAdClicked();
            }
        }

        public void onAdDismissed() {
            if (PangleInterstitialAd.this.interstitialAdCallback != null) {
                PangleInterstitialAd.this.interstitialAdCallback.onAdClosed();
            }
        }

        public void onAdShowed() {
            if (PangleInterstitialAd.this.interstitialAdCallback != null) {
                PangleInterstitialAd.this.interstitialAdCallback.onAdOpened();
                PangleInterstitialAd.this.interstitialAdCallback.reportAdImpression();
            }
        }
    }

    public PangleInterstitialAd(@NonNull MediationInterstitialAdConfiguration mediationInterstitialAdConfiguration, @NonNull MediationAdLoadCallback<MediationInterstitialAd, MediationInterstitialAdCallback> mediationAdLoadCallback, PanglePrivacyConfig panglePrivacyConfig2) {
        this.adConfiguration = mediationInterstitialAdConfiguration;
        this.adLoadCallback = mediationAdLoadCallback;
        this.panglePrivacyConfig = panglePrivacyConfig2;
    }

    public void render() {
        this.panglePrivacyConfig.setCoppa(this.adConfiguration.taggedForChildDirectedTreatment());
        Bundle serverParameters = this.adConfiguration.getServerParameters();
        String string = serverParameters.getString(PangleConstants.PLACEMENT_ID);
        if (TextUtils.isEmpty(string)) {
            AdError createAdapterError = PangleConstants.createAdapterError(101, "Failed to load interstitial ad from Pangle. Missing or invalid Placement ID.");
            Log.e(PangleMediationAdapter.TAG, createAdapterError.toString());
            this.adLoadCallback.onFailure(createAdapterError);
            return;
        }
        String bidResponse = this.adConfiguration.getBidResponse();
        PangleInitializer.getInstance().initialize(this.adConfiguration.getContext(), serverParameters.getString("appid"), new a(bidResponse, string));
    }

    public void showAd(@NonNull Context context) {
        this.pagInterstitialAd.setAdInteractionListener(new b());
        if (context instanceof Activity) {
            this.pagInterstitialAd.show((Activity) context);
        } else {
            this.pagInterstitialAd.show((Activity) null);
        }
    }
}
