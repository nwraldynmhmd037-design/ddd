package com.google.ads.mediation.pangle.renderer;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.NonNull;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardItem;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedAd;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedAdInteractionListener;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedAdLoadListener;
import com.bytedance.sdk.openadsdk.api.reward.PAGRewardedRequest;
import com.google.ads.mediation.pangle.PangleConstants;
import com.google.ads.mediation.pangle.PangleInitializer;
import com.google.ads.mediation.pangle.PangleMediationAdapter;
import com.google.ads.mediation.pangle.PanglePrivacyConfig;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationRewardedAd;
import com.google.android.gms.ads.mediation.MediationRewardedAdCallback;
import com.google.android.gms.ads.mediation.MediationRewardedAdConfiguration;
import com.google.android.gms.ads.rewarded.RewardItem;

public class PangleRewardedAd implements MediationRewardedAd {
    private final MediationRewardedAdConfiguration adConfiguration;
    /* access modifiers changed from: private */
    public final MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback> adLoadCallback;
    /* access modifiers changed from: private */
    public PAGRewardedAd pagRewardedAd;
    private final PanglePrivacyConfig panglePrivacyConfig;
    /* access modifiers changed from: private */
    public MediationRewardedAdCallback rewardedAdCallback;

    public class a implements PangleInitializer.Listener {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ String f13424a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ String f13425b;

        /* renamed from: com.google.ads.mediation.pangle.renderer.PangleRewardedAd$a$a  reason: collision with other inner class name */
        public class C0210a implements PAGRewardedAdLoadListener {
            public C0210a() {
            }

            public void onAdLoaded(Object obj) {
                PangleRewardedAd pangleRewardedAd = PangleRewardedAd.this;
                MediationRewardedAdCallback unused = pangleRewardedAd.rewardedAdCallback = (MediationRewardedAdCallback) pangleRewardedAd.adLoadCallback.onSuccess(PangleRewardedAd.this);
                PAGRewardedAd unused2 = PangleRewardedAd.this.pagRewardedAd = (PAGRewardedAd) obj;
            }

            public void onError(int i10, String str) {
                AdError createSdkError = PangleConstants.createSdkError(i10, str);
                Log.w(PangleMediationAdapter.TAG, createSdkError.toString());
                PangleRewardedAd.this.adLoadCallback.onFailure(createSdkError);
            }
        }

        public a(String str, String str2) {
            this.f13424a = str;
            this.f13425b = str2;
        }

        public void onInitializeError(@NonNull AdError adError) {
            Log.w(PangleMediationAdapter.TAG, adError.toString());
            PangleRewardedAd.this.adLoadCallback.onFailure(adError);
        }

        public void onInitializeSuccess() {
            PAGRewardedRequest pAGRewardedRequest = new PAGRewardedRequest();
            pAGRewardedRequest.setAdString(this.f13424a);
            PAGRewardedAd.loadAd(this.f13425b, pAGRewardedRequest, (PAGRewardedAdLoadListener) new C0210a());
        }
    }

    public class b implements PAGRewardedAdInteractionListener {

        public class a implements RewardItem {

            /* renamed from: a  reason: collision with root package name */
            public final /* synthetic */ PAGRewardItem f13429a;

            public a(b bVar, PAGRewardItem pAGRewardItem) {
                this.f13429a = pAGRewardItem;
            }

            public int getAmount() {
                return this.f13429a.getRewardAmount();
            }

            @NonNull
            public String getType() {
                return this.f13429a.getRewardName();
            }
        }

        public b() {
        }

        public void onAdClicked() {
            if (PangleRewardedAd.this.rewardedAdCallback != null) {
                PangleRewardedAd.this.rewardedAdCallback.reportAdClicked();
            }
        }

        public void onAdDismissed() {
            if (PangleRewardedAd.this.rewardedAdCallback != null) {
                PangleRewardedAd.this.rewardedAdCallback.onAdClosed();
            }
        }

        public void onAdShowed() {
            if (PangleRewardedAd.this.rewardedAdCallback != null) {
                PangleRewardedAd.this.rewardedAdCallback.onAdOpened();
                PangleRewardedAd.this.rewardedAdCallback.reportAdImpression();
            }
        }

        public void onUserEarnedReward(PAGRewardItem pAGRewardItem) {
            a aVar = new a(this, pAGRewardItem);
            if (PangleRewardedAd.this.rewardedAdCallback != null) {
                PangleRewardedAd.this.rewardedAdCallback.onUserEarnedReward(aVar);
            }
        }

        public void onUserEarnedRewardFail(int i10, String str) {
            Log.d(PangleMediationAdapter.TAG, PangleConstants.createSdkError(i10, String.format("Failed to reward user: %s", new Object[]{str})).toString());
        }
    }

    public PangleRewardedAd(@NonNull MediationRewardedAdConfiguration mediationRewardedAdConfiguration, @NonNull MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback> mediationAdLoadCallback, PanglePrivacyConfig panglePrivacyConfig2) {
        this.adConfiguration = mediationRewardedAdConfiguration;
        this.adLoadCallback = mediationAdLoadCallback;
        this.panglePrivacyConfig = panglePrivacyConfig2;
    }

    public void render() {
        this.panglePrivacyConfig.setCoppa(this.adConfiguration.taggedForChildDirectedTreatment());
        Bundle serverParameters = this.adConfiguration.getServerParameters();
        String string = serverParameters.getString(PangleConstants.PLACEMENT_ID);
        if (TextUtils.isEmpty(string)) {
            AdError createAdapterError = PangleConstants.createAdapterError(101, "Failed to load rewarded ad from Pangle. Missing or invalid Placement ID.");
            Log.e(PangleMediationAdapter.TAG, createAdapterError.toString());
            this.adLoadCallback.onFailure(createAdapterError);
            return;
        }
        String bidResponse = this.adConfiguration.getBidResponse();
        PangleInitializer.getInstance().initialize(this.adConfiguration.getContext(), serverParameters.getString("appid"), new a(bidResponse, string));
    }

    public void showAd(@NonNull Context context) {
        this.pagRewardedAd.setAdInteractionListener(new b());
        if (context instanceof Activity) {
            this.pagRewardedAd.show((Activity) context);
        } else {
            this.pagRewardedAd.show((Activity) null);
        }
    }
}
