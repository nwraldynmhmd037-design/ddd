package com.google.ads.mediation.pangle.renderer;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.NonNull;
import com.bytedance.sdk.openadsdk.api.open.PAGAppOpenAd;
import com.bytedance.sdk.openadsdk.api.open.PAGAppOpenAdInteractionListener;
import com.bytedance.sdk.openadsdk.api.open.PAGAppOpenAdLoadListener;
import com.bytedance.sdk.openadsdk.api.open.PAGAppOpenRequest;
import com.google.ads.mediation.pangle.PangleConstants;
import com.google.ads.mediation.pangle.PangleInitializer;
import com.google.ads.mediation.pangle.PangleMediationAdapter;
import com.google.ads.mediation.pangle.PanglePrivacyConfig;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationAppOpenAd;
import com.google.android.gms.ads.mediation.MediationAppOpenAdCallback;
import com.google.android.gms.ads.mediation.MediationAppOpenAdConfiguration;

public class PangleAppOpenAd implements MediationAppOpenAd {
    private final MediationAppOpenAdConfiguration adConfiguration;
    /* access modifiers changed from: private */
    public final MediationAdLoadCallback<MediationAppOpenAd, MediationAppOpenAdCallback> adLoadCallback;
    /* access modifiers changed from: private */
    public MediationAppOpenAdCallback appOpenAdCallback;
    /* access modifiers changed from: private */
    public PAGAppOpenAd pagAppOpenAd;
    private final PanglePrivacyConfig panglePrivacyConfig;

    public class a implements PangleInitializer.Listener {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ String f13403a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ String f13404b;

        /* renamed from: com.google.ads.mediation.pangle.renderer.PangleAppOpenAd$a$a  reason: collision with other inner class name */
        public class C0206a implements PAGAppOpenAdLoadListener {
            public C0206a() {
            }

            public void onAdLoaded(Object obj) {
                PangleAppOpenAd pangleAppOpenAd = PangleAppOpenAd.this;
                MediationAppOpenAdCallback unused = pangleAppOpenAd.appOpenAdCallback = (MediationAppOpenAdCallback) pangleAppOpenAd.adLoadCallback.onSuccess(PangleAppOpenAd.this);
                PAGAppOpenAd unused2 = PangleAppOpenAd.this.pagAppOpenAd = (PAGAppOpenAd) obj;
            }

            public void onError(int i10, String str) {
                AdError createSdkError = PangleConstants.createSdkError(i10, str);
                Log.w(PangleMediationAdapter.TAG, createSdkError.toString());
                PangleAppOpenAd.this.adLoadCallback.onFailure(createSdkError);
            }
        }

        public a(String str, String str2) {
            this.f13403a = str;
            this.f13404b = str2;
        }

        public void onInitializeError(@NonNull AdError adError) {
            Log.w(PangleMediationAdapter.TAG, adError.toString());
            PangleAppOpenAd.this.adLoadCallback.onFailure(adError);
        }

        public void onInitializeSuccess() {
            PAGAppOpenRequest pAGAppOpenRequest = new PAGAppOpenRequest();
            pAGAppOpenRequest.setAdString(this.f13403a);
            PAGAppOpenAd.loadAd(this.f13404b, pAGAppOpenRequest, (PAGAppOpenAdLoadListener) new C0206a());
        }
    }

    public class b implements PAGAppOpenAdInteractionListener {
        public b() {
        }

        public void onAdClicked() {
            if (PangleAppOpenAd.this.appOpenAdCallback != null) {
                PangleAppOpenAd.this.appOpenAdCallback.reportAdClicked();
            }
        }

        public void onAdDismissed() {
            if (PangleAppOpenAd.this.appOpenAdCallback != null) {
                PangleAppOpenAd.this.appOpenAdCallback.onAdClosed();
            }
        }

        public void onAdShowed() {
            if (PangleAppOpenAd.this.appOpenAdCallback != null) {
                PangleAppOpenAd.this.appOpenAdCallback.onAdOpened();
                PangleAppOpenAd.this.appOpenAdCallback.reportAdImpression();
            }
        }
    }

    public PangleAppOpenAd(@NonNull MediationAppOpenAdConfiguration mediationAppOpenAdConfiguration, @NonNull MediationAdLoadCallback<MediationAppOpenAd, MediationAppOpenAdCallback> mediationAdLoadCallback, PanglePrivacyConfig panglePrivacyConfig2) {
        this.adConfiguration = mediationAppOpenAdConfiguration;
        this.adLoadCallback = mediationAdLoadCallback;
        this.panglePrivacyConfig = panglePrivacyConfig2;
    }

    public void render() {
        this.panglePrivacyConfig.setCoppa(this.adConfiguration.taggedForChildDirectedTreatment());
        Bundle serverParameters = this.adConfiguration.getServerParameters();
        String string = serverParameters.getString(PangleConstants.PLACEMENT_ID);
        if (TextUtils.isEmpty(string)) {
            AdError createAdapterError = PangleConstants.createAdapterError(101, "Failed to load app open ad from Pangle. Missing or invalid Placement ID.");
            Log.e(PangleMediationAdapter.TAG, createAdapterError.toString());
            this.adLoadCallback.onFailure(createAdapterError);
            return;
        }
        String bidResponse = this.adConfiguration.getBidResponse();
        PangleInitializer.getInstance().initialize(this.adConfiguration.getContext(), serverParameters.getString("appid"), new a(bidResponse, string));
    }

    public void showAd(@NonNull Context context) {
        this.pagAppOpenAd.setAdInteractionListener(new b());
        if (context instanceof Activity) {
            this.pagAppOpenAd.show((Activity) context);
        } else {
            this.pagAppOpenAd.show((Activity) null);
        }
    }
}
