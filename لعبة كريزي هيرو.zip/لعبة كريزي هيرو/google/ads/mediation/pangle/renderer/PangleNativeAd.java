package com.google.ads.mediation.pangle.renderer;

import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import com.bytedance.sdk.openadsdk.api.nativeAd.PAGNativeAd;
import com.bytedance.sdk.openadsdk.api.nativeAd.PAGNativeAdData;
import com.bytedance.sdk.openadsdk.api.nativeAd.PAGNativeAdInteractionListener;
import com.bytedance.sdk.openadsdk.api.nativeAd.PAGNativeAdLoadListener;
import com.bytedance.sdk.openadsdk.api.nativeAd.PAGNativeRequest;
import com.google.ads.mediation.pangle.PangleConstants;
import com.google.ads.mediation.pangle.PangleInitializer;
import com.google.ads.mediation.pangle.PangleMediationAdapter;
import com.google.ads.mediation.pangle.PanglePrivacyConfig;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.formats.NativeAd;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationNativeAdCallback;
import com.google.android.gms.ads.mediation.MediationNativeAdConfiguration;
import com.google.android.gms.ads.mediation.UnifiedNativeAdMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PangleNativeAd extends UnifiedNativeAdMapper {
    private static final double PANGLE_SDK_IMAGE_SCALE = 1.0d;
    private final MediationNativeAdConfiguration adConfiguration;
    /* access modifiers changed from: private */
    public final MediationAdLoadCallback<UnifiedNativeAdMapper, MediationNativeAdCallback> adLoadCallback;
    /* access modifiers changed from: private */
    public MediationNativeAdCallback callback;
    /* access modifiers changed from: private */
    public PAGNativeAd pagNativeAd;
    private final PanglePrivacyConfig panglePrivacyConfig;

    public class PangleNativeMappedImage extends NativeAd.Image {
        private final Drawable drawable;
        private final Uri imageUri;
        private final double scale;

        public /* synthetic */ PangleNativeMappedImage(PangleNativeAd pangleNativeAd, Drawable drawable2, Uri uri, double d10, a aVar) {
            this(drawable2, uri, d10);
        }

        @NonNull
        public Drawable getDrawable() {
            return this.drawable;
        }

        public double getScale() {
            return this.scale;
        }

        @NonNull
        public Uri getUri() {
            return this.imageUri;
        }

        private PangleNativeMappedImage(Drawable drawable2, Uri uri, double d10) {
            this.drawable = drawable2;
            this.imageUri = uri;
            this.scale = d10;
        }
    }

    public class a implements PangleInitializer.Listener {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ String f13418a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ String f13419b;

        /* renamed from: com.google.ads.mediation.pangle.renderer.PangleNativeAd$a$a  reason: collision with other inner class name */
        public class C0209a implements PAGNativeAdLoadListener {
            public C0209a() {
            }

            public void onAdLoaded(Object obj) {
                PangleNativeAd.this.mapNativeAd((PAGNativeAd) obj);
                PangleNativeAd pangleNativeAd = PangleNativeAd.this;
                MediationNativeAdCallback unused = pangleNativeAd.callback = (MediationNativeAdCallback) pangleNativeAd.adLoadCallback.onSuccess(PangleNativeAd.this);
            }

            public void onError(int i10, String str) {
                AdError createSdkError = PangleConstants.createSdkError(i10, str);
                Log.w(PangleMediationAdapter.TAG, createSdkError.toString());
                PangleNativeAd.this.adLoadCallback.onFailure(createSdkError);
            }
        }

        public a(String str, String str2) {
            this.f13418a = str;
            this.f13419b = str2;
        }

        public void onInitializeError(@NonNull AdError adError) {
            Log.w(PangleMediationAdapter.TAG, adError.toString());
            PangleNativeAd.this.adLoadCallback.onFailure(adError);
        }

        public void onInitializeSuccess() {
            PAGNativeRequest pAGNativeRequest = new PAGNativeRequest();
            pAGNativeRequest.setAdString(this.f13418a);
            PAGNativeAd.loadAd(this.f13419b, pAGNativeRequest, (PAGNativeAdLoadListener) new C0209a());
        }
    }

    public class b implements PAGNativeAdInteractionListener {
        public b() {
        }

        public void onAdClicked() {
            if (PangleNativeAd.this.callback != null) {
                PangleNativeAd.this.callback.reportAdClicked();
            }
        }

        public void onAdDismissed() {
        }

        public void onAdShowed() {
            if (PangleNativeAd.this.callback != null) {
                PangleNativeAd.this.callback.reportAdImpression();
            }
        }
    }

    public class c implements View.OnClickListener {
        public c() {
        }

        public void onClick(View view) {
            PangleNativeAd.this.pagNativeAd.showPrivacyActivity();
        }
    }

    public PangleNativeAd(@NonNull MediationNativeAdConfiguration mediationNativeAdConfiguration, @NonNull MediationAdLoadCallback<UnifiedNativeAdMapper, MediationNativeAdCallback> mediationAdLoadCallback, PanglePrivacyConfig panglePrivacyConfig2) {
        this.adConfiguration = mediationNativeAdConfiguration;
        this.adLoadCallback = mediationAdLoadCallback;
        this.panglePrivacyConfig = panglePrivacyConfig2;
    }

    /* access modifiers changed from: private */
    public void mapNativeAd(PAGNativeAd pAGNativeAd) {
        this.pagNativeAd = pAGNativeAd;
        PAGNativeAdData nativeAdData = pAGNativeAd.getNativeAdData();
        setHeadline(nativeAdData.getTitle());
        setBody(nativeAdData.getDescription());
        setCallToAction(nativeAdData.getButtonText());
        if (nativeAdData.getIcon() != null) {
            setIcon(new PangleNativeMappedImage(this, (Drawable) null, Uri.parse(nativeAdData.getIcon().getImageUrl()), 1.0d, (a) null));
        }
        setOverrideClickHandling(true);
        setMediaView(nativeAdData.getMediaView());
        setAdChoicesContent(nativeAdData.getAdLogoView());
    }

    public void render() {
        this.panglePrivacyConfig.setCoppa(this.adConfiguration.taggedForChildDirectedTreatment());
        Bundle serverParameters = this.adConfiguration.getServerParameters();
        String string = serverParameters.getString(PangleConstants.PLACEMENT_ID);
        if (TextUtils.isEmpty(string)) {
            AdError createAdapterError = PangleConstants.createAdapterError(101, "Failed to load native ad from Pangle. Missing or invalid Placement ID.");
            Log.e(PangleMediationAdapter.TAG, createAdapterError.toString());
            this.adLoadCallback.onFailure(createAdapterError);
            return;
        }
        String bidResponse = this.adConfiguration.getBidResponse();
        PangleInitializer.getInstance().initialize(this.adConfiguration.getContext(), serverParameters.getString("appid"), new a(bidResponse, string));
    }

    public void trackViews(@NonNull View view, @NonNull Map<String, View> map, @NonNull Map<String, View> map2) {
        HashMap hashMap = new HashMap(map);
        hashMap.remove("3011");
        hashMap.remove("3012");
        View view2 = (View) hashMap.get("3002");
        ArrayList arrayList = new ArrayList();
        if (view2 != null) {
            arrayList.add(view2);
        }
        this.pagNativeAd.registerViewForInteraction((ViewGroup) view, (List<View>) new ArrayList(hashMap.values()), (List<View>) arrayList, (View) null, (PAGNativeAdInteractionListener) new b());
        getAdChoicesContent().setOnClickListener(new c());
    }
}
