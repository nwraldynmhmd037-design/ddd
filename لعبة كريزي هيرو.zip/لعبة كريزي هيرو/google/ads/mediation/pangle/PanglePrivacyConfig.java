package com.google.ads.mediation.pangle;

public class PanglePrivacyConfig {
    private static int coppa = -1;
    private final PangleSdkWrapper pangleSdkWrapper;

    public PanglePrivacyConfig(PangleSdkWrapper pangleSdkWrapper2) {
        this.pangleSdkWrapper = pangleSdkWrapper2;
    }

    public static int getCoppa() {
        return coppa;
    }

    public void setCoppa(int i10) {
        if (i10 == 0) {
            if (this.pangleSdkWrapper.isInitSuccess()) {
                this.pangleSdkWrapper.setChildDirected(0);
            }
            coppa = 0;
        } else if (i10 != 1) {
            if (this.pangleSdkWrapper.isInitSuccess()) {
                this.pangleSdkWrapper.setChildDirected(-1);
            }
            coppa = -1;
        } else {
            if (this.pangleSdkWrapper.isInitSuccess()) {
                this.pangleSdkWrapper.setChildDirected(1);
            }
            coppa = 1;
        }
    }
}
