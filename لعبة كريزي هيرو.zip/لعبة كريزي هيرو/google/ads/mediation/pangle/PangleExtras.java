package com.google.ads.mediation.pangle;

import android.os.Bundle;

public class PangleExtras {

    public static class Builder {
        private String userData;

        public Bundle build() {
            Bundle bundle = new Bundle();
            bundle.putString("user_data", this.userData);
            return bundle;
        }

        public Builder setUserData(String str) {
            this.userData = str;
            return this;
        }
    }
}
