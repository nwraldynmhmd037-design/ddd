package com.google.ads.mediation.pangle;

import com.bytedance.sdk.openadsdk.api.init.PAGConfig;

public class PangleFactory {
    public PAGConfig.Builder createPAGConfigBuilder() {
        return new PAGConfig.Builder();
    }
}
