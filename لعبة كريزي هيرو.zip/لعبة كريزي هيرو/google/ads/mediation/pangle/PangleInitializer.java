package com.google.ads.mediation.pangle;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;
import com.bytedance.sdk.openadsdk.api.init.PAGSdk;
import com.google.android.gms.ads.AdError;
import java.util.ArrayList;
import java.util.Iterator;

public class PangleInitializer implements PAGSdk.PAGInitCallback {
    private static PangleInitializer instance;
    private final ArrayList<Listener> initListeners;
    private boolean isInitialized;
    private boolean isInitializing;
    private final PangleFactory pangleFactory;
    private final PangleSdkWrapper pangleSdkWrapper;

    public interface Listener {
        void onInitializeError(@NonNull AdError adError);

        void onInitializeSuccess();
    }

    private PangleInitializer() {
        this.isInitializing = false;
        this.isInitialized = false;
        this.initListeners = new ArrayList<>();
        this.pangleSdkWrapper = new PangleSdkWrapper();
        this.pangleFactory = new PangleFactory();
    }

    @NonNull
    public static PangleInitializer getInstance() {
        if (instance == null) {
            instance = new PangleInitializer();
        }
        return instance;
    }

    public void fail(int i10, @NonNull String str) {
        this.isInitializing = false;
        this.isInitialized = false;
        AdError createSdkError = PangleConstants.createSdkError(i10, str);
        Iterator<Listener> it = this.initListeners.iterator();
        while (it.hasNext()) {
            it.next().onInitializeError(createSdkError);
        }
        this.initListeners.clear();
    }

    public void initialize(@NonNull Context context, @NonNull String str, @NonNull Listener listener) {
        if (TextUtils.isEmpty(str)) {
            AdError createAdapterError = PangleConstants.createAdapterError(101, "Failed to initialize Pangle SDK. Missing or invalid App ID.");
            Log.w(PangleMediationAdapter.TAG, createAdapterError.toString());
            listener.onInitializeError(createAdapterError);
        } else if (this.isInitializing) {
            this.initListeners.add(listener);
        } else if (this.isInitialized) {
            listener.onInitializeSuccess();
        } else {
            this.isInitializing = true;
            this.initListeners.add(listener);
            this.pangleSdkWrapper.init(context, this.pangleFactory.createPAGConfigBuilder().appId(str).setChildDirected(PanglePrivacyConfig.getCoppa()).setGDPRConsent(PangleMediationAdapter.getGDPRConsent()).setDoNotSell(PangleMediationAdapter.getDoNotSell()).build(), this);
        }
    }

    public void success() {
        this.isInitializing = false;
        this.isInitialized = true;
        Iterator<Listener> it = this.initListeners.iterator();
        while (it.hasNext()) {
            it.next().onInitializeSuccess();
        }
        this.initListeners.clear();
    }

    @VisibleForTesting
    public PangleInitializer(PangleSdkWrapper pangleSdkWrapper2, PangleFactory pangleFactory2) {
        this.isInitializing = false;
        this.isInitialized = false;
        this.initListeners = new ArrayList<>();
        this.pangleSdkWrapper = pangleSdkWrapper2;
        this.pangleFactory = pangleFactory2;
    }
}
