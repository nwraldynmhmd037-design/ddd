package com.google.ads.mediation.pangle;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;
import com.bytedance.sdk.openadsdk.api.PAGConstant;
import com.bytedance.sdk.openadsdk.api.init.PAGConfig;
import com.bytedance.sdk.openadsdk.api.init.PAGSdk;
import com.google.ads.mediation.pangle.PangleInitializer;
import com.google.ads.mediation.pangle.renderer.PangleAppOpenAd;
import com.google.ads.mediation.pangle.renderer.PangleBannerAd;
import com.google.ads.mediation.pangle.renderer.PangleInterstitialAd;
import com.google.ads.mediation.pangle.renderer.PangleNativeAd;
import com.google.ads.mediation.pangle.renderer.PangleRewardedAd;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.VersionInfo;
import com.google.android.gms.ads.mediation.InitializationCompleteCallback;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationAppOpenAd;
import com.google.android.gms.ads.mediation.MediationAppOpenAdCallback;
import com.google.android.gms.ads.mediation.MediationAppOpenAdConfiguration;
import com.google.android.gms.ads.mediation.MediationBannerAd;
import com.google.android.gms.ads.mediation.MediationBannerAdCallback;
import com.google.android.gms.ads.mediation.MediationBannerAdConfiguration;
import com.google.android.gms.ads.mediation.MediationConfiguration;
import com.google.android.gms.ads.mediation.MediationInterstitialAd;
import com.google.android.gms.ads.mediation.MediationInterstitialAdCallback;
import com.google.android.gms.ads.mediation.MediationInterstitialAdConfiguration;
import com.google.android.gms.ads.mediation.MediationNativeAdCallback;
import com.google.android.gms.ads.mediation.MediationNativeAdConfiguration;
import com.google.android.gms.ads.mediation.MediationRewardedAd;
import com.google.android.gms.ads.mediation.MediationRewardedAdCallback;
import com.google.android.gms.ads.mediation.MediationRewardedAdConfiguration;
import com.google.android.gms.ads.mediation.UnifiedNativeAdMapper;
import com.google.android.gms.ads.mediation.rtb.RtbAdapter;
import com.google.android.gms.ads.mediation.rtb.RtbSignalData;
import com.google.android.gms.ads.mediation.rtb.SignalCallbacks;
import java.util.HashSet;
import java.util.List;

public class PangleMediationAdapter extends RtbAdapter {
    @VisibleForTesting
    public static final String ERROR_MESSAGE_MISSING_OR_INVALID_APP_ID = "Missing or invalid App ID.";
    public static final String TAG = "PangleMediationAdapter";
    private static int ccpa = -1;
    private static int gdpr = -1;
    private PangleAppOpenAd appOpenAd;
    private PangleBannerAd bannerAd;
    private PangleInterstitialAd interstitialAd;
    private PangleNativeAd nativeAd;
    private final PangleInitializer pangleInitializer;
    private final PanglePrivacyConfig panglePrivacyConfig;
    private final PangleSdkWrapper pangleSdkWrapper;
    private PangleRewardedAd rewardedAd;

    public class a implements PangleInitializer.Listener {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ InitializationCompleteCallback f13395a;

        public a(PangleMediationAdapter pangleMediationAdapter, InitializationCompleteCallback initializationCompleteCallback) {
            this.f13395a = initializationCompleteCallback;
        }

        public void onInitializeError(@NonNull AdError adError) {
            Log.w(PangleMediationAdapter.TAG, adError.toString());
            this.f13395a.onInitializationFailed(adError.getMessage());
        }

        public void onInitializeSuccess() {
            this.f13395a.onInitializationSucceeded();
        }
    }

    public PangleMediationAdapter() {
        this.pangleInitializer = PangleInitializer.getInstance();
        PangleSdkWrapper pangleSdkWrapper2 = new PangleSdkWrapper();
        this.pangleSdkWrapper = pangleSdkWrapper2;
        this.panglePrivacyConfig = new PanglePrivacyConfig(pangleSdkWrapper2);
    }

    public static int getDoNotSell() {
        return ccpa;
    }

    public static int getGDPRConsent() {
        return gdpr;
    }

    public static void setDoNotSell(@PAGConstant.PAGDoNotSellType int i10) {
        if (i10 == 0 || i10 == 1 || i10 == -1) {
            if (PAGSdk.isInitSuccess()) {
                PAGConfig.setDoNotSell(i10);
            }
            ccpa = i10;
            return;
        }
        Log.w(TAG, "Invalid CCPA value. Pangle SDK only accepts -1, 0 or 1.");
    }

    public static void setGDPRConsent(@PAGConstant.PAGGDPRConsentType int i10) {
        if (i10 == 1 || i10 == 0 || i10 == -1) {
            if (PAGSdk.isInitSuccess()) {
                PAGConfig.setGDPRConsent(i10);
            }
            gdpr = i10;
            return;
        }
        Log.w(TAG, "Invalid GDPR value. Pangle SDK only accepts -1, 0 or 1.");
    }

    public void collectSignals(@NonNull RtbSignalData rtbSignalData, @NonNull SignalCallbacks signalCallbacks) {
        Bundle networkExtras = rtbSignalData.getNetworkExtras();
        if (networkExtras != null && networkExtras.containsKey("user_data")) {
            PAGConfig.setUserData(networkExtras.getString("user_data", ""));
        }
        signalCallbacks.onSuccess(PAGSdk.getBiddingToken());
    }

    @NonNull
    public VersionInfo getSDKVersionInfo() {
        String sDKVersion = PAGSdk.getSDKVersion();
        String[] split = sDKVersion.split("\\.");
        if (split.length >= 3) {
            int parseInt = Integer.parseInt(split[0]);
            int parseInt2 = Integer.parseInt(split[1]);
            int parseInt3 = Integer.parseInt(split[2]);
            if (split.length >= 4) {
                parseInt3 = (parseInt3 * 100) + Integer.parseInt(split[3]);
            }
            return new VersionInfo(parseInt, parseInt2, parseInt3);
        }
        Log.w(TAG, String.format("Unexpected SDK version format: %s. Returning 0.0.0 for SDK version.", new Object[]{sDKVersion}));
        return new VersionInfo(0, 0, 0);
    }

    @NonNull
    public VersionInfo getVersionInfo() {
        String[] split = BuildConfig.ADAPTER_VERSION.split("\\.");
        if (split.length >= 4) {
            int parseInt = Integer.parseInt(split[0]);
            int parseInt2 = Integer.parseInt(split[1]);
            int parseInt3 = Integer.parseInt(split[3]) + (Integer.parseInt(split[2]) * 100);
            if (split.length >= 5) {
                parseInt3 = (parseInt3 * 100) + Integer.parseInt(split[4]);
            }
            return new VersionInfo(parseInt, parseInt2, parseInt3);
        }
        Log.w(TAG, String.format("Unexpected adapter version format: %s. Returning 0.0.0 for adapter version.", new Object[]{BuildConfig.ADAPTER_VERSION}));
        return new VersionInfo(0, 0, 0);
    }

    public void initialize(@NonNull Context context, @NonNull InitializationCompleteCallback initializationCompleteCallback, @NonNull List<MediationConfiguration> list) {
        HashSet hashSet = new HashSet();
        for (MediationConfiguration serverParameters : list) {
            String string = serverParameters.getServerParameters().getString("appid");
            if (!TextUtils.isEmpty(string)) {
                hashSet.add(string);
            }
        }
        int size = hashSet.size();
        if (size <= 0) {
            AdError createAdapterError = PangleConstants.createAdapterError(101, ERROR_MESSAGE_MISSING_OR_INVALID_APP_ID);
            Log.w(TAG, createAdapterError.toString());
            initializationCompleteCallback.onInitializationFailed(createAdapterError.toString());
            return;
        }
        String str = (String) hashSet.iterator().next();
        if (size > 1) {
            Log.w(TAG, String.format("Found multiple app IDs in %s. Using %s to initialize Pangle SDK.", new Object[]{hashSet, str}));
        }
        this.panglePrivacyConfig.setCoppa(MobileAds.getRequestConfiguration().getTagForChildDirectedTreatment());
        this.pangleInitializer.initialize(context, str, new a(this, initializationCompleteCallback));
    }

    public void loadAppOpenAd(@NonNull MediationAppOpenAdConfiguration mediationAppOpenAdConfiguration, @NonNull MediationAdLoadCallback<MediationAppOpenAd, MediationAppOpenAdCallback> mediationAdLoadCallback) {
        PangleAppOpenAd pangleAppOpenAd = new PangleAppOpenAd(mediationAppOpenAdConfiguration, mediationAdLoadCallback, this.panglePrivacyConfig);
        this.appOpenAd = pangleAppOpenAd;
        pangleAppOpenAd.render();
    }

    public void loadBannerAd(@NonNull MediationBannerAdConfiguration mediationBannerAdConfiguration, @NonNull MediationAdLoadCallback<MediationBannerAd, MediationBannerAdCallback> mediationAdLoadCallback) {
        PangleBannerAd pangleBannerAd = new PangleBannerAd(mediationBannerAdConfiguration, mediationAdLoadCallback, this.pangleInitializer, this.pangleSdkWrapper, this.panglePrivacyConfig);
        this.bannerAd = pangleBannerAd;
        pangleBannerAd.render();
    }

    public void loadInterstitialAd(@NonNull MediationInterstitialAdConfiguration mediationInterstitialAdConfiguration, @NonNull MediationAdLoadCallback<MediationInterstitialAd, MediationInterstitialAdCallback> mediationAdLoadCallback) {
        PangleInterstitialAd pangleInterstitialAd = new PangleInterstitialAd(mediationInterstitialAdConfiguration, mediationAdLoadCallback, this.panglePrivacyConfig);
        this.interstitialAd = pangleInterstitialAd;
        pangleInterstitialAd.render();
    }

    public void loadNativeAd(@NonNull MediationNativeAdConfiguration mediationNativeAdConfiguration, @NonNull MediationAdLoadCallback<UnifiedNativeAdMapper, MediationNativeAdCallback> mediationAdLoadCallback) {
        PangleNativeAd pangleNativeAd = new PangleNativeAd(mediationNativeAdConfiguration, mediationAdLoadCallback, this.panglePrivacyConfig);
        this.nativeAd = pangleNativeAd;
        pangleNativeAd.render();
    }

    public void loadRewardedAd(@NonNull MediationRewardedAdConfiguration mediationRewardedAdConfiguration, @NonNull MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback> mediationAdLoadCallback) {
        PangleRewardedAd pangleRewardedAd = new PangleRewardedAd(mediationRewardedAdConfiguration, mediationAdLoadCallback, this.panglePrivacyConfig);
        this.rewardedAd = pangleRewardedAd;
        pangleRewardedAd.render();
    }

    @VisibleForTesting
    public PangleMediationAdapter(PangleInitializer pangleInitializer2, PangleSdkWrapper pangleSdkWrapper2, PanglePrivacyConfig panglePrivacyConfig2) {
        this.pangleInitializer = pangleInitializer2;
        this.pangleSdkWrapper = pangleSdkWrapper2;
        this.panglePrivacyConfig = panglePrivacyConfig2;
    }
}
