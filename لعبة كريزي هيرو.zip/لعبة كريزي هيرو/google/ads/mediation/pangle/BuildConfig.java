package com.google.ads.mediation.pangle;

public final class BuildConfig {
    public static final String ADAPTER_VERSION = "5.2.0.5.0";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.google.ads.mediation.pangle";
}
