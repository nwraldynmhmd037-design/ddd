package com.google.ads.mediation.facebook;

public final class R {

    public static final class attr {
        public static final int adSize = 2130968613;
        public static final int adSizes = 2130968614;
        public static final int adUnitId = 2130968615;
        public static final int alpha = 2130968661;
        public static final int buttonSize = 2130968743;
        public static final int circleCrop = 2130968788;
        public static final int colorScheme = 2130968829;
        public static final int coordinatorLayoutStyle = 2130968873;
        public static final int font = 2130969007;
        public static final int fontProviderAuthority = 2130969009;
        public static final int fontProviderCerts = 2130969010;
        public static final int fontProviderFetchStrategy = 2130969011;
        public static final int fontProviderFetchTimeout = 2130969012;
        public static final int fontProviderPackage = 2130969013;
        public static final int fontProviderQuery = 2130969014;
        public static final int fontProviderSystemFontFamily = 2130969015;
        public static final int fontStyle = 2130969016;
        public static final int fontVariationSettings = 2130969017;
        public static final int fontWeight = 2130969018;
        public static final int imageAspectRatio = 2130969054;
        public static final int imageAspectRatioAdjust = 2130969055;
        public static final int keylines = 2130969095;
        public static final int layout_anchor = 2130969105;
        public static final int layout_anchorGravity = 2130969106;
        public static final int layout_behavior = 2130969107;
        public static final int layout_dodgeInsetEdges = 2130969152;
        public static final int layout_insetEdge = 2130969161;
        public static final int layout_keyline = 2130969162;
        public static final int nestedScrollViewStyle = 2130969268;
        public static final int queryPatterns = 2130969344;
        public static final int scopeUris = 2130969363;
        public static final int shortcutMatchRequired = 2130969380;
        public static final int statusBarBackground = 2130969489;
        public static final int ttcIndex = 2130969634;

        private attr() {
        }
    }

    public static final class bool {
        public static final int enable_system_alarm_service_default = 2131034114;
        public static final int enable_system_foreground_service_default = 2131034115;
        public static final int enable_system_job_service_default = 2131034116;
        public static final int workmanager_test_configuration = 2131034118;

        private bool() {
        }
    }

    public static final class color {
        public static final int androidx_core_ripple_material_light = 2131099683;
        public static final int androidx_core_secondary_text_default_material_light = 2131099684;
        public static final int browser_actions_bg_grey = 2131099722;
        public static final int browser_actions_divider_color = 2131099723;
        public static final int browser_actions_text_color = 2131099724;
        public static final int browser_actions_title_color = 2131099725;
        public static final int common_google_signin_btn_text_dark = 2131099769;
        public static final int common_google_signin_btn_text_dark_default = 2131099770;
        public static final int common_google_signin_btn_text_dark_disabled = 2131099771;
        public static final int common_google_signin_btn_text_dark_focused = 2131099772;
        public static final int common_google_signin_btn_text_dark_pressed = 2131099773;
        public static final int common_google_signin_btn_text_light = 2131099774;
        public static final int common_google_signin_btn_text_light_default = 2131099775;
        public static final int common_google_signin_btn_text_light_disabled = 2131099776;
        public static final int common_google_signin_btn_text_light_focused = 2131099777;
        public static final int common_google_signin_btn_text_light_pressed = 2131099778;
        public static final int common_google_signin_btn_tint = 2131099779;
        public static final int notification_action_color_filter = 2131100008;
        public static final int notification_icon_bg_color = 2131100009;
        public static final int ripple_material_light = 2131100027;
        public static final int secondary_text_default_material_light = 2131100029;

        private color() {
        }
    }

    public static final class dimen {
        public static final int browser_actions_context_menu_max_width = 2131165312;
        public static final int browser_actions_context_menu_min_padding = 2131165313;
        public static final int compat_button_inset_horizontal_material = 2131165334;
        public static final int compat_button_inset_vertical_material = 2131165335;
        public static final int compat_button_padding_horizontal_material = 2131165336;
        public static final int compat_button_padding_vertical_material = 2131165337;
        public static final int compat_control_corner_material = 2131165338;
        public static final int compat_notification_large_icon_max_height = 2131165339;
        public static final int compat_notification_large_icon_max_width = 2131165340;
        public static final int notification_action_icon_size = 2131165692;
        public static final int notification_action_text_size = 2131165693;
        public static final int notification_big_circle_margin = 2131165694;
        public static final int notification_content_margin_start = 2131165695;
        public static final int notification_large_icon_height = 2131165696;
        public static final int notification_large_icon_width = 2131165697;
        public static final int notification_main_column_padding_top = 2131165698;
        public static final int notification_media_narrow_margin = 2131165699;
        public static final int notification_right_icon_size = 2131165700;
        public static final int notification_right_side_padding_top = 2131165701;
        public static final int notification_small_icon_background_padding = 2131165702;
        public static final int notification_small_icon_size_as_large = 2131165703;
        public static final int notification_subtext_size = 2131165704;
        public static final int notification_top_pad = 2131165705;
        public static final int notification_top_pad_large_text = 2131165706;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int admob_close_button_black_circle_white_cross = 2131230817;
        public static final int admob_close_button_white_circle_black_cross = 2131230818;
        public static final int common_full_open_on_phone = 2131231001;
        public static final int common_google_signin_btn_icon_dark = 2131231002;
        public static final int common_google_signin_btn_icon_dark_focused = 2131231003;
        public static final int common_google_signin_btn_icon_dark_normal = 2131231004;
        public static final int common_google_signin_btn_icon_dark_normal_background = 2131231005;
        public static final int common_google_signin_btn_icon_disabled = 2131231006;
        public static final int common_google_signin_btn_icon_light = 2131231007;
        public static final int common_google_signin_btn_icon_light_focused = 2131231008;
        public static final int common_google_signin_btn_icon_light_normal = 2131231009;
        public static final int common_google_signin_btn_icon_light_normal_background = 2131231010;
        public static final int common_google_signin_btn_text_dark = 2131231011;
        public static final int common_google_signin_btn_text_dark_focused = 2131231012;
        public static final int common_google_signin_btn_text_dark_normal = 2131231013;
        public static final int common_google_signin_btn_text_dark_normal_background = 2131231014;
        public static final int common_google_signin_btn_text_disabled = 2131231015;
        public static final int common_google_signin_btn_text_light = 2131231016;
        public static final int common_google_signin_btn_text_light_focused = 2131231017;
        public static final int common_google_signin_btn_text_light_normal = 2131231018;
        public static final int common_google_signin_btn_text_light_normal_background = 2131231019;
        public static final int googleg_disabled_color_18 = 2131231052;
        public static final int googleg_standard_color_18 = 2131231053;
        public static final int notification_action_background = 2131231283;
        public static final int notification_bg = 2131231284;
        public static final int notification_bg_low = 2131231285;
        public static final int notification_bg_low_normal = 2131231286;
        public static final int notification_bg_low_pressed = 2131231287;
        public static final int notification_bg_normal = 2131231288;
        public static final int notification_bg_normal_pressed = 2131231289;
        public static final int notification_icon_background = 2131231290;
        public static final int notification_template_icon_bg = 2131231291;
        public static final int notification_template_icon_low_bg = 2131231292;
        public static final int notification_tile_bg = 2131231293;
        public static final int notify_panel_notification_icon_bg = 2131231294;

        private drawable() {
        }
    }

    public static final class id {
        public static final int accessibility_action_clickable_span = 2131361812;
        public static final int accessibility_custom_action_0 = 2131361813;
        public static final int accessibility_custom_action_1 = 2131361814;
        public static final int accessibility_custom_action_10 = 2131361815;
        public static final int accessibility_custom_action_11 = 2131361816;
        public static final int accessibility_custom_action_12 = 2131361817;
        public static final int accessibility_custom_action_13 = 2131361818;
        public static final int accessibility_custom_action_14 = 2131361819;
        public static final int accessibility_custom_action_15 = 2131361820;
        public static final int accessibility_custom_action_16 = 2131361821;
        public static final int accessibility_custom_action_17 = 2131361822;
        public static final int accessibility_custom_action_18 = 2131361823;
        public static final int accessibility_custom_action_19 = 2131361824;
        public static final int accessibility_custom_action_2 = 2131361825;
        public static final int accessibility_custom_action_20 = 2131361826;
        public static final int accessibility_custom_action_21 = 2131361827;
        public static final int accessibility_custom_action_22 = 2131361828;
        public static final int accessibility_custom_action_23 = 2131361829;
        public static final int accessibility_custom_action_24 = 2131361830;
        public static final int accessibility_custom_action_25 = 2131361831;
        public static final int accessibility_custom_action_26 = 2131361832;
        public static final int accessibility_custom_action_27 = 2131361833;
        public static final int accessibility_custom_action_28 = 2131361834;
        public static final int accessibility_custom_action_29 = 2131361835;
        public static final int accessibility_custom_action_3 = 2131361836;
        public static final int accessibility_custom_action_30 = 2131361837;
        public static final int accessibility_custom_action_31 = 2131361838;
        public static final int accessibility_custom_action_4 = 2131361839;
        public static final int accessibility_custom_action_5 = 2131361840;
        public static final int accessibility_custom_action_6 = 2131361841;
        public static final int accessibility_custom_action_7 = 2131361842;
        public static final int accessibility_custom_action_8 = 2131361843;
        public static final int accessibility_custom_action_9 = 2131361844;
        public static final int action_container = 2131361853;
        public static final int action_divider = 2131361855;
        public static final int action_image = 2131361856;
        public static final int action_text = 2131361863;
        public static final int actions = 2131361864;
        public static final int adjust_height = 2131361879;
        public static final int adjust_width = 2131361880;
        public static final int async = 2131361952;
        public static final int auto = 2131361954;
        public static final int blocking = 2131361976;
        public static final int bottom = 2131361980;
        public static final int browser_actions_header_text = 2131361987;
        public static final int browser_actions_menu_item_icon = 2131361988;
        public static final int browser_actions_menu_item_text = 2131361989;
        public static final int browser_actions_menu_items = 2131361990;
        public static final int browser_actions_menu_view = 2131361991;
        public static final int chronometer = 2131362019;
        public static final int dark = 2131362060;
        public static final int dialog_button = 2131362075;
        public static final int end = 2131362100;
        public static final int forever = 2131362146;
        public static final int icon = 2131362205;
        public static final int icon_group = 2131362206;
        public static final int icon_only = 2131362208;
        public static final int info = 2131362236;
        public static final int italic = 2131362259;
        public static final int layout = 2131362316;
        public static final int left = 2131362320;
        public static final int light = 2131362324;
        public static final int line1 = 2131362325;
        public static final int line3 = 2131362326;
        public static final int none = 2131362660;
        public static final int normal = 2131362661;
        public static final int notification_background = 2131362662;
        public static final int notification_main_column = 2131362663;
        public static final int notification_main_column_container = 2131362664;
        public static final int right = 2131362735;
        public static final int right_icon = 2131362737;
        public static final int right_side = 2131362738;
        public static final int standard = 2131362841;
        public static final int start = 2131362842;
        public static final int tag_accessibility_actions = 2131362860;
        public static final int tag_accessibility_clickable_spans = 2131362861;
        public static final int tag_accessibility_heading = 2131362862;
        public static final int tag_accessibility_pane_title = 2131362863;
        public static final int tag_on_apply_window_listener = 2131362866;
        public static final int tag_on_receive_content_listener = 2131362867;
        public static final int tag_on_receive_content_mime_types = 2131362868;
        public static final int tag_screen_reader_focusable = 2131362869;
        public static final int tag_state_description = 2131362870;
        public static final int tag_transition_group = 2131362871;
        public static final int tag_unhandled_key_event_manager = 2131362872;
        public static final int tag_unhandled_key_listeners = 2131362873;
        public static final int tag_window_insets_animation_callback = 2131362874;
        public static final int text = 2131362884;
        public static final int text2 = 2131362885;
        public static final int time = 2131362906;
        public static final int title = 2131362907;
        public static final int top = 2131362914;
        public static final int wide = 2131363427;

        private id() {
        }
    }

    public static final class integer {
        public static final int google_play_services_version = 2131427338;
        public static final int status_bar_notification_info_maxnum = 2131427353;

        private integer() {
        }
    }

    public static final class layout {
        public static final int admob_empty_layout = 2131558449;
        public static final int browser_actions_context_menu_page = 2131558464;
        public static final int browser_actions_context_menu_row = 2131558465;
        public static final int custom_dialog = 2131558475;
        public static final int notification_action = 2131558694;
        public static final int notification_action_tombstone = 2131558695;
        public static final int notification_template_custom_big = 2131558702;
        public static final int notification_template_icon_group = 2131558703;
        public static final int notification_template_part_chronometer = 2131558707;
        public static final int notification_template_part_time = 2131558708;

        private layout() {
        }
    }

    public static final class string {
        public static final int androidx_startup = 2131886164;
        public static final int common_google_play_services_enable_button = 2131886215;
        public static final int common_google_play_services_enable_text = 2131886216;
        public static final int common_google_play_services_enable_title = 2131886217;
        public static final int common_google_play_services_install_button = 2131886218;
        public static final int common_google_play_services_install_text = 2131886219;
        public static final int common_google_play_services_install_title = 2131886220;
        public static final int common_google_play_services_notification_channel_name = 2131886221;
        public static final int common_google_play_services_notification_ticker = 2131886222;
        public static final int common_google_play_services_unknown_issue = 2131886223;
        public static final int common_google_play_services_unsupported_text = 2131886224;
        public static final int common_google_play_services_update_button = 2131886225;
        public static final int common_google_play_services_update_text = 2131886226;
        public static final int common_google_play_services_update_title = 2131886227;
        public static final int common_google_play_services_updating_text = 2131886228;
        public static final int common_google_play_services_wear_update_text = 2131886229;
        public static final int common_open_on_phone = 2131886230;
        public static final int common_signin_button_text = 2131886231;
        public static final int common_signin_button_text_long = 2131886232;
        public static final int copy_toast_msg = 2131886233;
        public static final int fallback_menu_item_copy_link = 2131886273;
        public static final int fallback_menu_item_open_in_browser = 2131886274;
        public static final int fallback_menu_item_share_link = 2131886275;
        public static final int native_body = 2131886386;
        public static final int native_headline = 2131886387;
        public static final int native_media_view = 2131886388;
        public static final int notifications_permission_confirm = 2131886390;
        public static final int notifications_permission_decline = 2131886391;
        public static final int notifications_permission_title = 2131886392;
        public static final int offline_notification_text = 2131886393;
        public static final int offline_notification_title = 2131886394;
        public static final int offline_opt_in_confirm = 2131886395;
        public static final int offline_opt_in_confirmation = 2131886396;
        public static final int offline_opt_in_decline = 2131886397;
        public static final int offline_opt_in_message = 2131886398;
        public static final int offline_opt_in_title = 2131886399;

        /* renamed from: s1  reason: collision with root package name */
        public static final int f13368s1 = 2131886447;

        /* renamed from: s2  reason: collision with root package name */
        public static final int f13369s2 = 2131886448;

        /* renamed from: s3  reason: collision with root package name */
        public static final int f13370s3 = 2131886449;

        /* renamed from: s4  reason: collision with root package name */
        public static final int f13371s4 = 2131886450;

        /* renamed from: s5  reason: collision with root package name */
        public static final int f13372s5 = 2131886451;

        /* renamed from: s6  reason: collision with root package name */
        public static final int f13373s6 = 2131886452;

        /* renamed from: s7  reason: collision with root package name */
        public static final int f13374s7 = 2131886453;
        public static final int status_bar_notification_info_overflow = 2131886481;
        public static final int watermark_label_prefix = 2131886641;

        private string() {
        }
    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification = 2131952048;
        public static final int TextAppearance_Compat_Notification_Info = 2131952049;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131952051;
        public static final int TextAppearance_Compat_Notification_Time = 2131952054;
        public static final int TextAppearance_Compat_Notification_Title = 2131952056;
        public static final int Theme_IAPTheme = 2131952117;
        public static final int Widget_Compat_NotificationActionContainer = 2131952296;
        public static final int Widget_Compat_NotificationActionText = 2131952297;
        public static final int Widget_Support_CoordinatorLayout = 2131952423;

        private style() {
        }
    }

    public static final class styleable {
        public static final int[] AdsAttrs = {com.crazyhero.android.R.attr.adSize, com.crazyhero.android.R.attr.adSizes, com.crazyhero.android.R.attr.adUnitId};
        public static final int AdsAttrs_adSize = 0;
        public static final int AdsAttrs_adSizes = 1;
        public static final int AdsAttrs_adUnitId = 2;
        public static final int[] Capability = {com.crazyhero.android.R.attr.queryPatterns, com.crazyhero.android.R.attr.shortcutMatchRequired};
        public static final int Capability_queryPatterns = 0;
        public static final int Capability_shortcutMatchRequired = 1;
        public static final int[] ColorStateListItem = {16843173, 16843551, 16844359, com.crazyhero.android.R.attr.alpha, com.crazyhero.android.R.attr.lStar};
        public static final int ColorStateListItem_alpha = 3;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int ColorStateListItem_android_lStar = 2;
        public static final int ColorStateListItem_lStar = 4;
        public static final int[] CoordinatorLayout = {com.crazyhero.android.R.attr.keylines, com.crazyhero.android.R.attr.statusBarBackground};
        public static final int[] CoordinatorLayout_Layout = {16842931, com.crazyhero.android.R.attr.layout_anchor, com.crazyhero.android.R.attr.layout_anchorGravity, com.crazyhero.android.R.attr.layout_behavior, com.crazyhero.android.R.attr.layout_dodgeInsetEdges, com.crazyhero.android.R.attr.layout_insetEdge, com.crazyhero.android.R.attr.layout_keyline};
        public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
        public static final int CoordinatorLayout_Layout_layout_anchor = 1;
        public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
        public static final int CoordinatorLayout_Layout_layout_behavior = 3;
        public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
        public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
        public static final int CoordinatorLayout_Layout_layout_keyline = 6;
        public static final int CoordinatorLayout_keylines = 0;
        public static final int CoordinatorLayout_statusBarBackground = 1;
        public static final int[] FontFamily = {com.crazyhero.android.R.attr.fontProviderAuthority, com.crazyhero.android.R.attr.fontProviderCerts, com.crazyhero.android.R.attr.fontProviderFetchStrategy, com.crazyhero.android.R.attr.fontProviderFetchTimeout, com.crazyhero.android.R.attr.fontProviderPackage, com.crazyhero.android.R.attr.fontProviderQuery, com.crazyhero.android.R.attr.fontProviderSystemFontFamily};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, com.crazyhero.android.R.attr.font, com.crazyhero.android.R.attr.fontStyle, com.crazyhero.android.R.attr.fontVariationSettings, com.crazyhero.android.R.attr.fontWeight, com.crazyhero.android.R.attr.ttcIndex};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int FontFamily_fontProviderSystemFontFamily = 6;
        public static final int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = {16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;
        public static final int[] LoadingImageView = {com.crazyhero.android.R.attr.circleCrop, com.crazyhero.android.R.attr.imageAspectRatio, com.crazyhero.android.R.attr.imageAspectRatioAdjust};
        public static final int LoadingImageView_circleCrop = 0;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 2;
        public static final int[] SignInButton = {com.crazyhero.android.R.attr.buttonSize, com.crazyhero.android.R.attr.button_style, com.crazyhero.android.R.attr.colorScheme, com.crazyhero.android.R.attr.scopeUris, com.crazyhero.android.R.attr.text};
        public static final int SignInButton_buttonSize = 0;
        public static final int SignInButton_button_style = 1;
        public static final int SignInButton_colorScheme = 2;
        public static final int SignInButton_scopeUris = 3;
        public static final int SignInButton_text = 4;

        private styleable() {
        }
    }

    public static final class xml {
        public static final int image_share_filepaths = 2132082695;

        private xml() {
        }
    }

    private R() {
    }
}
