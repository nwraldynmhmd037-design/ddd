package com.google.ads.mediation.facebook;

import androidx.annotation.NonNull;
import com.google.android.gms.ads.rewarded.RewardItem;

public class FacebookReward implements RewardItem {
    public int getAmount() {
        return 1;
    }

    @NonNull
    public String getType() {
        return "";
    }
}
