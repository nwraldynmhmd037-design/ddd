package com.google.ads.mediation.facebook;

import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.AdError;
import java.util.ArrayList;
import java.util.Iterator;

/* compiled from: FacebookInitializer */
public class a implements AudienceNetworkAds.InitListener {

    /* renamed from: d  reason: collision with root package name */
    public static a f13375d;

    /* renamed from: a  reason: collision with root package name */
    public boolean f13376a = false;

    /* renamed from: b  reason: collision with root package name */
    public boolean f13377b = false;

    /* renamed from: c  reason: collision with root package name */
    public final ArrayList<C0205a> f13378c = new ArrayList<>();

    /* renamed from: com.google.ads.mediation.facebook.a$a  reason: collision with other inner class name */
    /* compiled from: FacebookInitializer */
    public interface C0205a {
        void onInitializeError(AdError adError);

        void onInitializeSuccess();
    }

    public void onInitialized(AudienceNetworkAds.InitResult initResult) {
        this.f13376a = false;
        this.f13377b = initResult.isSuccess();
        Iterator<C0205a> it = this.f13378c.iterator();
        while (it.hasNext()) {
            C0205a next = it.next();
            if (initResult.isSuccess()) {
                next.onInitializeSuccess();
            } else {
                next.onInitializeError(new AdError(104, initResult.getMessage(), "com.google.ads.mediation.facebook"));
            }
        }
        this.f13378c.clear();
    }
}
