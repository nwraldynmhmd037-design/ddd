package com.google.ads.mediation.mintegral;

import android.view.ViewGroup;
import com.google.android.gms.common.internal.ServiceSpecificExtraArgs;
import com.ironsource.sdk.constants.a;
import com.mbridge.msdk.out.MBSplashHandler;
import com.mbridge.msdk.out.MBSplashLoadWithCodeListener;
import com.mbridge.msdk.out.MBSplashShowListener;
import jg.m;

/* compiled from: MintegralFactory.kt */
public final class MintegralFactory$createSplashAdWrapper$1 implements MintegralSplashAdWrapper {
    private MBSplashHandler instance;

    public void createAd(String str, String str2) {
        m.f(str, a.f24292i);
        m.f(str2, "adUnitId");
        this.instance = new MBSplashHandler(str, str2, true, 5);
    }

    public void onDestroy() {
        MBSplashHandler mBSplashHandler = this.instance;
        if (mBSplashHandler != null) {
            mBSplashHandler.onDestroy();
        }
    }

    public void preLoad() {
        MBSplashHandler mBSplashHandler = this.instance;
        if (mBSplashHandler != null) {
            mBSplashHandler.preLoad();
        }
    }

    public void setSplashLoadListener(MBSplashLoadWithCodeListener mBSplashLoadWithCodeListener) {
        m.f(mBSplashLoadWithCodeListener, ServiceSpecificExtraArgs.CastExtraArgs.LISTENER);
        MBSplashHandler mBSplashHandler = this.instance;
        if (mBSplashHandler != null) {
            mBSplashHandler.setSplashLoadListener(mBSplashLoadWithCodeListener);
        }
    }

    public void setSplashShowListener(MBSplashShowListener mBSplashShowListener) {
        m.f(mBSplashShowListener, ServiceSpecificExtraArgs.CastExtraArgs.LISTENER);
        MBSplashHandler mBSplashHandler = this.instance;
        if (mBSplashHandler != null) {
            mBSplashHandler.setSplashShowListener(mBSplashShowListener);
        }
    }

    public void show(ViewGroup viewGroup) {
        m.f(viewGroup, "group");
        MBSplashHandler mBSplashHandler = this.instance;
        if (mBSplashHandler != null) {
            mBSplashHandler.show(viewGroup);
        }
    }
}
