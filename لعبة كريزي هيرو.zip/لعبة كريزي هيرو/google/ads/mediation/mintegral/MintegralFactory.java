package com.google.ads.mediation.mintegral;

/* compiled from: MintegralFactory.kt */
public final class MintegralFactory {
    public static final MintegralFactory INSTANCE = new MintegralFactory();

    private MintegralFactory() {
    }

    public static final MintegralSplashAdWrapper createSplashAdWrapper() {
        return new MintegralFactory$createSplashAdWrapper$1();
    }
}
