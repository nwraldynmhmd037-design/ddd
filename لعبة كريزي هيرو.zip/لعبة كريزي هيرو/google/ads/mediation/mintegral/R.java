package com.google.ads.mediation.mintegral;

public final class R {

    public static final class anim {
        public static final int mbridge_reward_activity_open = 2130772014;
        public static final int mbridge_reward_activity_stay = 2130772015;

        private anim() {
        }
    }

    public static final class attr {
        public static final int adSize = 2130968613;
        public static final int adSizes = 2130968614;
        public static final int adUnitId = 2130968615;
        public static final int alpha = 2130968661;
        public static final int buttonSize = 2130968743;
        public static final int circleCrop = 2130968788;
        public static final int colorScheme = 2130968829;
        public static final int coordinatorLayoutStyle = 2130968873;
        public static final int corner = 2130968874;
        public static final int font = 2130969007;
        public static final int fontProviderAuthority = 2130969009;
        public static final int fontProviderCerts = 2130969010;
        public static final int fontProviderFetchStrategy = 2130969011;
        public static final int fontProviderFetchTimeout = 2130969012;
        public static final int fontProviderPackage = 2130969013;
        public static final int fontProviderQuery = 2130969014;
        public static final int fontProviderSystemFontFamily = 2130969015;
        public static final int fontStyle = 2130969016;
        public static final int fontVariationSettings = 2130969017;
        public static final int fontWeight = 2130969018;
        public static final int imageAspectRatio = 2130969054;
        public static final int imageAspectRatioAdjust = 2130969055;
        public static final int keylines = 2130969095;
        public static final int layout_anchor = 2130969105;
        public static final int layout_anchorGravity = 2130969106;
        public static final int layout_behavior = 2130969107;
        public static final int layout_dodgeInsetEdges = 2130969152;
        public static final int layout_insetEdge = 2130969161;
        public static final int layout_keyline = 2130969162;
        public static final int mbridge_click = 2130969233;
        public static final int mbridge_data = 2130969234;
        public static final int mbridge_effect = 2130969235;
        public static final int mbridge_effect_strategy = 2130969236;
        public static final int mbridge_report = 2130969237;
        public static final int mbridge_strategy = 2130969238;
        public static final int nestedScrollViewStyle = 2130969268;
        public static final int queryPatterns = 2130969344;
        public static final int scopeUris = 2130969363;
        public static final int shortcutMatchRequired = 2130969380;
        public static final int statusBarBackground = 2130969489;
        public static final int ttcIndex = 2130969634;

        private attr() {
        }
    }

    public static final class bool {
        public static final int enable_system_alarm_service_default = 2131034114;
        public static final int enable_system_foreground_service_default = 2131034115;
        public static final int enable_system_job_service_default = 2131034116;
        public static final int workmanager_test_configuration = 2131034118;

        private bool() {
        }
    }

    public static final class color {
        public static final int androidx_core_ripple_material_light = 2131099683;
        public static final int androidx_core_secondary_text_default_material_light = 2131099684;
        public static final int browser_actions_bg_grey = 2131099722;
        public static final int browser_actions_divider_color = 2131099723;
        public static final int browser_actions_text_color = 2131099724;
        public static final int browser_actions_title_color = 2131099725;
        public static final int common_google_signin_btn_text_dark = 2131099769;
        public static final int common_google_signin_btn_text_dark_default = 2131099770;
        public static final int common_google_signin_btn_text_dark_disabled = 2131099771;
        public static final int common_google_signin_btn_text_dark_focused = 2131099772;
        public static final int common_google_signin_btn_text_dark_pressed = 2131099773;
        public static final int common_google_signin_btn_text_light = 2131099774;
        public static final int common_google_signin_btn_text_light_default = 2131099775;
        public static final int common_google_signin_btn_text_light_disabled = 2131099776;
        public static final int common_google_signin_btn_text_light_focused = 2131099777;
        public static final int common_google_signin_btn_text_light_pressed = 2131099778;
        public static final int common_google_signin_btn_tint = 2131099779;
        public static final int mbridge_black = 2131099898;
        public static final int mbridge_black_66 = 2131099899;
        public static final int mbridge_black_alpha_50 = 2131099900;
        public static final int mbridge_cm_feedback_dialog_chice_bg_pressed = 2131099901;
        public static final int mbridge_cm_feedback_rb_text_color_color_list = 2131099902;
        public static final int mbridge_color_999999 = 2131099903;
        public static final int mbridge_color_cc000000 = 2131099904;
        public static final int mbridge_common_white = 2131099905;
        public static final int mbridge_cpb_blue = 2131099906;
        public static final int mbridge_cpb_blue_dark = 2131099907;
        public static final int mbridge_cpb_green = 2131099908;
        public static final int mbridge_cpb_green_dark = 2131099909;
        public static final int mbridge_cpb_grey = 2131099910;
        public static final int mbridge_cpb_red = 2131099911;
        public static final int mbridge_cpb_red_dark = 2131099912;
        public static final int mbridge_cpb_white = 2131099913;
        public static final int mbridge_dd_grey = 2131099914;
        public static final int mbridge_ee_grey = 2131099915;
        public static final int mbridge_more_offer_list_bg = 2131099918;
        public static final int mbridge_nativex_cta_txt_nor = 2131099919;
        public static final int mbridge_nativex_cta_txt_pre = 2131099920;
        public static final int mbridge_nativex_land_cta_bg_nor = 2131099921;
        public static final int mbridge_nativex_por_cta_bg_nor = 2131099922;
        public static final int mbridge_nativex_por_cta_bg_pre = 2131099923;
        public static final int mbridge_nativex_sound_bg = 2131099924;
        public static final int mbridge_purple_200 = 2131099925;
        public static final int mbridge_purple_500 = 2131099926;
        public static final int mbridge_purple_700 = 2131099927;
        public static final int mbridge_reward_black = 2131099928;
        public static final int mbridge_reward_cta_bg = 2131099929;
        public static final int mbridge_reward_desc_textcolor = 2131099930;
        public static final int mbridge_reward_endcard_hor_bg = 2131099931;
        public static final int mbridge_reward_endcard_land_bg = 2131099932;
        public static final int mbridge_reward_endcard_line_bg = 2131099933;
        public static final int mbridge_reward_endcard_vast_bg = 2131099934;
        public static final int mbridge_reward_kiloo_background = 2131099935;
        public static final int mbridge_reward_layer_text_bg = 2131099936;
        public static final int mbridge_reward_minicard_bg = 2131099937;
        public static final int mbridge_reward_six_black_transparent = 2131099938;
        public static final int mbridge_reward_six_black_transparent1 = 2131099939;
        public static final int mbridge_reward_six_black_transparent2 = 2131099940;
        public static final int mbridge_reward_title_textcolor = 2131099941;
        public static final int mbridge_reward_white = 2131099942;
        public static final int mbridge_splash_count_time_skip_text_color = 2131099943;
        public static final int mbridge_teal_200 = 2131099944;
        public static final int mbridge_teal_700 = 2131099945;
        public static final int mbridge_video_common_alertview_bg = 2131099946;
        public static final int mbridge_video_common_alertview_cancel_button_bg_default = 2131099947;
        public static final int mbridge_video_common_alertview_cancel_button_bg_pressed = 2131099948;
        public static final int mbridge_video_common_alertview_cancel_button_textcolor = 2131099949;
        public static final int mbridge_video_common_alertview_confirm_button_bg_default = 2131099950;
        public static final int mbridge_video_common_alertview_confirm_button_bg_pressed = 2131099951;
        public static final int mbridge_video_common_alertview_confirm_button_textcolor = 2131099952;
        public static final int mbridge_video_common_alertview_content_textcolor = 2131099953;
        public static final int mbridge_video_common_alertview_feedback_rb_bg = 2131099954;
        public static final int mbridge_video_common_alertview_title_textcolor = 2131099955;
        public static final int mbridge_white = 2131099956;
        public static final int notification_action_color_filter = 2131100008;
        public static final int notification_icon_bg_color = 2131100009;
        public static final int ripple_material_light = 2131100027;
        public static final int secondary_text_default_material_light = 2131100029;

        private color() {
        }
    }

    public static final class dimen {
        public static final int browser_actions_context_menu_max_width = 2131165312;
        public static final int browser_actions_context_menu_min_padding = 2131165313;
        public static final int compat_button_inset_horizontal_material = 2131165334;
        public static final int compat_button_inset_vertical_material = 2131165335;
        public static final int compat_button_padding_horizontal_material = 2131165336;
        public static final int compat_button_padding_vertical_material = 2131165337;
        public static final int compat_control_corner_material = 2131165338;
        public static final int compat_notification_large_icon_max_height = 2131165339;
        public static final int compat_notification_large_icon_max_width = 2131165340;
        public static final int mbridge_video_common_alertview_bg_padding = 2131165496;
        public static final int mbridge_video_common_alertview_button_height = 2131165497;
        public static final int mbridge_video_common_alertview_button_margintop = 2131165498;
        public static final int mbridge_video_common_alertview_button_radius = 2131165499;
        public static final int mbridge_video_common_alertview_button_textsize = 2131165500;
        public static final int mbridge_video_common_alertview_button_width = 2131165501;
        public static final int mbridge_video_common_alertview_content_margintop = 2131165502;
        public static final int mbridge_video_common_alertview_content_size = 2131165503;
        public static final int mbridge_video_common_alertview_contentview_maxwidth = 2131165504;
        public static final int mbridge_video_common_alertview_contentview_minwidth = 2131165505;
        public static final int mbridge_video_common_alertview_title_size = 2131165506;
        public static final int notification_action_icon_size = 2131165692;
        public static final int notification_action_text_size = 2131165693;
        public static final int notification_big_circle_margin = 2131165694;
        public static final int notification_content_margin_start = 2131165695;
        public static final int notification_large_icon_height = 2131165696;
        public static final int notification_large_icon_width = 2131165697;
        public static final int notification_main_column_padding_top = 2131165698;
        public static final int notification_media_narrow_margin = 2131165699;
        public static final int notification_right_icon_size = 2131165700;
        public static final int notification_right_side_padding_top = 2131165701;
        public static final int notification_small_icon_background_padding = 2131165702;
        public static final int notification_small_icon_size_as_large = 2131165703;
        public static final int notification_subtext_size = 2131165704;
        public static final int notification_top_pad = 2131165705;
        public static final int notification_top_pad_large_text = 2131165706;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int admob_close_button_black_circle_white_cross = 2131230817;
        public static final int admob_close_button_white_circle_black_cross = 2131230818;
        public static final int common_full_open_on_phone = 2131231001;
        public static final int common_google_signin_btn_icon_dark = 2131231002;
        public static final int common_google_signin_btn_icon_dark_focused = 2131231003;
        public static final int common_google_signin_btn_icon_dark_normal = 2131231004;
        public static final int common_google_signin_btn_icon_dark_normal_background = 2131231005;
        public static final int common_google_signin_btn_icon_disabled = 2131231006;
        public static final int common_google_signin_btn_icon_light = 2131231007;
        public static final int common_google_signin_btn_icon_light_focused = 2131231008;
        public static final int common_google_signin_btn_icon_light_normal = 2131231009;
        public static final int common_google_signin_btn_icon_light_normal_background = 2131231010;
        public static final int common_google_signin_btn_text_dark = 2131231011;
        public static final int common_google_signin_btn_text_dark_focused = 2131231012;
        public static final int common_google_signin_btn_text_dark_normal = 2131231013;
        public static final int common_google_signin_btn_text_dark_normal_background = 2131231014;
        public static final int common_google_signin_btn_text_disabled = 2131231015;
        public static final int common_google_signin_btn_text_light = 2131231016;
        public static final int common_google_signin_btn_text_light_focused = 2131231017;
        public static final int common_google_signin_btn_text_light_normal = 2131231018;
        public static final int common_google_signin_btn_text_light_normal_background = 2131231019;
        public static final int googleg_disabled_color_18 = 2131231052;
        public static final int googleg_standard_color_18 = 2131231053;
        public static final int mbridge_banner_close = 2131231113;
        public static final int mbridge_bottom_media_control = 2131231114;
        public static final int mbridge_cm_alertview_bg = 2131231115;
        public static final int mbridge_cm_alertview_cancel_bg = 2131231116;
        public static final int mbridge_cm_alertview_cancel_bg_nor = 2131231117;
        public static final int mbridge_cm_alertview_cancel_bg_pressed = 2131231118;
        public static final int mbridge_cm_alertview_confirm_bg = 2131231119;
        public static final int mbridge_cm_alertview_confirm_bg_nor = 2131231120;
        public static final int mbridge_cm_alertview_confirm_bg_pressed = 2131231121;
        public static final int mbridge_cm_backward = 2131231122;
        public static final int mbridge_cm_backward_disabled = 2131231123;
        public static final int mbridge_cm_backward_nor = 2131231124;
        public static final int mbridge_cm_backward_selected = 2131231125;
        public static final int mbridge_cm_btn_shake = 2131231126;
        public static final int mbridge_cm_circle_50black = 2131231127;
        public static final int mbridge_cm_end_animation = 2131231128;
        public static final int mbridge_cm_exits = 2131231129;
        public static final int mbridge_cm_exits_nor = 2131231130;
        public static final int mbridge_cm_exits_selected = 2131231131;
        public static final int mbridge_cm_feedback_btn_bg = 2131231132;
        public static final int mbridge_cm_feedback_choice_btn_bg = 2131231133;
        public static final int mbridge_cm_feedback_choice_btn_bg_nor = 2131231134;
        public static final int mbridge_cm_feedback_choice_btn_bg_pressed = 2131231135;
        public static final int mbridge_cm_feedback_dialog_view_bg = 2131231136;
        public static final int mbridge_cm_feedback_dialog_view_btn_bg = 2131231137;
        public static final int mbridge_cm_forward = 2131231138;
        public static final int mbridge_cm_forward_disabled = 2131231139;
        public static final int mbridge_cm_forward_nor = 2131231140;
        public static final int mbridge_cm_forward_selected = 2131231141;
        public static final int mbridge_cm_head = 2131231142;
        public static final int mbridge_cm_highlight = 2131231143;
        public static final int mbridge_cm_progress = 2131231144;
        public static final int mbridge_cm_progress_drawable = 2131231145;
        public static final int mbridge_cm_progress_icon = 2131231146;
        public static final int mbridge_cm_refresh = 2131231147;
        public static final int mbridge_cm_refresh_nor = 2131231148;
        public static final int mbridge_cm_refresh_selected = 2131231149;
        public static final int mbridge_cm_tail = 2131231150;
        public static final int mbridge_demo_star_nor = 2131231151;
        public static final int mbridge_demo_star_sel = 2131231152;
        public static final int mbridge_download_message_dialog_star_sel = 2131231153;
        public static final int mbridge_download_message_dilaog_star_nor = 2131231154;
        public static final int mbridge_finger_media_control = 2131231155;
        public static final int mbridge_icon_click_circle = 2131231156;
        public static final int mbridge_icon_click_hand = 2131231157;
        public static final int mbridge_icon_play_bg = 2131231158;
        public static final int mbridge_native_bg_loading_camera = 2131231161;
        public static final int mbridge_nativex_close = 2131231162;
        public static final int mbridge_nativex_cta_land_nor = 2131231163;
        public static final int mbridge_nativex_cta_land_pre = 2131231164;
        public static final int mbridge_nativex_cta_por_nor = 2131231165;
        public static final int mbridge_nativex_cta_por_pre = 2131231166;
        public static final int mbridge_nativex_full_land_close = 2131231167;
        public static final int mbridge_nativex_full_protial_close = 2131231168;
        public static final int mbridge_nativex_fullview_background = 2131231169;
        public static final int mbridge_nativex_pause = 2131231170;
        public static final int mbridge_nativex_play = 2131231171;
        public static final int mbridge_nativex_play_bg = 2131231172;
        public static final int mbridge_nativex_play_progress = 2131231173;
        public static final int mbridge_nativex_sound1 = 2131231174;
        public static final int mbridge_nativex_sound2 = 2131231175;
        public static final int mbridge_nativex_sound3 = 2131231176;
        public static final int mbridge_nativex_sound4 = 2131231177;
        public static final int mbridge_nativex_sound5 = 2131231178;
        public static final int mbridge_nativex_sound6 = 2131231179;
        public static final int mbridge_nativex_sound7 = 2131231180;
        public static final int mbridge_nativex_sound8 = 2131231181;
        public static final int mbridge_nativex_sound_animation = 2131231182;
        public static final int mbridge_nativex_sound_bg = 2131231183;
        public static final int mbridge_nativex_sound_close = 2131231184;
        public static final int mbridge_nativex_sound_open = 2131231185;
        public static final int mbridge_order_layout_list_bg = 2131231186;
        public static final int mbridge_reward_activity_ad_end_land_des_rl_hot = 2131231187;
        public static final int mbridge_reward_close = 2131231188;
        public static final int mbridge_reward_close_ec = 2131231189;
        public static final int mbridge_reward_end_close_shape_oval = 2131231190;
        public static final int mbridge_reward_end_land_shape = 2131231191;
        public static final int mbridge_reward_end_pager_logo = 2131231192;
        public static final int mbridge_reward_end_shape_oval = 2131231193;
        public static final int mbridge_reward_flag_cn = 2131231194;
        public static final int mbridge_reward_flag_en = 2131231195;
        public static final int mbridge_reward_more_offer_default_bg = 2131231196;
        public static final int mbridge_reward_notice = 2131231197;
        public static final int mbridge_reward_popview_close = 2131231198;
        public static final int mbridge_reward_shape_choice = 2131231199;
        public static final int mbridge_reward_shape_choice_rl = 2131231200;
        public static final int mbridge_reward_shape_end_pager = 2131231201;
        public static final int mbridge_reward_shape_mf_selector = 2131231202;
        public static final int mbridge_reward_shape_mof_like_normal = 2131231203;
        public static final int mbridge_reward_shape_mof_like_pressed = 2131231204;
        public static final int mbridge_reward_shape_order = 2131231205;
        public static final int mbridge_reward_shape_order_history = 2131231206;
        public static final int mbridge_reward_shape_progress = 2131231207;
        public static final int mbridge_reward_shape_videoend_buttonbg = 2131231208;
        public static final int mbridge_reward_sound_close = 2131231209;
        public static final int mbridge_reward_sound_open = 2131231210;
        public static final int mbridge_reward_two_title_arabia_land = 2131231211;
        public static final int mbridge_reward_two_title_arabia_por = 2131231212;
        public static final int mbridge_reward_two_title_en_land = 2131231213;
        public static final int mbridge_reward_two_title_en_por = 2131231214;
        public static final int mbridge_reward_two_title_france_land = 2131231215;
        public static final int mbridge_reward_two_title_france_por = 2131231216;
        public static final int mbridge_reward_two_title_germany_land = 2131231217;
        public static final int mbridge_reward_two_title_germany_por = 2131231218;
        public static final int mbridge_reward_two_title_japan_land = 2131231219;
        public static final int mbridge_reward_two_title_japan_por = 2131231220;
        public static final int mbridge_reward_two_title_korea_land = 2131231221;
        public static final int mbridge_reward_two_title_korea_por = 2131231222;
        public static final int mbridge_reward_two_title_russian_land = 2131231223;
        public static final int mbridge_reward_two_title_russian_por = 2131231224;
        public static final int mbridge_reward_two_title_zh = 2131231225;
        public static final int mbridge_reward_two_title_zh_trad = 2131231226;
        public static final int mbridge_reward_user = 2131231227;
        public static final int mbridge_reward_vast_end_close = 2131231228;
        public static final int mbridge_reward_vast_end_ok = 2131231229;
        public static final int mbridge_reward_video_icon = 2131231230;
        public static final int mbridge_reward_video_progress_bg = 2131231231;
        public static final int mbridge_reward_video_progressbar_bg = 2131231232;
        public static final int mbridge_reward_video_time_count_num_bg = 2131231233;
        public static final int mbridge_shape_btn = 2131231234;
        public static final int mbridge_shape_corners_bg = 2131231235;
        public static final int mbridge_shape_line = 2131231236;
        public static final int mbridge_shape_splash_circle_14 = 2131231237;
        public static final int mbridge_shape_splash_corners_14 = 2131231238;
        public static final int mbridge_shape_splash_rightbottom_corners_10 = 2131231239;
        public static final int mbridge_slide_hand = 2131231240;
        public static final int mbridge_slide_rightarrow = 2131231241;
        public static final int mbridge_splash_ad_right_bottom_corner_en = 2131231242;
        public static final int mbridge_splash_ad_right_bottom_corner_zh = 2131231243;
        public static final int mbridge_splash_adchoice = 2131231244;
        public static final int mbridge_splash_btn_arrow_right = 2131231245;
        public static final int mbridge_splash_btn_circle = 2131231246;
        public static final int mbridge_splash_btn_finger = 2131231247;
        public static final int mbridge_splash_btn_go = 2131231248;
        public static final int mbridge_splash_btn_light = 2131231249;
        public static final int mbridge_splash_button_bg_gray = 2131231250;
        public static final int mbridge_splash_button_bg_gray_55 = 2131231251;
        public static final int mbridge_splash_button_bg_green = 2131231252;
        public static final int mbridge_splash_close_bg = 2131231253;
        public static final int mbridge_splash_m_circle = 2131231254;
        public static final int mbridge_splash_notice = 2131231255;
        public static final int mbridge_splash_pop_ad = 2131231256;
        public static final int mbridge_splash_pop_ad_en = 2131231257;
        public static final int mbridge_splash_popview_close = 2131231258;
        public static final int mbridge_splash_popview_default = 2131231259;
        public static final int mbridge_video_common_full_star = 2131231260;
        public static final int mbridge_video_common_full_while_star = 2131231261;
        public static final int mbridge_video_common_half_star = 2131231262;
        public static final int notification_action_background = 2131231283;
        public static final int notification_bg = 2131231284;
        public static final int notification_bg_low = 2131231285;
        public static final int notification_bg_low_normal = 2131231286;
        public static final int notification_bg_low_pressed = 2131231287;
        public static final int notification_bg_normal = 2131231288;
        public static final int notification_bg_normal_pressed = 2131231289;
        public static final int notification_icon_background = 2131231290;
        public static final int notification_template_icon_bg = 2131231291;
        public static final int notification_template_icon_low_bg = 2131231292;
        public static final int notification_tile_bg = 2131231293;
        public static final int notify_panel_notification_icon_bg = 2131231294;

        private drawable() {
        }
    }

    public static final class id {
        public static final int accessibility_action_clickable_span = 2131361812;
        public static final int accessibility_custom_action_0 = 2131361813;
        public static final int accessibility_custom_action_1 = 2131361814;
        public static final int accessibility_custom_action_10 = 2131361815;
        public static final int accessibility_custom_action_11 = 2131361816;
        public static final int accessibility_custom_action_12 = 2131361817;
        public static final int accessibility_custom_action_13 = 2131361818;
        public static final int accessibility_custom_action_14 = 2131361819;
        public static final int accessibility_custom_action_15 = 2131361820;
        public static final int accessibility_custom_action_16 = 2131361821;
        public static final int accessibility_custom_action_17 = 2131361822;
        public static final int accessibility_custom_action_18 = 2131361823;
        public static final int accessibility_custom_action_19 = 2131361824;
        public static final int accessibility_custom_action_2 = 2131361825;
        public static final int accessibility_custom_action_20 = 2131361826;
        public static final int accessibility_custom_action_21 = 2131361827;
        public static final int accessibility_custom_action_22 = 2131361828;
        public static final int accessibility_custom_action_23 = 2131361829;
        public static final int accessibility_custom_action_24 = 2131361830;
        public static final int accessibility_custom_action_25 = 2131361831;
        public static final int accessibility_custom_action_26 = 2131361832;
        public static final int accessibility_custom_action_27 = 2131361833;
        public static final int accessibility_custom_action_28 = 2131361834;
        public static final int accessibility_custom_action_29 = 2131361835;
        public static final int accessibility_custom_action_3 = 2131361836;
        public static final int accessibility_custom_action_30 = 2131361837;
        public static final int accessibility_custom_action_31 = 2131361838;
        public static final int accessibility_custom_action_4 = 2131361839;
        public static final int accessibility_custom_action_5 = 2131361840;
        public static final int accessibility_custom_action_6 = 2131361841;
        public static final int accessibility_custom_action_7 = 2131361842;
        public static final int accessibility_custom_action_8 = 2131361843;
        public static final int accessibility_custom_action_9 = 2131361844;
        public static final int action_container = 2131361853;
        public static final int action_divider = 2131361855;
        public static final int action_image = 2131361856;
        public static final int action_text = 2131361863;
        public static final int actions = 2131361864;
        public static final int adjust_height = 2131361879;
        public static final int adjust_width = 2131361880;
        public static final int async = 2131361952;
        public static final int auto = 2131361954;
        public static final int blocking = 2131361976;
        public static final int bottom = 2131361980;
        public static final int browser_actions_header_text = 2131361987;
        public static final int browser_actions_menu_item_icon = 2131361988;
        public static final int browser_actions_menu_item_text = 2131361989;
        public static final int browser_actions_menu_items = 2131361990;
        public static final int browser_actions_menu_view = 2131361991;
        public static final int chronometer = 2131362019;
        public static final int dark = 2131362060;
        public static final int dialog_button = 2131362075;
        public static final int end = 2131362100;
        public static final int forever = 2131362146;
        public static final int icon = 2131362205;
        public static final int icon_group = 2131362206;
        public static final int icon_only = 2131362208;
        public static final int info = 2131362236;
        public static final int italic = 2131362259;
        public static final int item = 2131362260;
        public static final int layout = 2131362316;
        public static final int left = 2131362320;
        public static final int light = 2131362324;
        public static final int line1 = 2131362325;
        public static final int line3 = 2131362326;
        public static final int mbridge_animation_click_view = 2131362417;
        public static final int mbridge_bottom_finger_bg = 2131362418;
        public static final int mbridge_bottom_icon_iv = 2131362419;
        public static final int mbridge_bottom_item_rl = 2131362420;
        public static final int mbridge_bottom_iv = 2131362421;
        public static final int mbridge_bottom_play_bg = 2131362422;
        public static final int mbridge_bottom_ration = 2131362423;
        public static final int mbridge_bottom_title_tv = 2131362424;
        public static final int mbridge_bt_container = 2131362425;
        public static final int mbridge_bt_container_root = 2131362426;
        public static final int mbridge_center_view = 2131362427;
        public static final int mbridge_choice_frl = 2131362428;
        public static final int mbridge_choice_one_countdown_tv = 2131362429;
        public static final int mbridge_cta_layout = 2131362430;
        public static final int mbridge_ec_layout_center = 2131362431;
        public static final int mbridge_ec_layout_top = 2131362432;
        public static final int mbridge_full_animation_content = 2131362433;
        public static final int mbridge_full_animation_player = 2131362434;
        public static final int mbridge_full_iv_close = 2131362435;
        public static final int mbridge_full_pb_loading = 2131362436;
        public static final int mbridge_full_player_parent = 2131362437;
        public static final int mbridge_full_rl_close = 2131362438;
        public static final int mbridge_full_rl_playcontainer = 2131362439;
        public static final int mbridge_full_tv_display_content = 2131362440;
        public static final int mbridge_full_tv_display_description = 2131362441;
        public static final int mbridge_full_tv_display_icon = 2131362442;
        public static final int mbridge_full_tv_display_title = 2131362443;
        public static final int mbridge_full_tv_feeds_star = 2131362444;
        public static final int mbridge_full_tv_install = 2131362445;
        public static final int mbridge_interstitial_pb = 2131362447;
        public static final int mbridge_iv_adbanner = 2131362449;
        public static final int mbridge_iv_adbanner_bg = 2131362450;
        public static final int mbridge_iv_appicon = 2131362451;
        public static final int mbridge_iv_close = 2131362452;
        public static final int mbridge_iv_flag = 2131362453;
        public static final int mbridge_iv_icon = 2131362454;
        public static final int mbridge_iv_iconbg = 2131362455;
        public static final int mbridge_iv_link = 2131362456;
        public static final int mbridge_iv_logo = 2131362457;
        public static final int mbridge_iv_pause = 2131362458;
        public static final int mbridge_iv_play = 2131362459;
        public static final int mbridge_iv_playend_pic = 2131362460;
        public static final int mbridge_iv_sound = 2131362461;
        public static final int mbridge_iv_sound_animation = 2131362462;
        public static final int mbridge_iv_vastclose = 2131362463;
        public static final int mbridge_iv_vastok = 2131362464;
        public static final int mbridge_layout_bottomLayout = 2131362465;
        public static final int mbridge_ll_loading = 2131362466;
        public static final int mbridge_ll_playerview_container = 2131362467;
        public static final int mbridge_lv_desc_tv = 2131362468;
        public static final int mbridge_lv_icon_iv = 2131362469;
        public static final int mbridge_lv_item_rl = 2131362470;
        public static final int mbridge_lv_iv = 2131362471;
        public static final int mbridge_lv_iv_bg = 2131362472;
        public static final int mbridge_lv_iv_burl = 2131362473;
        public static final int mbridge_lv_iv_cover = 2131362474;
        public static final int mbridge_lv_sv_starlevel = 2131362475;
        public static final int mbridge_lv_title_tv = 2131362476;
        public static final int mbridge_lv_tv_install = 2131362477;
        public static final int mbridge_more_offer_ll_item = 2131362478;
        public static final int mbridge_moreoffer_hls = 2131362479;
        public static final int mbridge_my_big_img = 2131362480;
        public static final int mbridge_native_ec_controller = 2131362481;
        public static final int mbridge_native_ec_layer_layout = 2131362482;
        public static final int mbridge_native_ec_layout = 2131362483;
        public static final int mbridge_native_endcard_feed_btn = 2131362484;
        public static final int mbridge_native_order_camp_controller = 2131362485;
        public static final int mbridge_native_order_camp_feed_btn = 2131362486;
        public static final int mbridge_native_pb = 2131362487;
        public static final int mbridge_native_rl_root = 2131362488;
        public static final int mbridge_nativex_webview_layout = 2131362489;
        public static final int mbridge_nativex_webview_layout_webview = 2131362490;
        public static final int mbridge_order_view_h_lv = 2131362491;
        public static final int mbridge_order_view_iv_close = 2131362492;
        public static final int mbridge_order_view_lv = 2131362493;
        public static final int mbridge_order_viewed_tv = 2131362494;
        public static final int mbridge_playercommon_ll_loading = 2131362495;
        public static final int mbridge_playercommon_ll_sur_container = 2131362496;
        public static final int mbridge_playercommon_rl_root = 2131362497;
        public static final int mbridge_progress = 2131362498;
        public static final int mbridge_progressBar = 2131362499;
        public static final int mbridge_progressBar1 = 2131362500;
        public static final int mbridge_reward_bottom_widget = 2131362501;
        public static final int mbridge_reward_choice_one_like_iv = 2131362502;
        public static final int mbridge_reward_click_tv = 2131362503;
        public static final int mbridge_reward_cta_layout = 2131362504;
        public static final int mbridge_reward_desc_tv = 2131362505;
        public static final int mbridge_reward_end_card_item_iv = 2131362506;
        public static final int mbridge_reward_end_card_item_title_tv = 2131362507;
        public static final int mbridge_reward_end_card_like_tv = 2131362508;
        public static final int mbridge_reward_end_card_more_offer_rl = 2131362509;
        public static final int mbridge_reward_end_card_offer_title_rl = 2131362510;
        public static final int mbridge_reward_icon_riv = 2131362511;
        public static final int mbridge_reward_logo_iv = 2131362512;
        public static final int mbridge_reward_popview = 2131362513;
        public static final int mbridge_reward_root_container = 2131362514;
        public static final int mbridge_reward_segment_progressbar = 2131362515;
        public static final int mbridge_reward_stars_mllv = 2131362516;
        public static final int mbridge_reward_title_tv = 2131362517;
        public static final int mbridge_rl_content = 2131362518;
        public static final int mbridge_rl_mediaview_root = 2131362519;
        public static final int mbridge_rl_playing_close = 2131362520;
        public static final int mbridge_sound_switch = 2131362521;
        public static final int mbridge_splash_feedback = 2131362522;
        public static final int mbridge_splash_iv_foregroundimage = 2131362523;
        public static final int mbridge_splash_iv_icon = 2131362524;
        public static final int mbridge_splash_iv_image = 2131362525;
        public static final int mbridge_splash_iv_image_bg = 2131362526;
        public static final int mbridge_splash_iv_link = 2131362527;
        public static final int mbridge_splash_landscape_foreground = 2131362528;
        public static final int mbridge_splash_layout_appinfo = 2131362529;
        public static final int mbridge_splash_layout_foreground = 2131362530;
        public static final int mbridge_splash_topcontroller = 2131362531;
        public static final int mbridge_splash_tv_adcircle = 2131362532;
        public static final int mbridge_splash_tv_adrect = 2131362533;
        public static final int mbridge_splash_tv_appinfo = 2131362534;
        public static final int mbridge_splash_tv_click = 2131362535;
        public static final int mbridge_splash_tv_permission = 2131362536;
        public static final int mbridge_splash_tv_privacy = 2131362537;
        public static final int mbridge_splash_tv_skip = 2131362538;
        public static final int mbridge_splash_tv_title = 2131362539;
        public static final int mbridge_sv_starlevel = 2131362540;
        public static final int mbridge_tag_icon = 2131362541;
        public static final int mbridge_tag_title = 2131362542;
        public static final int mbridge_temp_container = 2131362543;
        public static final int mbridge_textView = 2131362544;
        public static final int mbridge_text_layout = 2131362545;
        public static final int mbridge_textureview = 2131362546;
        public static final int mbridge_title_layout = 2131362547;
        public static final int mbridge_top_control = 2131362548;
        public static final int mbridge_top_finger_bg = 2131362549;
        public static final int mbridge_top_icon_iv = 2131362550;
        public static final int mbridge_top_item_rl = 2131362551;
        public static final int mbridge_top_iv = 2131362552;
        public static final int mbridge_top_play_bg = 2131362553;
        public static final int mbridge_top_ration = 2131362554;
        public static final int mbridge_top_title_tv = 2131362555;
        public static final int mbridge_tv_appdesc = 2131362556;
        public static final int mbridge_tv_apptitle = 2131362557;
        public static final int mbridge_tv_count = 2131362558;
        public static final int mbridge_tv_cta = 2131362559;
        public static final int mbridge_tv_desc = 2131362560;
        public static final int mbridge_tv_install = 2131362561;
        public static final int mbridge_tv_number = 2131362562;
        public static final int mbridge_tv_number_layout = 2131362563;
        public static final int mbridge_tv_reward_status = 2131362564;
        public static final int mbridge_tv_title = 2131362565;
        public static final int mbridge_tv_vasttag = 2131362566;
        public static final int mbridge_tv_vasttitle = 2131362567;
        public static final int mbridge_vec_btn = 2131362568;
        public static final int mbridge_vec_iv_close = 2131362569;
        public static final int mbridge_vec_iv_icon = 2131362570;
        public static final int mbridge_vec_tv_desc = 2131362571;
        public static final int mbridge_vec_tv_title = 2131362572;
        public static final int mbridge_vfpv = 2131362573;
        public static final int mbridge_vfpv_fl = 2131362574;
        public static final int mbridge_video_common_alertview_cancel_button = 2131362575;
        public static final int mbridge_video_common_alertview_confirm_button = 2131362576;
        public static final int mbridge_video_common_alertview_contentview = 2131362577;
        public static final int mbridge_video_common_alertview_contentview_scrollview = 2131362578;
        public static final int mbridge_video_common_alertview_private_action_button = 2131362579;
        public static final int mbridge_video_common_alertview_titleview = 2131362580;
        public static final int mbridge_video_progress_bar = 2131362581;
        public static final int mbridge_video_templete_container = 2131362582;
        public static final int mbridge_video_templete_progressbar = 2131362583;
        public static final int mbridge_video_templete_videoview = 2131362584;
        public static final int mbridge_video_templete_webview_parent = 2131362585;
        public static final int mbridge_videoview_bg = 2131362586;
        public static final int mbridge_view_cover = 2131362587;
        public static final int mbridge_viewgroup_ctaroot = 2131362588;
        public static final int mbridge_windwv_close = 2131362589;
        public static final int mbridge_windwv_content_rl = 2131362590;
        public static final int none = 2131362660;
        public static final int normal = 2131362661;
        public static final int notification_background = 2131362662;
        public static final int notification_main_column = 2131362663;
        public static final int notification_main_column_container = 2131362664;
        public static final int right = 2131362735;
        public static final int right_icon = 2131362737;
        public static final int right_side = 2131362738;
        public static final int standard = 2131362841;
        public static final int start = 2131362842;
        public static final int tag_accessibility_actions = 2131362860;
        public static final int tag_accessibility_clickable_spans = 2131362861;
        public static final int tag_accessibility_heading = 2131362862;
        public static final int tag_accessibility_pane_title = 2131362863;
        public static final int tag_on_apply_window_listener = 2131362866;
        public static final int tag_on_receive_content_listener = 2131362867;
        public static final int tag_on_receive_content_mime_types = 2131362868;
        public static final int tag_screen_reader_focusable = 2131362869;
        public static final int tag_state_description = 2131362870;
        public static final int tag_transition_group = 2131362871;
        public static final int tag_unhandled_key_event_manager = 2131362872;
        public static final int tag_unhandled_key_listeners = 2131362873;
        public static final int tag_window_insets_animation_callback = 2131362874;
        public static final int text = 2131362884;
        public static final int text2 = 2131362885;
        public static final int time = 2131362906;
        public static final int title = 2131362907;
        public static final int top = 2131362914;
        public static final int wide = 2131363427;

        private id() {
        }
    }

    public static final class integer {
        public static final int google_play_services_version = 2131427338;
        public static final int status_bar_notification_info_maxnum = 2131427353;

        private integer() {
        }
    }

    public static final class layout {
        public static final int admob_empty_layout = 2131558449;
        public static final int browser_actions_context_menu_page = 2131558464;
        public static final int browser_actions_context_menu_row = 2131558465;
        public static final int custom_dialog = 2131558475;
        public static final int loading_alert = 2131558582;
        public static final int mbridge_bt_container = 2131558609;
        public static final int mbridge_cm_alertview = 2131558610;
        public static final int mbridge_cm_feedback_notice_layout = 2131558611;
        public static final int mbridge_cm_feedbackview = 2131558612;
        public static final int mbridge_cm_loading_layout = 2131558613;
        public static final int mbridge_more_offer_activity = 2131558615;
        public static final int mbridge_nativex_fullbasescreen = 2131558616;
        public static final int mbridge_nativex_fullscreen_top = 2131558617;
        public static final int mbridge_nativex_mbmediaview = 2131558618;
        public static final int mbridge_nativex_playerview = 2131558619;
        public static final int mbridge_order_layout_item = 2131558620;
        public static final int mbridge_order_layout_list_landscape = 2131558621;
        public static final int mbridge_order_layout_list_portrait = 2131558622;
        public static final int mbridge_playercommon_player_view = 2131558623;
        public static final int mbridge_reward_activity_video_templete = 2131558624;
        public static final int mbridge_reward_activity_video_templete_transparent = 2131558625;
        public static final int mbridge_reward_clickable_cta = 2131558626;
        public static final int mbridge_reward_end_card_layout_landscape = 2131558627;
        public static final int mbridge_reward_end_card_layout_portrait = 2131558628;
        public static final int mbridge_reward_end_card_more_offer_item = 2131558629;
        public static final int mbridge_reward_endcard_h5 = 2131558630;
        public static final int mbridge_reward_endcard_native_half_landscape = 2131558631;
        public static final int mbridge_reward_endcard_native_half_portrait = 2131558632;
        public static final int mbridge_reward_endcard_native_hor = 2131558633;
        public static final int mbridge_reward_endcard_native_land = 2131558634;
        public static final int mbridge_reward_endcard_vast = 2131558635;
        public static final int mbridge_reward_layer_floor = 2131558636;
        public static final int mbridge_reward_layer_floor_302 = 2131558637;
        public static final int mbridge_reward_layer_floor_802 = 2131558638;
        public static final int mbridge_reward_layer_floor_904 = 2131558639;
        public static final int mbridge_reward_layer_floor_bottom = 2131558640;
        public static final int mbridge_reward_more_offer_view = 2131558641;
        public static final int mbridge_reward_videoend_cover = 2131558642;
        public static final int mbridge_reward_videoview_item = 2131558643;
        public static final int mbridge_reward_view_tag_item = 2131558644;
        public static final int mbridge_same_choice_one_layout_landscape = 2131558645;
        public static final int mbridge_same_choice_one_layout_portrait = 2131558646;
        public static final int mbridge_splash_landscape = 2131558647;
        public static final int mbridge_splash_portrait = 2131558648;
        public static final int notification_action = 2131558694;
        public static final int notification_action_tombstone = 2131558695;
        public static final int notification_template_custom_big = 2131558702;
        public static final int notification_template_icon_group = 2131558703;
        public static final int notification_template_part_chronometer = 2131558707;
        public static final int notification_template_part_time = 2131558708;

        private layout() {
        }
    }

    public static final class string {
        public static final int androidx_startup = 2131886164;
        public static final int campaign_appName = 2131886181;
        public static final int campaign_iconUrl = 2131886182;
        public static final int campaign_imageUrl = 2131886183;
        public static final int common_google_play_services_enable_button = 2131886215;
        public static final int common_google_play_services_enable_text = 2131886216;
        public static final int common_google_play_services_enable_title = 2131886217;
        public static final int common_google_play_services_install_button = 2131886218;
        public static final int common_google_play_services_install_text = 2131886219;
        public static final int common_google_play_services_install_title = 2131886220;
        public static final int common_google_play_services_notification_channel_name = 2131886221;
        public static final int common_google_play_services_notification_ticker = 2131886222;
        public static final int common_google_play_services_unknown_issue = 2131886223;
        public static final int common_google_play_services_unsupported_text = 2131886224;
        public static final int common_google_play_services_update_button = 2131886225;
        public static final int common_google_play_services_update_text = 2131886226;
        public static final int common_google_play_services_update_title = 2131886227;
        public static final int common_google_play_services_updating_text = 2131886228;
        public static final int common_google_play_services_wear_update_text = 2131886229;
        public static final int common_open_on_phone = 2131886230;
        public static final int common_signin_button_text = 2131886231;
        public static final int common_signin_button_text_long = 2131886232;
        public static final int copy_toast_msg = 2131886233;
        public static final int defaults = 2131886244;
        public static final int dyAction_getClick = 2131886250;
        public static final int dyAction_getLogicClick = 2131886251;
        public static final int dyAction_getLongClick = 2131886252;
        public static final int dyAction_getMove = 2131886253;
        public static final int dyAction_getWobble = 2131886254;
        public static final int dyEffect_getCountDown = 2131886255;
        public static final int dyEffect_getVisible = 2131886256;
        public static final int dyEffect_getVisibleParam = 2131886257;
        public static final int dyEffect_getWobble = 2131886258;
        public static final int dyStrategy_feedback = 2131886259;
        public static final int dyStrategy_getActivity = 2131886260;
        public static final int dyStrategy_getClose = 2131886261;
        public static final int dyStrategy_getDeeplink = 2131886262;
        public static final int dyStrategy_getDownload = 2131886263;
        public static final int dyStrategy_notice = 2131886264;
        public static final int dyStrategy_permissionInfo = 2131886265;
        public static final int dyStrategy_privateAddress = 2131886266;
        public static final int fallback_menu_item_copy_link = 2131886273;
        public static final int fallback_menu_item_open_in_browser = 2131886274;
        public static final int fallback_menu_item_share_link = 2131886275;
        public static final int mSplashData_setAdClickText = 2131886301;
        public static final int mSplashData_setAppInfo = 2131886302;
        public static final int mSplashData_setCountDownText = 2131886303;
        public static final int mSplashData_setLogoImage = 2131886304;
        public static final int mSplashData_setLogoText = 2131886305;
        public static final int mSplashData_setNoticeImage = 2131886306;
        public static final int mbridge_cm_feedback_btn_text = 2131886322;
        public static final int mbridge_cm_feedback_dialog_close_close = 2131886323;
        public static final int mbridge_cm_feedback_dialog_close_submit = 2131886324;
        public static final int mbridge_cm_feedback_dialog_content_fraud = 2131886325;
        public static final int mbridge_cm_feedback_dialog_content_misleading = 2131886326;
        public static final int mbridge_cm_feedback_dialog_content_not_play = 2131886327;
        public static final int mbridge_cm_feedback_dialog_content_other = 2131886328;
        public static final int mbridge_cm_feedback_dialog_content_por_violence = 2131886329;
        public static final int mbridge_cm_feedback_dialog_content_sound_problems = 2131886330;
        public static final int mbridge_cm_feedback_dialog_privacy_des = 2131886331;
        public static final int mbridge_cm_feedback_dialog_submit_notice = 2131886332;
        public static final int mbridge_cm_feedback_dialog_title = 2131886333;
        public static final int mbridge_reward_appdesc = 2131886334;
        public static final int mbridge_reward_apptitle = 2131886335;
        public static final int mbridge_reward_clickable_cta_btntext = 2131886336;
        public static final int mbridge_reward_endcard_ad = 2131886337;
        public static final int mbridge_reward_endcard_vast_notice = 2131886338;
        public static final int mbridge_reward_heat_count_unit = 2131886339;
        public static final int mbridge_reward_install = 2131886340;
        public static final int mbridge_reward_video_view_reward_time_complete = 2131886341;
        public static final int mbridge_reward_video_view_reward_time_left = 2131886342;
        public static final int mbridge_reward_viewed_text_str = 2131886343;
        public static final int mbridge_splash_count_time_can_skip = 2131886344;
        public static final int mbridge_splash_count_time_can_skip_not = 2131886345;
        public static final int mbridge_splash_count_time_can_skip_s = 2131886346;
        public static final int native_body = 2131886386;
        public static final int native_headline = 2131886387;
        public static final int native_media_view = 2131886388;
        public static final int notifications_permission_confirm = 2131886390;
        public static final int notifications_permission_decline = 2131886391;
        public static final int notifications_permission_title = 2131886392;
        public static final int offline_notification_text = 2131886393;
        public static final int offline_notification_title = 2131886394;
        public static final int offline_opt_in_confirm = 2131886395;
        public static final int offline_opt_in_confirmation = 2131886396;
        public static final int offline_opt_in_decline = 2131886397;
        public static final int offline_opt_in_message = 2131886398;
        public static final int offline_opt_in_title = 2131886399;

        /* renamed from: s1  reason: collision with root package name */
        public static final int f13387s1 = 2131886447;

        /* renamed from: s2  reason: collision with root package name */
        public static final int f13388s2 = 2131886448;

        /* renamed from: s3  reason: collision with root package name */
        public static final int f13389s3 = 2131886449;

        /* renamed from: s4  reason: collision with root package name */
        public static final int f13390s4 = 2131886450;

        /* renamed from: s5  reason: collision with root package name */
        public static final int f13391s5 = 2131886451;

        /* renamed from: s6  reason: collision with root package name */
        public static final int f13392s6 = 2131886452;

        /* renamed from: s7  reason: collision with root package name */
        public static final int f13393s7 = 2131886453;
        public static final int status_bar_notification_info_overflow = 2131886481;
        public static final int watermark_label_prefix = 2131886641;

        private string() {
        }
    }

    public static final class style {
        public static final int AppBaseTheme = 2131951624;
        public static final int MBridgeAppTheme = 2131951907;
        public static final int TextAppearance_Compat_Notification = 2131952048;
        public static final int TextAppearance_Compat_Notification_Info = 2131952049;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131952051;
        public static final int TextAppearance_Compat_Notification_Time = 2131952054;
        public static final int TextAppearance_Compat_Notification_Title = 2131952056;
        public static final int Theme_IAPTheme = 2131952117;
        public static final int Widget_Compat_NotificationActionContainer = 2131952296;
        public static final int Widget_Compat_NotificationActionText = 2131952297;
        public static final int Widget_Support_CoordinatorLayout = 2131952423;
        public static final int mbridge_common_activity_style = 2131952477;
        public static final int mbridge_reward_theme = 2131952478;
        public static final int mbridge_transparent_common_activity_style = 2131952479;
        public static final int mbridge_transparent_theme = 2131952480;
        public static final int myDialog = 2131952481;

        private style() {
        }
    }

    public static final class styleable {
        public static final int[] AdsAttrs = {com.crazyhero.android.R.attr.adSize, com.crazyhero.android.R.attr.adSizes, com.crazyhero.android.R.attr.adUnitId};
        public static final int AdsAttrs_adSize = 0;
        public static final int AdsAttrs_adSizes = 1;
        public static final int AdsAttrs_adUnitId = 2;
        public static final int[] Capability = {com.crazyhero.android.R.attr.queryPatterns, com.crazyhero.android.R.attr.shortcutMatchRequired};
        public static final int Capability_queryPatterns = 0;
        public static final int Capability_shortcutMatchRequired = 1;
        public static final int[] ColorStateListItem = {16843173, 16843551, 16844359, com.crazyhero.android.R.attr.alpha, com.crazyhero.android.R.attr.lStar};
        public static final int ColorStateListItem_alpha = 3;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int ColorStateListItem_android_lStar = 2;
        public static final int ColorStateListItem_lStar = 4;
        public static final int[] CoordinatorLayout = {com.crazyhero.android.R.attr.keylines, com.crazyhero.android.R.attr.statusBarBackground};
        public static final int[] CoordinatorLayout_Layout = {16842931, com.crazyhero.android.R.attr.layout_anchor, com.crazyhero.android.R.attr.layout_anchorGravity, com.crazyhero.android.R.attr.layout_behavior, com.crazyhero.android.R.attr.layout_dodgeInsetEdges, com.crazyhero.android.R.attr.layout_insetEdge, com.crazyhero.android.R.attr.layout_keyline};
        public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
        public static final int CoordinatorLayout_Layout_layout_anchor = 1;
        public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
        public static final int CoordinatorLayout_Layout_layout_behavior = 3;
        public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
        public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
        public static final int CoordinatorLayout_Layout_layout_keyline = 6;
        public static final int CoordinatorLayout_keylines = 0;
        public static final int CoordinatorLayout_statusBarBackground = 1;
        public static final int[] FontFamily = {com.crazyhero.android.R.attr.fontProviderAuthority, com.crazyhero.android.R.attr.fontProviderCerts, com.crazyhero.android.R.attr.fontProviderFetchStrategy, com.crazyhero.android.R.attr.fontProviderFetchTimeout, com.crazyhero.android.R.attr.fontProviderPackage, com.crazyhero.android.R.attr.fontProviderQuery, com.crazyhero.android.R.attr.fontProviderSystemFontFamily};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, com.crazyhero.android.R.attr.font, com.crazyhero.android.R.attr.fontStyle, com.crazyhero.android.R.attr.fontVariationSettings, com.crazyhero.android.R.attr.fontWeight, com.crazyhero.android.R.attr.ttcIndex};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int FontFamily_fontProviderSystemFontFamily = 6;
        public static final int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = {16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;
        public static final int[] LoadingImageView = {com.crazyhero.android.R.attr.circleCrop, com.crazyhero.android.R.attr.imageAspectRatio, com.crazyhero.android.R.attr.imageAspectRatioAdjust};
        public static final int LoadingImageView_circleCrop = 0;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 2;
        public static final int[] RoundRectImageView = {com.crazyhero.android.R.attr.corner};
        public static final int RoundRectImageView_corner = 0;
        public static final int[] SignInButton = {com.crazyhero.android.R.attr.buttonSize, com.crazyhero.android.R.attr.button_style, com.crazyhero.android.R.attr.colorScheme, com.crazyhero.android.R.attr.scopeUris, com.crazyhero.android.R.attr.text};
        public static final int SignInButton_buttonSize = 0;
        public static final int SignInButton_button_style = 1;
        public static final int SignInButton_colorScheme = 2;
        public static final int SignInButton_scopeUris = 3;
        public static final int SignInButton_text = 4;

        private styleable() {
        }
    }

    public static final class xml {
        public static final int image_share_filepaths = 2132082695;

        private xml() {
        }
    }

    private R() {
    }
}
