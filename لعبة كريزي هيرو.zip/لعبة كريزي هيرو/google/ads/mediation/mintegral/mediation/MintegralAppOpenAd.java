package com.google.ads.mediation.mintegral.mediation;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import com.google.ads.mediation.mintegral.MintegralConstants;
import com.google.ads.mediation.mintegral.MintegralMediationAdapter;
import com.google.ads.mediation.mintegral.MintegralSplashAdWrapper;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationAppOpenAd;
import com.google.android.gms.ads.mediation.MediationAppOpenAdCallback;
import com.google.android.gms.ads.mediation.MediationAppOpenAdConfiguration;
import com.mbridge.msdk.out.MBSplashLoadWithCodeListener;
import com.mbridge.msdk.out.MBSplashShowListener;
import com.mbridge.msdk.out.MBridgeIds;

public abstract class MintegralAppOpenAd extends MBSplashLoadWithCodeListener implements MediationAppOpenAd, MBSplashShowListener {
    public Activity activity;
    public final MediationAppOpenAdConfiguration adConfiguration;
    public final MediationAdLoadCallback<MediationAppOpenAd, MediationAppOpenAdCallback> adLoadCallback;
    public MediationAppOpenAdCallback appOpenAdCallback;
    public MintegralSplashAdWrapper splashAdWrapper;

    public MintegralAppOpenAd(@NonNull MediationAppOpenAdConfiguration mediationAppOpenAdConfiguration, @NonNull MediationAdLoadCallback<MediationAppOpenAd, MediationAppOpenAdCallback> mediationAdLoadCallback) {
        this.adConfiguration = mediationAppOpenAdConfiguration;
        this.adLoadCallback = mediationAdLoadCallback;
    }

    public void isSupportZoomOut(MBridgeIds mBridgeIds, boolean z10) {
    }

    public abstract void loadAd();

    public void onAdClicked(MBridgeIds mBridgeIds) {
        MediationAppOpenAdCallback mediationAppOpenAdCallback = this.appOpenAdCallback;
        if (mediationAppOpenAdCallback != null) {
            mediationAppOpenAdCallback.reportAdClicked();
        }
    }

    public void onAdTick(MBridgeIds mBridgeIds, long j10) {
    }

    public void onDismiss(MBridgeIds mBridgeIds, int i10) {
        MediationAppOpenAdCallback mediationAppOpenAdCallback = this.appOpenAdCallback;
        if (mediationAppOpenAdCallback != null) {
            mediationAppOpenAdCallback.onAdClosed();
        }
        MintegralSplashAdWrapper mintegralSplashAdWrapper = this.splashAdWrapper;
        if (mintegralSplashAdWrapper != null) {
            mintegralSplashAdWrapper.onDestroy();
        }
    }

    public void onLoadFailedWithCode(MBridgeIds mBridgeIds, int i10, String str, int i11) {
        AdError createSdkError = MintegralConstants.createSdkError(i10, str);
        Log.d(MintegralMediationAdapter.TAG, createSdkError.toString());
        this.adLoadCallback.onFailure(createSdkError);
    }

    public void onLoadSuccessed(MBridgeIds mBridgeIds, int i10) {
        this.appOpenAdCallback = this.adLoadCallback.onSuccess(this);
    }

    public void onShowFailed(MBridgeIds mBridgeIds, String str) {
        if (this.appOpenAdCallback != null) {
            AdError createSdkError = MintegralConstants.createSdkError(100, str);
            Log.w(MintegralMediationAdapter.TAG, createSdkError.toString());
            this.appOpenAdCallback.onAdFailedToShow(createSdkError);
        }
    }

    public void onShowSuccessed(MBridgeIds mBridgeIds) {
        MediationAppOpenAdCallback mediationAppOpenAdCallback = this.appOpenAdCallback;
        if (mediationAppOpenAdCallback != null) {
            mediationAppOpenAdCallback.onAdOpened();
            this.appOpenAdCallback.reportAdImpression();
        }
    }

    public void onZoomOutPlayFinish(MBridgeIds mBridgeIds) {
    }

    public void onZoomOutPlayStart(MBridgeIds mBridgeIds) {
    }

    public void showAd(@NonNull Context context) {
        if (this.splashAdWrapper != null) {
            RelativeLayout relativeLayout = new RelativeLayout(this.activity);
            ((ViewGroup) this.activity.getWindow().getDecorView().findViewById(16908290)).addView(relativeLayout);
            this.splashAdWrapper.show(relativeLayout);
        }
    }
}
