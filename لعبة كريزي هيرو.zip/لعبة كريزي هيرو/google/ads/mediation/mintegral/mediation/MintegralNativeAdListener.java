package com.google.ads.mediation.mintegral.mediation;

import android.util.Log;
import androidx.annotation.NonNull;
import com.google.ads.mediation.mintegral.MintegralConstants;
import com.google.ads.mediation.mintegral.MintegralMediationAdapter;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationNativeAdCallback;
import com.google.android.gms.ads.mediation.UnifiedNativeAdMapper;
import com.mbridge.msdk.out.Campaign;
import com.mbridge.msdk.out.Frame;
import com.mbridge.msdk.out.NativeAdWithCodeListener;
import java.util.List;

public class MintegralNativeAdListener extends NativeAdWithCodeListener {
    public MediationAdLoadCallback<UnifiedNativeAdMapper, MediationNativeAdCallback> adLoadCallback;
    private MintegralNativeAd mintegralNativeAd;
    public MediationNativeAdCallback nativeCallback;

    public MintegralNativeAdListener(@NonNull MintegralNativeAd mintegralNativeAd2) {
        this.mintegralNativeAd = mintegralNativeAd2;
        this.nativeCallback = mintegralNativeAd2.nativeCallback;
        this.adLoadCallback = mintegralNativeAd2.adLoadCallback;
    }

    public void onAdClick(Campaign campaign) {
        MediationNativeAdCallback mediationNativeAdCallback = this.nativeCallback;
        if (mediationNativeAdCallback != null) {
            mediationNativeAdCallback.reportAdClicked();
            this.nativeCallback.onAdLeftApplication();
        }
    }

    public void onAdFramesLoaded(List<Frame> list) {
    }

    public void onAdLoadErrorWithCode(int i10, String str) {
        AdError createSdkError = MintegralConstants.createSdkError(i10, str);
        Log.w(MintegralMediationAdapter.TAG, createSdkError.toString());
        this.adLoadCallback.onFailure(createSdkError);
    }

    public void onAdLoaded(List<Campaign> list, int i10) {
        if (list == null || list.size() == 0) {
            AdError createAdapterError = MintegralConstants.createAdapterError(104, "Mintegral SDK failed to return a native ad.");
            Log.w(MintegralMediationAdapter.TAG, createAdapterError.toString());
            this.adLoadCallback.onFailure(createAdapterError);
            return;
        }
        this.mintegralNativeAd.mapNativeAd(list.get(0));
        this.nativeCallback = this.adLoadCallback.onSuccess(this.mintegralNativeAd);
    }

    public void onLoggingImpression(int i10) {
        MediationNativeAdCallback mediationNativeAdCallback = this.nativeCallback;
        if (mediationNativeAdCallback != null) {
            mediationNativeAdCallback.reportAdImpression();
        }
    }
}
