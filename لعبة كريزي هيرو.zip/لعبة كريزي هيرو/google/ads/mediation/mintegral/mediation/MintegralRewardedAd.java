package com.google.ads.mediation.mintegral.mediation;

import android.util.Log;
import androidx.annotation.NonNull;
import com.google.ads.mediation.mintegral.MintegralConstants;
import com.google.ads.mediation.mintegral.MintegralMediationAdapter;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationRewardedAd;
import com.google.android.gms.ads.mediation.MediationRewardedAdCallback;
import com.google.android.gms.ads.mediation.MediationRewardedAdConfiguration;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.mbridge.msdk.out.MBridgeIds;
import com.mbridge.msdk.out.RewardInfo;
import com.mbridge.msdk.out.RewardVideoWithCodeListener;

public abstract class MintegralRewardedAd extends RewardVideoWithCodeListener implements MediationRewardedAd {
    public final MediationRewardedAdConfiguration adConfiguration;
    public final MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback> adLoadCallback;
    public MediationRewardedAdCallback rewardedAdCallback;

    public class a implements RewardItem {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ RewardInfo f13394a;

        public a(MintegralRewardedAd mintegralRewardedAd, RewardInfo rewardInfo) {
            this.f13394a = rewardInfo;
        }

        public int getAmount() {
            try {
                return Integer.getInteger(this.f13394a.getRewardAmount()).intValue();
            } catch (Exception e10) {
                Log.w(MintegralMediationAdapter.TAG, "Failed to get reward amount.", e10);
                return 0;
            }
        }

        @NonNull
        public String getType() {
            return this.f13394a.getRewardName();
        }
    }

    public MintegralRewardedAd(@NonNull MediationRewardedAdConfiguration mediationRewardedAdConfiguration, @NonNull MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback> mediationAdLoadCallback) {
        this.adConfiguration = mediationRewardedAdConfiguration;
        this.adLoadCallback = mediationAdLoadCallback;
    }

    public abstract void loadAd();

    public void onAdClose(MBridgeIds mBridgeIds, RewardInfo rewardInfo) {
        if (this.rewardedAdCallback != null) {
            if (rewardInfo == null || !rewardInfo.isCompleteView()) {
                Log.w(MintegralMediationAdapter.TAG, "Mintegral SDK failed to reward user due to missing rewarded settings or rewarded ad playback not completed.");
            } else {
                this.rewardedAdCallback.onUserEarnedReward(new a(this, rewardInfo));
            }
            this.rewardedAdCallback.onAdClosed();
        }
    }

    public void onAdShow(MBridgeIds mBridgeIds) {
        MediationRewardedAdCallback mediationRewardedAdCallback = this.rewardedAdCallback;
        if (mediationRewardedAdCallback != null) {
            mediationRewardedAdCallback.onAdOpened();
            this.rewardedAdCallback.reportAdImpression();
        }
    }

    public void onEndcardShow(MBridgeIds mBridgeIds) {
    }

    public void onLoadSuccess(MBridgeIds mBridgeIds) {
    }

    public void onShowFailWithCode(MBridgeIds mBridgeIds, int i10, String str) {
        AdError createSdkError = MintegralConstants.createSdkError(i10, str);
        Log.w(MintegralMediationAdapter.TAG, createSdkError.toString());
        MediationRewardedAdCallback mediationRewardedAdCallback = this.rewardedAdCallback;
        if (mediationRewardedAdCallback != null) {
            mediationRewardedAdCallback.onAdFailedToShow(createSdkError);
        }
    }

    public void onVideoAdClicked(MBridgeIds mBridgeIds) {
        MediationRewardedAdCallback mediationRewardedAdCallback = this.rewardedAdCallback;
        if (mediationRewardedAdCallback != null) {
            mediationRewardedAdCallback.reportAdClicked();
        }
    }

    public void onVideoComplete(MBridgeIds mBridgeIds) {
    }

    public void onVideoLoadFailWithCode(MBridgeIds mBridgeIds, int i10, String str) {
        AdError createSdkError = MintegralConstants.createSdkError(i10, str);
        Log.w(MintegralMediationAdapter.TAG, createSdkError.toString());
        this.adLoadCallback.onFailure(createSdkError);
    }

    public void onVideoLoadSuccess(MBridgeIds mBridgeIds) {
        this.rewardedAdCallback = this.adLoadCallback.onSuccess(this);
    }
}
