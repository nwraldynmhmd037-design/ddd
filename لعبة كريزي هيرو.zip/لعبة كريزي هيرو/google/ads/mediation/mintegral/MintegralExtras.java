package com.google.ads.mediation.mintegral;

import android.os.Bundle;
import androidx.annotation.NonNull;

public final class MintegralExtras {

    public static class Builder {
        private boolean muteAudio;

        @NonNull
        public Bundle build() {
            Bundle bundle = new Bundle();
            bundle.putBoolean("mute_audio", this.muteAudio);
            return bundle;
        }

        @NonNull
        public Builder setMuteAudio(boolean z10) {
            this.muteAudio = z10;
            return this;
        }
    }
}
