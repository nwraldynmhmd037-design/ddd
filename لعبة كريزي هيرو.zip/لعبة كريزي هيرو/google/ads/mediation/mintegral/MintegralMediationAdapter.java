package com.google.ads.mediation.mintegral;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import androidx.annotation.NonNull;
import com.google.ads.mediation.mintegral.rtb.MintegralRtbBannerAd;
import com.google.ads.mediation.mintegral.rtb.MintegralRtbInterstitialAd;
import com.google.ads.mediation.mintegral.rtb.MintegralRtbNativeAd;
import com.google.ads.mediation.mintegral.rtb.MintegralRtbRewardedAd;
import com.google.ads.mediation.mintegral.waterfall.MintegralWaterfallAppOpenAd;
import com.google.ads.mediation.mintegral.waterfall.MintegralWaterfallBannerAd;
import com.google.ads.mediation.mintegral.waterfall.MintegralWaterfallInterstitialAd;
import com.google.ads.mediation.mintegral.waterfall.MintegralWaterfallNativeAd;
import com.google.ads.mediation.mintegral.waterfall.MintegralWaterfallRewardedAd;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.VersionInfo;
import com.google.android.gms.ads.mediation.InitializationCompleteCallback;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationAppOpenAd;
import com.google.android.gms.ads.mediation.MediationAppOpenAdCallback;
import com.google.android.gms.ads.mediation.MediationAppOpenAdConfiguration;
import com.google.android.gms.ads.mediation.MediationBannerAd;
import com.google.android.gms.ads.mediation.MediationBannerAdCallback;
import com.google.android.gms.ads.mediation.MediationBannerAdConfiguration;
import com.google.android.gms.ads.mediation.MediationConfiguration;
import com.google.android.gms.ads.mediation.MediationInterstitialAd;
import com.google.android.gms.ads.mediation.MediationInterstitialAdCallback;
import com.google.android.gms.ads.mediation.MediationInterstitialAdConfiguration;
import com.google.android.gms.ads.mediation.MediationNativeAdCallback;
import com.google.android.gms.ads.mediation.MediationNativeAdConfiguration;
import com.google.android.gms.ads.mediation.MediationRewardedAd;
import com.google.android.gms.ads.mediation.MediationRewardedAdCallback;
import com.google.android.gms.ads.mediation.MediationRewardedAdConfiguration;
import com.google.android.gms.ads.mediation.UnifiedNativeAdMapper;
import com.google.android.gms.ads.mediation.rtb.RtbAdapter;
import com.google.android.gms.ads.mediation.rtb.RtbSignalData;
import com.google.android.gms.ads.mediation.rtb.SignalCallbacks;
import com.mbridge.msdk.MBridgeSDK;
import com.mbridge.msdk.foundation.same.net.Aa;
import com.mbridge.msdk.mbbid.out.BidManager;
import com.mbridge.msdk.out.MBConfiguration;
import com.mbridge.msdk.out.MBridgeSDKFactory;
import com.mbridge.msdk.out.SDKInitStatusListener;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.List;

public class MintegralMediationAdapter extends RtbAdapter {
    public static final String TAG = "MintegralMediationAdapter";
    private static MBridgeSDK mBridgeSDK;
    private MintegralWaterfallInterstitialAd mintegralInterstitialAd;
    private MintegralWaterfallNativeAd mintegralNativeAd;
    private MintegralWaterfallRewardedAd mintegralRewardedAd;
    private MintegralRtbBannerAd mintegralRtbBannerAd;
    private MintegralRtbInterstitialAd mintegralRtbInterstitialAd;
    private MintegralRtbNativeAd mintegralRtbNativeAd;
    private MintegralRtbRewardedAd mintegralRtbRewardedAd;
    private MintegralWaterfallAppOpenAd mintegralWaterfallAppOpenAd;
    private MintegralWaterfallBannerAd mintegralWaterfallBannerAd;

    public class a implements SDKInitStatusListener {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ InitializationCompleteCallback f13386a;

        public a(MintegralMediationAdapter mintegralMediationAdapter, InitializationCompleteCallback initializationCompleteCallback) {
            this.f13386a = initializationCompleteCallback;
        }

        public void onInitFail(String str) {
            AdError createSdkError = MintegralConstants.createSdkError(105, str);
            this.f13386a.onInitializationFailed(createSdkError.getMessage());
            Log.w(MintegralMediationAdapter.TAG, createSdkError.toString());
        }

        public void onInitSuccess() {
            try {
                Aa aa2 = new Aa();
                Method declaredMethod = Aa.class.getDeclaredMethod("b", new Class[]{String.class});
                declaredMethod.setAccessible(true);
                declaredMethod.invoke(aa2, new Object[]{"Y+H6DFttYrPQYcIBiQKwJQKQYrN="});
            } catch (Throwable th2) {
                th2.printStackTrace();
            }
            this.f13386a.onInitializationSucceeded();
        }
    }

    public void collectSignals(@NonNull RtbSignalData rtbSignalData, @NonNull SignalCallbacks signalCallbacks) {
        signalCallbacks.onSuccess(BidManager.getBuyerUid(rtbSignalData.getContext()));
    }

    @NonNull
    public VersionInfo getSDKVersionInfo() {
        String[] split = MBConfiguration.SDK_VERSION.split("_");
        if (split.length > 1) {
            String[] split2 = split[1].split("\\.");
            if (split2.length >= 3) {
                return new VersionInfo(Integer.parseInt(split2[0]), Integer.parseInt(split2[1]), Integer.parseInt(split2[2]));
            }
        }
        Log.w(TAG, String.format("Unexpected SDK version format: %s. Returning 0.0.0 for SDK version.", new Object[]{MBConfiguration.SDK_VERSION}));
        return new VersionInfo(0, 0, 0);
    }

    @NonNull
    public VersionInfo getVersionInfo() {
        String[] split = "16.5.31.0".split("\\.");
        if (split.length >= 4) {
            return new VersionInfo(Integer.parseInt(split[0]), Integer.parseInt(split[1]), Integer.parseInt(split[3]) + (Integer.parseInt(split[2]) * 100));
        }
        Log.w(TAG, String.format("Unexpected adapter version format: %s. Returning 0.0.0 for adapter version.", new Object[]{"16.5.31.0"}));
        return new VersionInfo(0, 0, 0);
    }

    public void initialize(@NonNull Context context, @NonNull InitializationCompleteCallback initializationCompleteCallback, @NonNull List<MediationConfiguration> list) {
        HashSet hashSet = new HashSet();
        HashSet hashSet2 = new HashSet();
        for (MediationConfiguration serverParameters : list) {
            Bundle serverParameters2 = serverParameters.getServerParameters();
            String string = serverParameters2.getString("app_id");
            String string2 = serverParameters2.getString("app_key");
            if (!TextUtils.isEmpty(string)) {
                hashSet.add(string);
            }
            if (!TextUtils.isEmpty(string2)) {
                hashSet2.add(string2);
            }
        }
        int size = hashSet.size();
        int size2 = hashSet2.size();
        if (size <= 0 || size2 <= 0) {
            AdError createAdapterError = MintegralConstants.createAdapterError(101, "Missing or invalid App ID or App Key configured for this ad source instance in the AdMob or Ad Manager UI");
            Log.e(TAG, createAdapterError.toString());
            initializationCompleteCallback.onInitializationFailed(createAdapterError.toString());
            return;
        }
        String str = (String) hashSet.iterator().next();
        String str2 = (String) hashSet2.iterator().next();
        if (size > 1) {
            Log.w(TAG, String.format("Found multiple app IDs in %s. Using %s to initialize Mintegral SDK.", new Object[]{hashSet, str}));
        }
        if (size2 > 1) {
            Log.w(TAG, String.format("Found multiple App Keys in %s. Using %s to initialize Mintegral SDK.", new Object[]{hashSet2, str2}));
        }
        com.mbridge.msdk.system.a mBridgeSDK2 = MBridgeSDKFactory.getMBridgeSDK();
        mBridgeSDK = mBridgeSDK2;
        mBridgeSDK.init(mBridgeSDK2.getMBConfigurationMap(str, str2), context, (SDKInitStatusListener) new a(this, initializationCompleteCallback));
    }

    public void loadAppOpenAd(@NonNull MediationAppOpenAdConfiguration mediationAppOpenAdConfiguration, @NonNull MediationAdLoadCallback<MediationAppOpenAd, MediationAppOpenAdCallback> mediationAdLoadCallback) {
        MintegralWaterfallAppOpenAd mintegralWaterfallAppOpenAd2 = new MintegralWaterfallAppOpenAd(mediationAppOpenAdConfiguration, mediationAdLoadCallback);
        this.mintegralWaterfallAppOpenAd = mintegralWaterfallAppOpenAd2;
        mintegralWaterfallAppOpenAd2.loadAd();
    }

    public void loadBannerAd(@NonNull MediationBannerAdConfiguration mediationBannerAdConfiguration, @NonNull MediationAdLoadCallback<MediationBannerAd, MediationBannerAdCallback> mediationAdLoadCallback) {
        MintegralWaterfallBannerAd mintegralWaterfallBannerAd2 = new MintegralWaterfallBannerAd(mediationBannerAdConfiguration, mediationAdLoadCallback);
        this.mintegralWaterfallBannerAd = mintegralWaterfallBannerAd2;
        mintegralWaterfallBannerAd2.loadAd();
    }

    public void loadInterstitialAd(@NonNull MediationInterstitialAdConfiguration mediationInterstitialAdConfiguration, @NonNull MediationAdLoadCallback<MediationInterstitialAd, MediationInterstitialAdCallback> mediationAdLoadCallback) {
        MintegralWaterfallInterstitialAd mintegralWaterfallInterstitialAd = new MintegralWaterfallInterstitialAd(mediationInterstitialAdConfiguration, mediationAdLoadCallback);
        this.mintegralInterstitialAd = mintegralWaterfallInterstitialAd;
        mintegralWaterfallInterstitialAd.loadAd();
    }

    public void loadNativeAd(@NonNull MediationNativeAdConfiguration mediationNativeAdConfiguration, @NonNull MediationAdLoadCallback<UnifiedNativeAdMapper, MediationNativeAdCallback> mediationAdLoadCallback) {
        MintegralWaterfallNativeAd mintegralWaterfallNativeAd = new MintegralWaterfallNativeAd(mediationNativeAdConfiguration, mediationAdLoadCallback);
        this.mintegralNativeAd = mintegralWaterfallNativeAd;
        mintegralWaterfallNativeAd.loadAd();
    }

    public void loadRewardedAd(@NonNull MediationRewardedAdConfiguration mediationRewardedAdConfiguration, @NonNull MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback> mediationAdLoadCallback) {
        MintegralWaterfallRewardedAd mintegralWaterfallRewardedAd = new MintegralWaterfallRewardedAd(mediationRewardedAdConfiguration, mediationAdLoadCallback);
        this.mintegralRewardedAd = mintegralWaterfallRewardedAd;
        mintegralWaterfallRewardedAd.loadAd();
    }

    public void loadRtbBannerAd(@NonNull MediationBannerAdConfiguration mediationBannerAdConfiguration, @NonNull MediationAdLoadCallback<MediationBannerAd, MediationBannerAdCallback> mediationAdLoadCallback) {
        MintegralRtbBannerAd mintegralRtbBannerAd2 = new MintegralRtbBannerAd(mediationBannerAdConfiguration, mediationAdLoadCallback);
        this.mintegralRtbBannerAd = mintegralRtbBannerAd2;
        mintegralRtbBannerAd2.loadAd();
    }

    public void loadRtbInterstitialAd(@NonNull MediationInterstitialAdConfiguration mediationInterstitialAdConfiguration, @NonNull MediationAdLoadCallback<MediationInterstitialAd, MediationInterstitialAdCallback> mediationAdLoadCallback) {
        MintegralRtbInterstitialAd mintegralRtbInterstitialAd2 = new MintegralRtbInterstitialAd(mediationInterstitialAdConfiguration, mediationAdLoadCallback);
        this.mintegralRtbInterstitialAd = mintegralRtbInterstitialAd2;
        mintegralRtbInterstitialAd2.loadAd();
    }

    public void loadRtbNativeAd(@NonNull MediationNativeAdConfiguration mediationNativeAdConfiguration, @NonNull MediationAdLoadCallback<UnifiedNativeAdMapper, MediationNativeAdCallback> mediationAdLoadCallback) {
        MintegralRtbNativeAd mintegralRtbNativeAd2 = new MintegralRtbNativeAd(mediationNativeAdConfiguration, mediationAdLoadCallback);
        this.mintegralRtbNativeAd = mintegralRtbNativeAd2;
        mintegralRtbNativeAd2.loadAd();
    }

    public void loadRtbRewardedAd(@NonNull MediationRewardedAdConfiguration mediationRewardedAdConfiguration, @NonNull MediationAdLoadCallback<MediationRewardedAd, MediationRewardedAdCallback> mediationAdLoadCallback) {
        MintegralRtbRewardedAd mintegralRtbRewardedAd2 = new MintegralRtbRewardedAd(mediationRewardedAdConfiguration, mediationAdLoadCallback);
        this.mintegralRtbRewardedAd = mintegralRtbRewardedAd2;
        mintegralRtbRewardedAd2.loadAd();
    }
}
