package com.google.ads.mediation.mintegral;

import android.view.ViewGroup;
import com.mbridge.msdk.out.MBSplashLoadWithCodeListener;
import com.mbridge.msdk.out.MBSplashShowListener;

/* compiled from: MintegralFactory.kt */
public interface MintegralSplashAdWrapper {
    void createAd(String str, String str2);

    void onDestroy();

    void preLoad();

    void setSplashLoadListener(MBSplashLoadWithCodeListener mBSplashLoadWithCodeListener);

    void setSplashShowListener(MBSplashShowListener mBSplashShowListener);

    void show(ViewGroup viewGroup);
}
