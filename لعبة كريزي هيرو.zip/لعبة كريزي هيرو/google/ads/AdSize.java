package com.google.ads;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

@Deprecated
/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public final class AdSize {
    public static final int AUTO_HEIGHT = -2;
    @NonNull
    public static final AdSize BANNER = new AdSize(320, 50);
    public static final int FULL_WIDTH = -1;
    @NonNull
    public static final AdSize IAB_BANNER = new AdSize(468, 60);
    @NonNull
    public static final AdSize IAB_LEADERBOARD = new AdSize(728, 90);
    @NonNull
    public static final AdSize IAB_MRECT = new AdSize(300, 250);
    @NonNull
    public static final AdSize IAB_WIDE_SKYSCRAPER = new AdSize(160, 600);
    public static final int LANDSCAPE_AD_HEIGHT = 32;
    public static final int LARGE_AD_HEIGHT = 90;
    public static final int PORTRAIT_AD_HEIGHT = 50;
    @NonNull
    public static final AdSize SMART_BANNER = new AdSize(-1, -2);
    private final com.google.android.gms.ads.AdSize zza;

    public AdSize(int i10, int i11) {
        this(new com.google.android.gms.ads.AdSize(i10, i11));
    }

    public AdSize(@NonNull com.google.android.gms.ads.AdSize adSize) {
        this.zza = adSize;
    }

    public boolean equals(@NonNull Object obj) {
        if (!(obj instanceof AdSize)) {
            return false;
        }
        return this.zza.equals(((AdSize) obj).zza);
    }

    @Nullable
    public AdSize findBestSize(@NonNull AdSize... adSizeArr) {
        AdSize adSize = null;
        if (adSizeArr == null) {
            return null;
        }
        int width = getWidth();
        int height = getHeight();
        float f10 = 0.0f;
        for (AdSize adSize2 : adSizeArr) {
            int width2 = adSize2.getWidth();
            int height2 = adSize2.getHeight();
            if (isSizeAppropriate(width2, height2)) {
                float f11 = ((float) (width2 * height2)) / ((float) (width * height));
                if (f11 > 1.0f) {
                    f11 = 1.0f / f11;
                }
                if (f11 > f10) {
                    adSize = adSize2;
                    f10 = f11;
                }
            }
        }
        return adSize;
    }

    public int getHeight() {
        return this.zza.getHeight();
    }

    public int getHeightInPixels(@NonNull Context context) {
        return this.zza.getHeightInPixels(context);
    }

    public int getWidth() {
        return this.zza.getWidth();
    }

    public int getWidthInPixels(@NonNull Context context) {
        return this.zza.getWidthInPixels(context);
    }

    public int hashCode() {
        return this.zza.hashCode();
    }

    public boolean isAutoHeight() {
        return this.zza.isAutoHeight();
    }

    public boolean isCustomAdSize() {
        return false;
    }

    public boolean isFullWidth() {
        return this.zza.isFullWidth();
    }

    public boolean isSizeAppropriate(int i10, int i11) {
        float width = (float) getWidth();
        float f10 = (float) i10;
        int i12 = (f10 > (width * 1.25f) ? 1 : (f10 == (width * 1.25f) ? 0 : -1));
        int height = getHeight();
        if (i12 > 0 || f10 < width * 0.8f) {
            return false;
        }
        float f11 = (float) i11;
        float f12 = (float) height;
        return f11 <= 1.25f * f12 && f11 >= f12 * 0.8f;
    }

    @NonNull
    public String toString() {
        return this.zza.toString();
    }
}
