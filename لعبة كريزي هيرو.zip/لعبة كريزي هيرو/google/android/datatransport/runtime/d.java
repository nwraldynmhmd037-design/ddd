package com.google.android.datatransport.runtime;

import b5.f;
import com.google.android.datatransport.Encoding;
import com.google.android.datatransport.Event;
import com.google.android.datatransport.Transformer;
import com.google.android.datatransport.Transport;
import com.google.android.datatransport.TransportScheduleCallback;
import com.google.android.datatransport.runtime.b;
import java.util.Objects;
import l.a;

/* compiled from: TransportImpl */
public final class d<T> implements Transport<T> {

    /* renamed from: a  reason: collision with root package name */
    public final TransportContext f13592a;

    /* renamed from: b  reason: collision with root package name */
    public final String f13593b;

    /* renamed from: c  reason: collision with root package name */
    public final Encoding f13594c;

    /* renamed from: d  reason: collision with root package name */
    public final Transformer<T, byte[]> f13595d;

    /* renamed from: e  reason: collision with root package name */
    public final f f13596e;

    public d(TransportContext transportContext, String str, Encoding encoding, Transformer<T, byte[]> transformer, f fVar) {
        this.f13592a = transportContext;
        this.f13593b = str;
        this.f13594c = encoding;
        this.f13595d = transformer;
        this.f13596e = fVar;
    }

    public void schedule(Event<T> event, TransportScheduleCallback transportScheduleCallback) {
        f fVar = this.f13596e;
        b.C0214b bVar = new b.C0214b();
        TransportContext transportContext = this.f13592a;
        Objects.requireNonNull(transportContext, "Null transportContext");
        bVar.f13575a = transportContext;
        Objects.requireNonNull(event, "Null event");
        bVar.f13577c = event;
        String str = this.f13593b;
        Objects.requireNonNull(str, "Null transportName");
        bVar.f13576b = str;
        Transformer<T, byte[]> transformer = this.f13595d;
        Objects.requireNonNull(transformer, "Null transformer");
        bVar.f13578d = transformer;
        Encoding encoding = this.f13594c;
        Objects.requireNonNull(encoding, "Null encoding");
        bVar.f13579e = encoding;
        String str2 = bVar.f13575a == null ? " transportContext" : "";
        if (bVar.f13576b == null) {
            str2 = a.a(str2, " transportName");
        }
        if (bVar.f13577c == null) {
            str2 = a.a(str2, " event");
        }
        if (bVar.f13578d == null) {
            str2 = a.a(str2, " transformer");
        }
        if (bVar.f13579e == null) {
            str2 = a.a(str2, " encoding");
        }
        if (str2.isEmpty()) {
            fVar.send(new b(bVar.f13575a, bVar.f13576b, bVar.f13577c, bVar.f13578d, bVar.f13579e, (b.a) null), transportScheduleCallback);
            return;
        }
        throw new IllegalStateException(a.a("Missing required properties:", str2));
    }

    public void send(Event<T> event) {
        schedule(event, e1.b.f33250d);
    }
}
