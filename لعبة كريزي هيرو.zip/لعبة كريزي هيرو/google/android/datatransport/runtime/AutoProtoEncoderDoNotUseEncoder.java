package com.google.android.datatransport.runtime;

import com.google.android.datatransport.runtime.firebase.transport.ClientMetrics;
import com.google.android.datatransport.runtime.firebase.transport.GlobalMetrics;
import com.google.android.datatransport.runtime.firebase.transport.LogEventDropped;
import com.google.android.datatransport.runtime.firebase.transport.LogSourceMetrics;
import com.google.android.datatransport.runtime.firebase.transport.StorageMetrics;
import com.google.android.datatransport.runtime.firebase.transport.TimeWindow;
import com.google.firebase.encoders.FieldDescriptor;
import com.google.firebase.encoders.ObjectEncoder;
import com.google.firebase.encoders.ObjectEncoderContext;
import com.google.firebase.encoders.config.Configurator;
import com.google.firebase.encoders.config.EncoderConfig;
import java.io.IOException;

public final class AutoProtoEncoderDoNotUseEncoder implements Configurator {
    public static final int CODEGEN_VERSION = 2;
    public static final Configurator CONFIG = new AutoProtoEncoderDoNotUseEncoder();

    public static final class a implements ObjectEncoder<ClientMetrics> {

        /* renamed from: a  reason: collision with root package name */
        public static final a f13536a = new a();

        /* renamed from: b  reason: collision with root package name */
        public static final FieldDescriptor f13537b = b5.a.a(1, FieldDescriptor.builder("window"));

        /* renamed from: c  reason: collision with root package name */
        public static final FieldDescriptor f13538c = b5.a.a(2, FieldDescriptor.builder("logSourceMetrics"));

        /* renamed from: d  reason: collision with root package name */
        public static final FieldDescriptor f13539d = b5.a.a(3, FieldDescriptor.builder("globalMetrics"));

        /* renamed from: e  reason: collision with root package name */
        public static final FieldDescriptor f13540e = b5.a.a(4, FieldDescriptor.builder("appNamespace"));

        public void encode(Object obj, Object obj2) throws IOException {
            ClientMetrics clientMetrics = (ClientMetrics) obj;
            ObjectEncoderContext objectEncoderContext = (ObjectEncoderContext) obj2;
            objectEncoderContext.add(f13537b, (Object) clientMetrics.getWindowInternal());
            objectEncoderContext.add(f13538c, (Object) clientMetrics.getLogSourceMetricsList());
            objectEncoderContext.add(f13539d, (Object) clientMetrics.getGlobalMetricsInternal());
            objectEncoderContext.add(f13540e, (Object) clientMetrics.getAppNamespace());
        }
    }

    public static final class b implements ObjectEncoder<GlobalMetrics> {

        /* renamed from: a  reason: collision with root package name */
        public static final b f13541a = new b();

        /* renamed from: b  reason: collision with root package name */
        public static final FieldDescriptor f13542b = b5.a.a(1, FieldDescriptor.builder("storageMetrics"));

        public void encode(Object obj, Object obj2) throws IOException {
            ((ObjectEncoderContext) obj2).add(f13542b, (Object) ((GlobalMetrics) obj).getStorageMetricsInternal());
        }
    }

    public static final class c implements ObjectEncoder<LogEventDropped> {

        /* renamed from: a  reason: collision with root package name */
        public static final c f13543a = new c();

        /* renamed from: b  reason: collision with root package name */
        public static final FieldDescriptor f13544b = b5.a.a(1, FieldDescriptor.builder("eventsDroppedCount"));

        /* renamed from: c  reason: collision with root package name */
        public static final FieldDescriptor f13545c = b5.a.a(3, FieldDescriptor.builder("reason"));

        public void encode(Object obj, Object obj2) throws IOException {
            LogEventDropped logEventDropped = (LogEventDropped) obj;
            ObjectEncoderContext objectEncoderContext = (ObjectEncoderContext) obj2;
            objectEncoderContext.add(f13544b, logEventDropped.getEventsDroppedCount());
            objectEncoderContext.add(f13545c, (Object) logEventDropped.getReason());
        }
    }

    public static final class d implements ObjectEncoder<LogSourceMetrics> {

        /* renamed from: a  reason: collision with root package name */
        public static final d f13546a = new d();

        /* renamed from: b  reason: collision with root package name */
        public static final FieldDescriptor f13547b = b5.a.a(1, FieldDescriptor.builder("logSource"));

        /* renamed from: c  reason: collision with root package name */
        public static final FieldDescriptor f13548c = b5.a.a(2, FieldDescriptor.builder("logEventDropped"));

        public void encode(Object obj, Object obj2) throws IOException {
            LogSourceMetrics logSourceMetrics = (LogSourceMetrics) obj;
            ObjectEncoderContext objectEncoderContext = (ObjectEncoderContext) obj2;
            objectEncoderContext.add(f13547b, (Object) logSourceMetrics.getLogSource());
            objectEncoderContext.add(f13548c, (Object) logSourceMetrics.getLogEventDroppedList());
        }
    }

    public static final class e implements ObjectEncoder<ProtoEncoderDoNotUse> {

        /* renamed from: a  reason: collision with root package name */
        public static final e f13549a = new e();

        /* renamed from: b  reason: collision with root package name */
        public static final FieldDescriptor f13550b = FieldDescriptor.of("clientMetrics");

        public void encode(Object obj, Object obj2) throws IOException {
            ((ObjectEncoderContext) obj2).add(f13550b, (Object) ((ProtoEncoderDoNotUse) obj).getClientMetrics());
        }
    }

    public static final class f implements ObjectEncoder<StorageMetrics> {

        /* renamed from: a  reason: collision with root package name */
        public static final f f13551a = new f();

        /* renamed from: b  reason: collision with root package name */
        public static final FieldDescriptor f13552b = b5.a.a(1, FieldDescriptor.builder("currentCacheSizeBytes"));

        /* renamed from: c  reason: collision with root package name */
        public static final FieldDescriptor f13553c = b5.a.a(2, FieldDescriptor.builder("maxCacheSizeBytes"));

        public void encode(Object obj, Object obj2) throws IOException {
            StorageMetrics storageMetrics = (StorageMetrics) obj;
            ObjectEncoderContext objectEncoderContext = (ObjectEncoderContext) obj2;
            objectEncoderContext.add(f13552b, storageMetrics.getCurrentCacheSizeBytes());
            objectEncoderContext.add(f13553c, storageMetrics.getMaxCacheSizeBytes());
        }
    }

    public static final class g implements ObjectEncoder<TimeWindow> {

        /* renamed from: a  reason: collision with root package name */
        public static final g f13554a = new g();

        /* renamed from: b  reason: collision with root package name */
        public static final FieldDescriptor f13555b = b5.a.a(1, FieldDescriptor.builder("startMs"));

        /* renamed from: c  reason: collision with root package name */
        public static final FieldDescriptor f13556c = b5.a.a(2, FieldDescriptor.builder("endMs"));

        public void encode(Object obj, Object obj2) throws IOException {
            TimeWindow timeWindow = (TimeWindow) obj;
            ObjectEncoderContext objectEncoderContext = (ObjectEncoderContext) obj2;
            objectEncoderContext.add(f13555b, timeWindow.getStartMs());
            objectEncoderContext.add(f13556c, timeWindow.getEndMs());
        }
    }

    private AutoProtoEncoderDoNotUseEncoder() {
    }

    public void configure(EncoderConfig<?> encoderConfig) {
        encoderConfig.registerEncoder((Class<U>) ProtoEncoderDoNotUse.class, (ObjectEncoder<? super U>) e.f13549a);
        encoderConfig.registerEncoder((Class<U>) ClientMetrics.class, (ObjectEncoder<? super U>) a.f13536a);
        encoderConfig.registerEncoder((Class<U>) TimeWindow.class, (ObjectEncoder<? super U>) g.f13554a);
        encoderConfig.registerEncoder((Class<U>) LogSourceMetrics.class, (ObjectEncoder<? super U>) d.f13546a);
        encoderConfig.registerEncoder((Class<U>) LogEventDropped.class, (ObjectEncoder<? super U>) c.f13543a);
        encoderConfig.registerEncoder((Class<U>) GlobalMetrics.class, (ObjectEncoder<? super U>) b.f13541a);
        encoderConfig.registerEncoder((Class<U>) StorageMetrics.class, (ObjectEncoder<? super U>) f.f13551a);
    }
}
