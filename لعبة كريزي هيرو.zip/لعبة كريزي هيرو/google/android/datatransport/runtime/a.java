package com.google.android.datatransport.runtime;

import androidx.annotation.Nullable;
import com.google.android.datatransport.runtime.EventInternal;
import java.util.Map;
import java.util.Objects;

/* compiled from: AutoValue_EventInternal */
public final class a extends EventInternal {

    /* renamed from: a  reason: collision with root package name */
    public final String f13558a;

    /* renamed from: b  reason: collision with root package name */
    public final Integer f13559b;

    /* renamed from: c  reason: collision with root package name */
    public final EncodedPayload f13560c;

    /* renamed from: d  reason: collision with root package name */
    public final long f13561d;

    /* renamed from: e  reason: collision with root package name */
    public final long f13562e;

    /* renamed from: f  reason: collision with root package name */
    public final Map<String, String> f13563f;

    /* compiled from: AutoValue_EventInternal */
    public static final class b extends EventInternal.Builder {

        /* renamed from: a  reason: collision with root package name */
        public String f13564a;

        /* renamed from: b  reason: collision with root package name */
        public Integer f13565b;

        /* renamed from: c  reason: collision with root package name */
        public EncodedPayload f13566c;

        /* renamed from: d  reason: collision with root package name */
        public Long f13567d;

        /* renamed from: e  reason: collision with root package name */
        public Long f13568e;

        /* renamed from: f  reason: collision with root package name */
        public Map<String, String> f13569f;

        public EventInternal build() {
            String str = this.f13564a == null ? " transportName" : "";
            if (this.f13566c == null) {
                str = l.a.a(str, " encodedPayload");
            }
            if (this.f13567d == null) {
                str = l.a.a(str, " eventMillis");
            }
            if (this.f13568e == null) {
                str = l.a.a(str, " uptimeMillis");
            }
            if (this.f13569f == null) {
                str = l.a.a(str, " autoMetadata");
            }
            if (str.isEmpty()) {
                return new a(this.f13564a, this.f13565b, this.f13566c, this.f13567d.longValue(), this.f13568e.longValue(), this.f13569f, (C0213a) null);
            }
            throw new IllegalStateException(l.a.a("Missing required properties:", str));
        }

        public Map<String, String> getAutoMetadata() {
            Map<String, String> map = this.f13569f;
            if (map != null) {
                return map;
            }
            throw new IllegalStateException("Property \"autoMetadata\" has not been set");
        }

        public EventInternal.Builder setAutoMetadata(Map<String, String> map) {
            Objects.requireNonNull(map, "Null autoMetadata");
            this.f13569f = map;
            return this;
        }

        public EventInternal.Builder setCode(Integer num) {
            this.f13565b = num;
            return this;
        }

        public EventInternal.Builder setEncodedPayload(EncodedPayload encodedPayload) {
            Objects.requireNonNull(encodedPayload, "Null encodedPayload");
            this.f13566c = encodedPayload;
            return this;
        }

        public EventInternal.Builder setEventMillis(long j10) {
            this.f13567d = Long.valueOf(j10);
            return this;
        }

        public EventInternal.Builder setTransportName(String str) {
            Objects.requireNonNull(str, "Null transportName");
            this.f13564a = str;
            return this;
        }

        public EventInternal.Builder setUptimeMillis(long j10) {
            this.f13568e = Long.valueOf(j10);
            return this;
        }
    }

    public a(String str, Integer num, EncodedPayload encodedPayload, long j10, long j11, Map map, C0213a aVar) {
        this.f13558a = str;
        this.f13559b = num;
        this.f13560c = encodedPayload;
        this.f13561d = j10;
        this.f13562e = j11;
        this.f13563f = map;
    }

    public boolean equals(Object obj) {
        Integer num;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof EventInternal)) {
            return false;
        }
        EventInternal eventInternal = (EventInternal) obj;
        if (!this.f13558a.equals(eventInternal.getTransportName()) || ((num = this.f13559b) != null ? !num.equals(eventInternal.getCode()) : eventInternal.getCode() != null) || !this.f13560c.equals(eventInternal.getEncodedPayload()) || this.f13561d != eventInternal.getEventMillis() || this.f13562e != eventInternal.getUptimeMillis() || !this.f13563f.equals(eventInternal.getAutoMetadata())) {
            return false;
        }
        return true;
    }

    public Map<String, String> getAutoMetadata() {
        return this.f13563f;
    }

    @Nullable
    public Integer getCode() {
        return this.f13559b;
    }

    public EncodedPayload getEncodedPayload() {
        return this.f13560c;
    }

    public long getEventMillis() {
        return this.f13561d;
    }

    public String getTransportName() {
        return this.f13558a;
    }

    public long getUptimeMillis() {
        return this.f13562e;
    }

    public int hashCode() {
        int hashCode = (this.f13558a.hashCode() ^ 1000003) * 1000003;
        Integer num = this.f13559b;
        int hashCode2 = num == null ? 0 : num.hashCode();
        long j10 = this.f13561d;
        long j11 = this.f13562e;
        return ((((((((hashCode ^ hashCode2) * 1000003) ^ this.f13560c.hashCode()) * 1000003) ^ ((int) (j10 ^ (j10 >>> 32)))) * 1000003) ^ ((int) (j11 ^ (j11 >>> 32)))) * 1000003) ^ this.f13563f.hashCode();
    }

    public String toString() {
        StringBuilder a10 = d.a.a("EventInternal{transportName=");
        a10.append(this.f13558a);
        a10.append(", code=");
        a10.append(this.f13559b);
        a10.append(", encodedPayload=");
        a10.append(this.f13560c);
        a10.append(", eventMillis=");
        a10.append(this.f13561d);
        a10.append(", uptimeMillis=");
        a10.append(this.f13562e);
        a10.append(", autoMetadata=");
        a10.append(this.f13563f);
        a10.append("}");
        return a10.toString();
    }
}
