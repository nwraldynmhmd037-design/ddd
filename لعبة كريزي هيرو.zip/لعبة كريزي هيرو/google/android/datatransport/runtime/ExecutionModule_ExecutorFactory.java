package com.google.android.datatransport.runtime;

import b5.d;
import com.google.android.datatransport.runtime.dagger.internal.Factory;
import com.google.android.datatransport.runtime.dagger.internal.Preconditions;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public final class ExecutionModule_ExecutorFactory implements Factory<Executor> {

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public static final ExecutionModule_ExecutorFactory f13557a = new ExecutionModule_ExecutorFactory();
    }

    public static ExecutionModule_ExecutorFactory create() {
        return a.f13557a;
    }

    public static Executor executor() {
        return (Executor) Preconditions.checkNotNull(new d(Executors.newSingleThreadExecutor()), "Cannot return null from a non-@Nullable @Provides method");
    }

    public Executor get() {
        return executor();
    }
}
