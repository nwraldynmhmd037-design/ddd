package com.google.android.datatransport.runtime;

import com.google.android.datatransport.Encoding;
import com.google.android.datatransport.Event;
import com.google.android.datatransport.Transformer;
import com.google.android.datatransport.runtime.SendRequest;
import java.util.Objects;

/* compiled from: AutoValue_SendRequest */
public final class b extends SendRequest {

    /* renamed from: a  reason: collision with root package name */
    public final TransportContext f13570a;

    /* renamed from: b  reason: collision with root package name */
    public final String f13571b;

    /* renamed from: c  reason: collision with root package name */
    public final Event<?> f13572c;

    /* renamed from: d  reason: collision with root package name */
    public final Transformer<?, byte[]> f13573d;

    /* renamed from: e  reason: collision with root package name */
    public final Encoding f13574e;

    /* renamed from: com.google.android.datatransport.runtime.b$b  reason: collision with other inner class name */
    /* compiled from: AutoValue_SendRequest */
    public static final class C0214b extends SendRequest.Builder {

        /* renamed from: a  reason: collision with root package name */
        public TransportContext f13575a;

        /* renamed from: b  reason: collision with root package name */
        public String f13576b;

        /* renamed from: c  reason: collision with root package name */
        public Event<?> f13577c;

        /* renamed from: d  reason: collision with root package name */
        public Transformer<?, byte[]> f13578d;

        /* renamed from: e  reason: collision with root package name */
        public Encoding f13579e;

        public SendRequest build() {
            String str = this.f13575a == null ? " transportContext" : "";
            if (this.f13576b == null) {
                str = l.a.a(str, " transportName");
            }
            if (this.f13577c == null) {
                str = l.a.a(str, " event");
            }
            if (this.f13578d == null) {
                str = l.a.a(str, " transformer");
            }
            if (this.f13579e == null) {
                str = l.a.a(str, " encoding");
            }
            if (str.isEmpty()) {
                return new b(this.f13575a, this.f13576b, this.f13577c, this.f13578d, this.f13579e, (a) null);
            }
            throw new IllegalStateException(l.a.a("Missing required properties:", str));
        }

        public SendRequest.Builder setEncoding(Encoding encoding) {
            Objects.requireNonNull(encoding, "Null encoding");
            this.f13579e = encoding;
            return this;
        }

        public SendRequest.Builder setEvent(Event<?> event) {
            Objects.requireNonNull(event, "Null event");
            this.f13577c = event;
            return this;
        }

        public SendRequest.Builder setTransformer(Transformer<?, byte[]> transformer) {
            Objects.requireNonNull(transformer, "Null transformer");
            this.f13578d = transformer;
            return this;
        }

        public SendRequest.Builder setTransportContext(TransportContext transportContext) {
            Objects.requireNonNull(transportContext, "Null transportContext");
            this.f13575a = transportContext;
            return this;
        }

        public SendRequest.Builder setTransportName(String str) {
            Objects.requireNonNull(str, "Null transportName");
            this.f13576b = str;
            return this;
        }
    }

    public b(TransportContext transportContext, String str, Event event, Transformer transformer, Encoding encoding, a aVar) {
        this.f13570a = transportContext;
        this.f13571b = str;
        this.f13572c = event;
        this.f13573d = transformer;
        this.f13574e = encoding;
    }

    public Encoding a() {
        return this.f13574e;
    }

    public Event<?> b() {
        return this.f13572c;
    }

    public Transformer<?, byte[]> c() {
        return this.f13573d;
    }

    public TransportContext d() {
        return this.f13570a;
    }

    public String e() {
        return this.f13571b;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof SendRequest)) {
            return false;
        }
        SendRequest sendRequest = (SendRequest) obj;
        if (!this.f13570a.equals(sendRequest.d()) || !this.f13571b.equals(sendRequest.e()) || !this.f13572c.equals(sendRequest.b()) || !this.f13573d.equals(sendRequest.c()) || !this.f13574e.equals(sendRequest.a())) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return ((((((((this.f13570a.hashCode() ^ 1000003) * 1000003) ^ this.f13571b.hashCode()) * 1000003) ^ this.f13572c.hashCode()) * 1000003) ^ this.f13573d.hashCode()) * 1000003) ^ this.f13574e.hashCode();
    }

    public String toString() {
        StringBuilder a10 = d.a.a("SendRequest{transportContext=");
        a10.append(this.f13570a);
        a10.append(", transportName=");
        a10.append(this.f13571b);
        a10.append(", event=");
        a10.append(this.f13572c);
        a10.append(", transformer=");
        a10.append(this.f13573d);
        a10.append(", encoding=");
        a10.append(this.f13574e);
        a10.append("}");
        return a10.toString();
    }
}
