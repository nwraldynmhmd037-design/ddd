package com.google.android.datatransport.runtime;

import b5.b;
import b5.c;
import com.google.android.datatransport.runtime.backends.BackendRegistryModule;
import com.google.android.datatransport.runtime.dagger.Component;
import com.google.android.datatransport.runtime.scheduling.SchedulingConfigModule;
import com.google.android.datatransport.runtime.scheduling.SchedulingModule;
import com.google.android.datatransport.runtime.scheduling.persistence.EventStoreModule;
import com.google.android.datatransport.runtime.time.TimeModule;
import java.io.Closeable;
import java.io.IOException;

@Component(modules = {BackendRegistryModule.class, EventStoreModule.class, c.class, SchedulingModule.class, SchedulingConfigModule.class, TimeModule.class})
/* compiled from: TransportRuntimeComponent */
public abstract class e implements Closeable {
    public void close() throws IOException {
        ((b) this).f2518g.get().close();
    }
}
