package com.google.android.datatransport.runtime.backends;

import com.google.android.datatransport.runtime.backends.BackendResponse;
import d.a;
import java.util.Objects;

/* compiled from: AutoValue_BackendResponse */
public final class b extends BackendResponse {

    /* renamed from: a  reason: collision with root package name */
    public final BackendResponse.Status f13584a;

    /* renamed from: b  reason: collision with root package name */
    public final long f13585b;

    public b(BackendResponse.Status status, long j10) {
        Objects.requireNonNull(status, "Null status");
        this.f13584a = status;
        this.f13585b = j10;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof BackendResponse)) {
            return false;
        }
        BackendResponse backendResponse = (BackendResponse) obj;
        if (!this.f13584a.equals(backendResponse.getStatus()) || this.f13585b != backendResponse.getNextRequestWaitMillis()) {
            return false;
        }
        return true;
    }

    public long getNextRequestWaitMillis() {
        return this.f13585b;
    }

    public BackendResponse.Status getStatus() {
        return this.f13584a;
    }

    public int hashCode() {
        long j10 = this.f13585b;
        return ((this.f13584a.hashCode() ^ 1000003) * 1000003) ^ ((int) (j10 ^ (j10 >>> 32)));
    }

    public String toString() {
        StringBuilder a10 = a.a("BackendResponse{status=");
        a10.append(this.f13584a);
        a10.append(", nextRequestWaitMillis=");
        return i.a.a(a10, this.f13585b, "}");
    }
}
