package com.google.android.datatransport.runtime.backends;

import androidx.annotation.Nullable;
import com.google.android.datatransport.runtime.EventInternal;
import com.google.android.datatransport.runtime.backends.BackendRequest;
import java.util.Arrays;
import java.util.Objects;

/* compiled from: AutoValue_BackendRequest */
public final class a extends BackendRequest {

    /* renamed from: a  reason: collision with root package name */
    public final Iterable<EventInternal> f13580a;

    /* renamed from: b  reason: collision with root package name */
    public final byte[] f13581b;

    /* compiled from: AutoValue_BackendRequest */
    public static final class b extends BackendRequest.Builder {

        /* renamed from: a  reason: collision with root package name */
        public Iterable<EventInternal> f13582a;

        /* renamed from: b  reason: collision with root package name */
        public byte[] f13583b;

        public BackendRequest build() {
            String str = this.f13582a == null ? " events" : "";
            if (str.isEmpty()) {
                return new a(this.f13582a, this.f13583b, (C0215a) null);
            }
            throw new IllegalStateException(l.a.a("Missing required properties:", str));
        }

        public BackendRequest.Builder setEvents(Iterable<EventInternal> iterable) {
            Objects.requireNonNull(iterable, "Null events");
            this.f13582a = iterable;
            return this;
        }

        public BackendRequest.Builder setExtras(@Nullable byte[] bArr) {
            this.f13583b = bArr;
            return this;
        }
    }

    public a(Iterable iterable, byte[] bArr, C0215a aVar) {
        this.f13580a = iterable;
        this.f13581b = bArr;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof BackendRequest)) {
            return false;
        }
        BackendRequest backendRequest = (BackendRequest) obj;
        if (this.f13580a.equals(backendRequest.getEvents())) {
            if (Arrays.equals(this.f13581b, backendRequest instanceof a ? ((a) backendRequest).f13581b : backendRequest.getExtras())) {
                return true;
            }
        }
        return false;
    }

    public Iterable<EventInternal> getEvents() {
        return this.f13580a;
    }

    @Nullable
    public byte[] getExtras() {
        return this.f13581b;
    }

    public int hashCode() {
        return ((this.f13580a.hashCode() ^ 1000003) * 1000003) ^ Arrays.hashCode(this.f13581b);
    }

    public String toString() {
        StringBuilder a10 = d.a.a("BackendRequest{events=");
        a10.append(this.f13580a);
        a10.append(", extras=");
        a10.append(Arrays.toString(this.f13581b));
        a10.append("}");
        return a10.toString();
    }
}
