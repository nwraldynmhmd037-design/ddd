package com.google.android.datatransport.runtime.backends;

import c5.c;
import com.google.android.datatransport.runtime.dagger.Binds;
import com.google.android.datatransport.runtime.dagger.Module;

@Module
public abstract class BackendRegistryModule {
    @Binds
    public abstract BackendRegistry backendRegistry(c cVar);
}
