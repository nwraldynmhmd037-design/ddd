package com.google.android.datatransport.runtime.backends;

import android.content.Context;
import c5.b;
import c5.c;
import com.google.android.datatransport.runtime.dagger.internal.Factory;
import sf.a;

public final class MetadataBackendRegistry_Factory implements Factory<c> {
    private final a<Context> applicationContextProvider;
    private final a<b> creationContextFactoryProvider;

    public MetadataBackendRegistry_Factory(a<Context> aVar, a<b> aVar2) {
        this.applicationContextProvider = aVar;
        this.creationContextFactoryProvider = aVar2;
    }

    public static MetadataBackendRegistry_Factory create(a<Context> aVar, a<b> aVar2) {
        return new MetadataBackendRegistry_Factory(aVar, aVar2);
    }

    public static c newInstance(Context context, Object obj) {
        return new c(context, (b) obj);
    }

    public c get() {
        return newInstance(this.applicationContextProvider.get(), this.creationContextFactoryProvider.get());
    }
}
