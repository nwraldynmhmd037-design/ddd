package com.google.android.datatransport.runtime.scheduling.jobscheduling;

import com.google.android.datatransport.runtime.scheduling.jobscheduling.SchedulerConfig;
import java.util.Objects;
import java.util.Set;

/* compiled from: AutoValue_SchedulerConfig_ConfigValue */
public final class b extends SchedulerConfig.ConfigValue {

    /* renamed from: a  reason: collision with root package name */
    public final long f13599a;

    /* renamed from: b  reason: collision with root package name */
    public final long f13600b;

    /* renamed from: c  reason: collision with root package name */
    public final Set<SchedulerConfig.Flag> f13601c;

    /* renamed from: com.google.android.datatransport.runtime.scheduling.jobscheduling.b$b  reason: collision with other inner class name */
    /* compiled from: AutoValue_SchedulerConfig_ConfigValue */
    public static final class C0216b extends SchedulerConfig.ConfigValue.Builder {

        /* renamed from: a  reason: collision with root package name */
        public Long f13602a;

        /* renamed from: b  reason: collision with root package name */
        public Long f13603b;

        /* renamed from: c  reason: collision with root package name */
        public Set<SchedulerConfig.Flag> f13604c;

        public SchedulerConfig.ConfigValue build() {
            String str = this.f13602a == null ? " delta" : "";
            if (this.f13603b == null) {
                str = l.a.a(str, " maxAllowedDelay");
            }
            if (this.f13604c == null) {
                str = l.a.a(str, " flags");
            }
            if (str.isEmpty()) {
                return new b(this.f13602a.longValue(), this.f13603b.longValue(), this.f13604c, (a) null);
            }
            throw new IllegalStateException(l.a.a("Missing required properties:", str));
        }

        public SchedulerConfig.ConfigValue.Builder setDelta(long j10) {
            this.f13602a = Long.valueOf(j10);
            return this;
        }

        public SchedulerConfig.ConfigValue.Builder setFlags(Set<SchedulerConfig.Flag> set) {
            Objects.requireNonNull(set, "Null flags");
            this.f13604c = set;
            return this;
        }

        public SchedulerConfig.ConfigValue.Builder setMaxAllowedDelay(long j10) {
            this.f13603b = Long.valueOf(j10);
            return this;
        }
    }

    public b(long j10, long j11, Set set, a aVar) {
        this.f13599a = j10;
        this.f13600b = j11;
        this.f13601c = set;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof SchedulerConfig.ConfigValue)) {
            return false;
        }
        SchedulerConfig.ConfigValue configValue = (SchedulerConfig.ConfigValue) obj;
        if (this.f13599a == configValue.getDelta() && this.f13600b == configValue.getMaxAllowedDelay() && this.f13601c.equals(configValue.getFlags())) {
            return true;
        }
        return false;
    }

    public long getDelta() {
        return this.f13599a;
    }

    public Set<SchedulerConfig.Flag> getFlags() {
        return this.f13601c;
    }

    public long getMaxAllowedDelay() {
        return this.f13600b;
    }

    public int hashCode() {
        long j10 = this.f13599a;
        long j11 = this.f13600b;
        return this.f13601c.hashCode() ^ ((((((int) (j10 ^ (j10 >>> 32))) ^ 1000003) * 1000003) ^ ((int) ((j11 >>> 32) ^ j11))) * 1000003);
    }

    public String toString() {
        StringBuilder a10 = d.a.a("ConfigValue{delta=");
        a10.append(this.f13599a);
        a10.append(", maxAllowedDelay=");
        a10.append(this.f13600b);
        a10.append(", flags=");
        a10.append(this.f13601c);
        a10.append("}");
        return a10.toString();
    }
}
