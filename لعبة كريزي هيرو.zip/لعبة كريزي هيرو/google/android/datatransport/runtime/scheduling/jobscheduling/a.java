package com.google.android.datatransport.runtime.scheduling.jobscheduling;

import com.google.android.datatransport.Priority;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.SchedulerConfig;
import com.google.android.datatransport.runtime.time.Clock;
import java.util.Map;
import java.util.Objects;

/* compiled from: AutoValue_SchedulerConfig */
public final class a extends SchedulerConfig {

    /* renamed from: a  reason: collision with root package name */
    public final Clock f13597a;

    /* renamed from: b  reason: collision with root package name */
    public final Map<Priority, SchedulerConfig.ConfigValue> f13598b;

    public a(Clock clock, Map<Priority, SchedulerConfig.ConfigValue> map) {
        Objects.requireNonNull(clock, "Null clock");
        this.f13597a = clock;
        Objects.requireNonNull(map, "Null values");
        this.f13598b = map;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof SchedulerConfig)) {
            return false;
        }
        SchedulerConfig schedulerConfig = (SchedulerConfig) obj;
        if (!this.f13597a.equals(schedulerConfig.getClock()) || !this.f13598b.equals(schedulerConfig.getValues())) {
            return false;
        }
        return true;
    }

    public Clock getClock() {
        return this.f13597a;
    }

    public Map<Priority, SchedulerConfig.ConfigValue> getValues() {
        return this.f13598b;
    }

    public int hashCode() {
        return ((this.f13597a.hashCode() ^ 1000003) * 1000003) ^ this.f13598b.hashCode();
    }

    public String toString() {
        StringBuilder a10 = d.a.a("SchedulerConfig{clock=");
        a10.append(this.f13597a);
        a10.append(", values=");
        a10.append(this.f13598b);
        a10.append("}");
        return a10.toString();
    }
}
