package com.google.android.datatransport.runtime.scheduling.jobscheduling;

import com.google.android.datatransport.runtime.TransportContext;

public interface WorkScheduler {
    void schedule(TransportContext transportContext, int i10);

    void schedule(TransportContext transportContext, int i10, boolean z10);
}
