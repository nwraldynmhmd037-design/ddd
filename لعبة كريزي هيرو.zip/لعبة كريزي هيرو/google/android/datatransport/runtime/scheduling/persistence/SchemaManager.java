package com.google.android.datatransport.runtime.scheduling.persistence;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.datastore.preferences.protobuf.d;
import d.a;
import e5.e;
import e5.f;
import e5.g;
import e5.h;
import e5.i;
import java.util.Arrays;
import java.util.List;

public final class SchemaManager extends SQLiteOpenHelper {

    /* renamed from: c  reason: collision with root package name */
    public static final String f13610c;

    /* renamed from: d  reason: collision with root package name */
    public static int f13611d = 5;

    /* renamed from: e  reason: collision with root package name */
    public static final Migration f13612e;

    /* renamed from: f  reason: collision with root package name */
    public static final Migration f13613f;

    /* renamed from: g  reason: collision with root package name */
    public static final Migration f13614g;

    /* renamed from: h  reason: collision with root package name */
    public static final Migration f13615h;

    /* renamed from: i  reason: collision with root package name */
    public static final Migration f13616i;

    /* renamed from: j  reason: collision with root package name */
    public static final List<Migration> f13617j;

    /* renamed from: a  reason: collision with root package name */
    public final int f13618a;

    /* renamed from: b  reason: collision with root package name */
    public boolean f13619b = false;

    public interface Migration {
        void upgrade(SQLiteDatabase sQLiteDatabase);
    }

    static {
        StringBuilder a10 = a.a("INSERT INTO global_log_event_state VALUES (");
        a10.append(System.currentTimeMillis());
        a10.append(")");
        f13610c = a10.toString();
        e eVar = e.f33365a;
        f13612e = eVar;
        f fVar = f.f33366a;
        f13613f = fVar;
        g gVar = g.f33367a;
        f13614g = gVar;
        h hVar = h.f33368a;
        f13615h = hVar;
        i iVar = i.f33369a;
        f13616i = iVar;
        f13617j = Arrays.asList(new Migration[]{eVar, fVar, gVar, hVar, iVar});
    }

    public SchemaManager(Context context, String str, int i10) {
        super(context, str, (SQLiteDatabase.CursorFactory) null, i10);
        this.f13618a = i10;
    }

    public final void a(SQLiteDatabase sQLiteDatabase, int i10, int i11) {
        List<Migration> list = f13617j;
        if (i11 <= list.size()) {
            while (i10 < i11) {
                f13617j.get(i10).upgrade(sQLiteDatabase);
                i10++;
            }
            return;
        }
        StringBuilder a10 = d.a("Migration from ", i10, " to ", i11, " was requested, but cannot be performed. Only ");
        a10.append(list.size());
        a10.append(" migrations are provided");
        throw new IllegalArgumentException(a10.toString());
    }

    public void onConfigure(SQLiteDatabase sQLiteDatabase) {
        this.f13619b = true;
        sQLiteDatabase.rawQuery("PRAGMA busy_timeout=0;", new String[0]).close();
        sQLiteDatabase.setForeignKeyConstraintsEnabled(true);
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        int i10 = this.f13618a;
        if (!this.f13619b) {
            onConfigure(sQLiteDatabase);
        }
        a(sQLiteDatabase, 0, i10);
    }

    public void onDowngrade(SQLiteDatabase sQLiteDatabase, int i10, int i11) {
        sQLiteDatabase.execSQL("DROP TABLE events");
        sQLiteDatabase.execSQL("DROP TABLE event_metadata");
        sQLiteDatabase.execSQL("DROP TABLE transport_contexts");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS event_payloads");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS log_event_dropped");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS global_log_event_state");
        if (!this.f13619b) {
            onConfigure(sQLiteDatabase);
        }
        a(sQLiteDatabase, 0, i11);
    }

    public void onOpen(SQLiteDatabase sQLiteDatabase) {
        if (!this.f13619b) {
            onConfigure(sQLiteDatabase);
        }
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i10, int i11) {
        if (!this.f13619b) {
            onConfigure(sQLiteDatabase);
        }
        a(sQLiteDatabase, i10, i11);
    }
}
