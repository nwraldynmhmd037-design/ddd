package com.google.android.datatransport.runtime.scheduling.persistence;

import com.google.android.datatransport.runtime.dagger.internal.Factory;
import com.google.android.datatransport.runtime.dagger.internal.Preconditions;
import e5.c;

public final class EventStoreModule_StoreConfigFactory implements Factory<c> {

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public static final EventStoreModule_StoreConfigFactory f13607a = new EventStoreModule_StoreConfigFactory();
    }

    public static EventStoreModule_StoreConfigFactory create() {
        return a.f13607a;
    }

    public static c storeConfig() {
        return (c) Preconditions.checkNotNull(EventStoreModule.storeConfig(), "Cannot return null from a non-@Nullable @Provides method");
    }

    public c get() {
        return storeConfig();
    }
}
