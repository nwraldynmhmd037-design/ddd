package com.google.android.datatransport.runtime;

import android.content.Context;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import b5.b;
import b5.e;
import b5.f;
import com.google.android.datatransport.Encoding;
import com.google.android.datatransport.TransportFactory;
import com.google.android.datatransport.TransportScheduleCallback;
import com.google.android.datatransport.runtime.dagger.internal.Preconditions;
import com.google.android.datatransport.runtime.scheduling.Scheduler;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.Uploader;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.WorkInitializer;
import com.google.android.datatransport.runtime.time.Clock;
import com.google.android.datatransport.runtime.time.Monotonic;
import com.google.android.datatransport.runtime.time.WallTime;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.Callable;

public class TransportRuntime implements f {
    private static volatile e instance;
    private final Clock eventClock;
    private final Scheduler scheduler;
    private final Uploader uploader;
    private final Clock uptimeClock;

    public TransportRuntime(@WallTime Clock clock, @Monotonic Clock clock2, Scheduler scheduler2, Uploader uploader2, WorkInitializer workInitializer) {
        this.eventClock = clock;
        this.uptimeClock = clock2;
        this.scheduler = scheduler2;
        this.uploader = uploader2;
        workInitializer.ensureContextsScheduled();
    }

    private EventInternal convert(SendRequest sendRequest) {
        return EventInternal.builder().setEventMillis(this.eventClock.getTime()).setUptimeMillis(this.uptimeClock.getTime()).setTransportName(sendRequest.e()).setEncodedPayload(new EncodedPayload(sendRequest.a(), sendRequest.c().apply(sendRequest.b().getPayload()))).setCode(sendRequest.b().getCode()).build();
    }

    public static TransportRuntime getInstance() {
        e eVar = instance;
        if (eVar != null) {
            return ((b) eVar).f2524m.get();
        }
        throw new IllegalStateException("Not initialized!");
    }

    private static Set<Encoding> getSupportedEncodings(Destination destination) {
        if (destination instanceof EncodedDestination) {
            return Collections.unmodifiableSet(((EncodedDestination) destination).getSupportedEncodings());
        }
        return Collections.singleton(Encoding.of("proto"));
    }

    public static void initialize(Context context) {
        if (instance == null) {
            synchronized (TransportRuntime.class) {
                if (instance == null) {
                    Context context2 = (Context) Preconditions.checkNotNull(context);
                    Preconditions.checkBuilderRequirement(context2, Context.class);
                    instance = new b(context2, (b.a) null);
                }
            }
        }
    }

    @RestrictTo({RestrictTo.Scope.TESTS})
    @VisibleForTesting
    public static void withInstance(e eVar, Callable<Void> callable) throws Throwable {
        e eVar2;
        Class<TransportRuntime> cls = TransportRuntime.class;
        synchronized (cls) {
            eVar2 = instance;
            instance = eVar;
        }
        try {
            callable.call();
            synchronized (cls) {
                instance = eVar2;
            }
        } catch (Throwable th2) {
            synchronized (cls) {
                instance = eVar2;
                throw th2;
            }
        }
    }

    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Uploader getUploader() {
        return this.uploader;
    }

    @Deprecated
    public TransportFactory newFactory(String str) {
        return new e(getSupportedEncodings((Destination) null), TransportContext.builder().setBackendName(str).build(), this);
    }

    public void send(SendRequest sendRequest, TransportScheduleCallback transportScheduleCallback) {
        this.scheduler.schedule(sendRequest.d().withPriority(sendRequest.b().getPriority()), convert(sendRequest), transportScheduleCallback);
    }

    public TransportFactory newFactory(Destination destination) {
        return new e(getSupportedEncodings(destination), TransportContext.builder().setBackendName(destination.getName()).setExtras(destination.getExtras()).build(), this);
    }
}
