package com.google.android.datatransport.runtime;

import androidx.annotation.WorkerThread;
import com.google.android.datatransport.Priority;
import com.google.android.datatransport.Transport;
import com.google.android.datatransport.runtime.logging.Logging;

public final class ForcedSender {
    private static final String LOG_TAG = "ForcedSender";

    private ForcedSender() {
    }

    @WorkerThread
    public static void sendBlocking(Transport<?> transport, Priority priority) {
        if (transport instanceof d) {
            TransportRuntime.getInstance().getUploader().logAndUpdateState(((d) transport).f13592a.withPriority(priority), 1);
            return;
        }
        Logging.w(LOG_TAG, "Expected instance of `TransportImpl`, got `%s`.", transport);
    }
}
