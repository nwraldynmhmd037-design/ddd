package com.google.android.datatransport.runtime.dagger.internal;

import com.google.android.datatransport.runtime.dagger.Lazy;
import com.google.android.datatransport.runtime.dagger.internal.AbstractMapFactory;
import java.util.Map;

public final class MapProviderFactory<K, V> extends AbstractMapFactory<K, V, sf.a<V>> implements Lazy<Map<K, sf.a<V>>> {

    public static final class Builder<K, V> extends AbstractMapFactory.Builder<K, V, sf.a<V>> {
        public MapProviderFactory<K, V> build() {
            return new MapProviderFactory<>(this.map);
        }

        private Builder(int i10) {
            super(i10);
        }

        public Builder<K, V> put(K k10, sf.a<V> aVar) {
            super.put(k10, aVar);
            return this;
        }

        public Builder<K, V> putAll(sf.a<Map<K, sf.a<V>>> aVar) {
            super.putAll(aVar);
            return this;
        }
    }

    public static <K, V> Builder<K, V> builder(int i10) {
        return new Builder<>(i10);
    }

    private MapProviderFactory(Map<K, sf.a<V>> map) {
        super(map);
    }

    public Map<K, sf.a<V>> get() {
        return contributingMap();
    }
}
