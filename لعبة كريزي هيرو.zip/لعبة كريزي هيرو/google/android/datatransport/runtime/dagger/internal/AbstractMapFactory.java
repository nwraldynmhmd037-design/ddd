package com.google.android.datatransport.runtime.dagger.internal;

import com.ironsource.mediationsdk.utils.IronSourceConstants;
import com.ironsource.sdk.constants.a;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import sf.a;

public abstract class AbstractMapFactory<K, V, V2> implements Factory<Map<K, V2>> {
    /* access modifiers changed from: private */
    public final Map<K, a<V>> contributingMap;

    public static abstract class Builder<K, V, V2> {
        public final LinkedHashMap<K, a<V>> map;

        public Builder(int i10) {
            this.map = DaggerCollections.newLinkedHashMapWithExpectedSize(i10);
        }

        public Builder<K, V, V2> put(K k10, a<V> aVar) {
            this.map.put(Preconditions.checkNotNull(k10, a.h.W), Preconditions.checkNotNull(aVar, IronSourceConstants.EVENTS_PROVIDER));
            return this;
        }

        public Builder<K, V, V2> putAll(sf.a<Map<K, V2>> aVar) {
            if (aVar instanceof DelegateFactory) {
                return putAll(((DelegateFactory) aVar).getDelegate());
            }
            this.map.putAll(((AbstractMapFactory) aVar).contributingMap);
            return this;
        }
    }

    public AbstractMapFactory(Map<K, sf.a<V>> map) {
        this.contributingMap = Collections.unmodifiableMap(map);
    }

    public final Map<K, sf.a<V>> contributingMap() {
        return this.contributingMap;
    }
}
