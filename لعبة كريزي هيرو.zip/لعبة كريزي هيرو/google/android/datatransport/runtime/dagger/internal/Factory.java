package com.google.android.datatransport.runtime.dagger.internal;

import sf.a;

public interface Factory<T> extends a<T> {
    /* synthetic */ T get();
}
