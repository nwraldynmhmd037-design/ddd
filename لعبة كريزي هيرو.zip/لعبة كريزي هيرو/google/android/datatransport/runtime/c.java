package com.google.android.datatransport.runtime;

import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import com.google.android.datatransport.Priority;
import com.google.android.datatransport.runtime.TransportContext;
import java.util.Arrays;
import java.util.Objects;

/* compiled from: AutoValue_TransportContext */
public final class c extends TransportContext {

    /* renamed from: a  reason: collision with root package name */
    public final String f13586a;

    /* renamed from: b  reason: collision with root package name */
    public final byte[] f13587b;

    /* renamed from: c  reason: collision with root package name */
    public final Priority f13588c;

    /* compiled from: AutoValue_TransportContext */
    public static final class b extends TransportContext.Builder {

        /* renamed from: a  reason: collision with root package name */
        public String f13589a;

        /* renamed from: b  reason: collision with root package name */
        public byte[] f13590b;

        /* renamed from: c  reason: collision with root package name */
        public Priority f13591c;

        public TransportContext build() {
            String str = this.f13589a == null ? " backendName" : "";
            if (this.f13591c == null) {
                str = l.a.a(str, " priority");
            }
            if (str.isEmpty()) {
                return new c(this.f13589a, this.f13590b, this.f13591c, (a) null);
            }
            throw new IllegalStateException(l.a.a("Missing required properties:", str));
        }

        public TransportContext.Builder setBackendName(String str) {
            Objects.requireNonNull(str, "Null backendName");
            this.f13589a = str;
            return this;
        }

        public TransportContext.Builder setExtras(@Nullable byte[] bArr) {
            this.f13590b = bArr;
            return this;
        }

        public TransportContext.Builder setPriority(Priority priority) {
            Objects.requireNonNull(priority, "Null priority");
            this.f13591c = priority;
            return this;
        }
    }

    public c(String str, byte[] bArr, Priority priority, a aVar) {
        this.f13586a = str;
        this.f13587b = bArr;
        this.f13588c = priority;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof TransportContext)) {
            return false;
        }
        TransportContext transportContext = (TransportContext) obj;
        if (this.f13586a.equals(transportContext.getBackendName())) {
            if (!Arrays.equals(this.f13587b, transportContext instanceof c ? ((c) transportContext).f13587b : transportContext.getExtras()) || !this.f13588c.equals(transportContext.getPriority())) {
                return false;
            }
            return true;
        }
        return false;
    }

    public String getBackendName() {
        return this.f13586a;
    }

    @Nullable
    public byte[] getExtras() {
        return this.f13587b;
    }

    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Priority getPriority() {
        return this.f13588c;
    }

    public int hashCode() {
        return ((((this.f13586a.hashCode() ^ 1000003) * 1000003) ^ Arrays.hashCode(this.f13587b)) * 1000003) ^ this.f13588c.hashCode();
    }
}
