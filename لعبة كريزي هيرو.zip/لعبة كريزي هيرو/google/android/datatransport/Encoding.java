package com.google.android.datatransport;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import d.a;
import h.b;
import java.util.Objects;

public final class Encoding {
    private final String name;

    private Encoding(@NonNull String str) {
        Objects.requireNonNull(str, "name is null");
        this.name = str;
    }

    public static Encoding of(@NonNull String str) {
        return new Encoding(str);
    }

    public boolean equals(@Nullable Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Encoding)) {
            return false;
        }
        return this.name.equals(((Encoding) obj).name);
    }

    public String getName() {
        return this.name;
    }

    public int hashCode() {
        return this.name.hashCode() ^ 1000003;
    }

    @NonNull
    public String toString() {
        return b.a(a.a("Encoding{name=\""), this.name, "\"}");
    }
}
