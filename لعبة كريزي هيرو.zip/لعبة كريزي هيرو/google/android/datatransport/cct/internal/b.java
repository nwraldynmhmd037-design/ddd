package com.google.android.datatransport.cct.internal;

import androidx.annotation.Nullable;
import com.google.android.datatransport.cct.internal.ClientInfo;

/* compiled from: AutoValue_ClientInfo */
public final class b extends ClientInfo {

    /* renamed from: a  reason: collision with root package name */
    public final ClientInfo.ClientType f13500a;

    /* renamed from: b  reason: collision with root package name */
    public final AndroidClientInfo f13501b;

    /* renamed from: com.google.android.datatransport.cct.internal.b$b  reason: collision with other inner class name */
    /* compiled from: AutoValue_ClientInfo */
    public static final class C0212b extends ClientInfo.Builder {

        /* renamed from: a  reason: collision with root package name */
        public ClientInfo.ClientType f13502a;

        /* renamed from: b  reason: collision with root package name */
        public AndroidClientInfo f13503b;

        public ClientInfo build() {
            return new b(this.f13502a, this.f13503b, (a) null);
        }

        public ClientInfo.Builder setAndroidClientInfo(@Nullable AndroidClientInfo androidClientInfo) {
            this.f13503b = androidClientInfo;
            return this;
        }

        public ClientInfo.Builder setClientType(@Nullable ClientInfo.ClientType clientType) {
            this.f13502a = clientType;
            return this;
        }
    }

    public b(ClientInfo.ClientType clientType, AndroidClientInfo androidClientInfo, a aVar) {
        this.f13500a = clientType;
        this.f13501b = androidClientInfo;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ClientInfo)) {
            return false;
        }
        ClientInfo clientInfo = (ClientInfo) obj;
        ClientInfo.ClientType clientType = this.f13500a;
        if (clientType != null ? clientType.equals(clientInfo.getClientType()) : clientInfo.getClientType() == null) {
            AndroidClientInfo androidClientInfo = this.f13501b;
            if (androidClientInfo == null) {
                if (clientInfo.getAndroidClientInfo() == null) {
                    return true;
                }
            } else if (androidClientInfo.equals(clientInfo.getAndroidClientInfo())) {
                return true;
            }
        }
        return false;
    }

    @Nullable
    public AndroidClientInfo getAndroidClientInfo() {
        return this.f13501b;
    }

    @Nullable
    public ClientInfo.ClientType getClientType() {
        return this.f13500a;
    }

    public int hashCode() {
        ClientInfo.ClientType clientType = this.f13500a;
        int i10 = 0;
        int hashCode = ((clientType == null ? 0 : clientType.hashCode()) ^ 1000003) * 1000003;
        AndroidClientInfo androidClientInfo = this.f13501b;
        if (androidClientInfo != null) {
            i10 = androidClientInfo.hashCode();
        }
        return hashCode ^ i10;
    }

    public String toString() {
        StringBuilder a10 = d.a.a("ClientInfo{clientType=");
        a10.append(this.f13500a);
        a10.append(", androidClientInfo=");
        a10.append(this.f13501b);
        a10.append("}");
        return a10.toString();
    }
}
