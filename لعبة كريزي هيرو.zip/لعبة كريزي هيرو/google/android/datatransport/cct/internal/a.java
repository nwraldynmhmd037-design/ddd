package com.google.android.datatransport.cct.internal;

import androidx.annotation.Nullable;
import com.google.android.datatransport.cct.internal.AndroidClientInfo;

/* compiled from: AutoValue_AndroidClientInfo */
public final class a extends AndroidClientInfo {

    /* renamed from: a  reason: collision with root package name */
    public final Integer f13476a;

    /* renamed from: b  reason: collision with root package name */
    public final String f13477b;

    /* renamed from: c  reason: collision with root package name */
    public final String f13478c;

    /* renamed from: d  reason: collision with root package name */
    public final String f13479d;

    /* renamed from: e  reason: collision with root package name */
    public final String f13480e;

    /* renamed from: f  reason: collision with root package name */
    public final String f13481f;

    /* renamed from: g  reason: collision with root package name */
    public final String f13482g;

    /* renamed from: h  reason: collision with root package name */
    public final String f13483h;

    /* renamed from: i  reason: collision with root package name */
    public final String f13484i;

    /* renamed from: j  reason: collision with root package name */
    public final String f13485j;

    /* renamed from: k  reason: collision with root package name */
    public final String f13486k;

    /* renamed from: l  reason: collision with root package name */
    public final String f13487l;

    /* compiled from: AutoValue_AndroidClientInfo */
    public static final class b extends AndroidClientInfo.Builder {

        /* renamed from: a  reason: collision with root package name */
        public Integer f13488a;

        /* renamed from: b  reason: collision with root package name */
        public String f13489b;

        /* renamed from: c  reason: collision with root package name */
        public String f13490c;

        /* renamed from: d  reason: collision with root package name */
        public String f13491d;

        /* renamed from: e  reason: collision with root package name */
        public String f13492e;

        /* renamed from: f  reason: collision with root package name */
        public String f13493f;

        /* renamed from: g  reason: collision with root package name */
        public String f13494g;

        /* renamed from: h  reason: collision with root package name */
        public String f13495h;

        /* renamed from: i  reason: collision with root package name */
        public String f13496i;

        /* renamed from: j  reason: collision with root package name */
        public String f13497j;

        /* renamed from: k  reason: collision with root package name */
        public String f13498k;

        /* renamed from: l  reason: collision with root package name */
        public String f13499l;

        public AndroidClientInfo build() {
            return new a(this.f13488a, this.f13489b, this.f13490c, this.f13491d, this.f13492e, this.f13493f, this.f13494g, this.f13495h, this.f13496i, this.f13497j, this.f13498k, this.f13499l, (C0211a) null);
        }

        public AndroidClientInfo.Builder setApplicationBuild(@Nullable String str) {
            this.f13499l = str;
            return this;
        }

        public AndroidClientInfo.Builder setCountry(@Nullable String str) {
            this.f13497j = str;
            return this;
        }

        public AndroidClientInfo.Builder setDevice(@Nullable String str) {
            this.f13491d = str;
            return this;
        }

        public AndroidClientInfo.Builder setFingerprint(@Nullable String str) {
            this.f13495h = str;
            return this;
        }

        public AndroidClientInfo.Builder setHardware(@Nullable String str) {
            this.f13490c = str;
            return this;
        }

        public AndroidClientInfo.Builder setLocale(@Nullable String str) {
            this.f13496i = str;
            return this;
        }

        public AndroidClientInfo.Builder setManufacturer(@Nullable String str) {
            this.f13494g = str;
            return this;
        }

        public AndroidClientInfo.Builder setMccMnc(@Nullable String str) {
            this.f13498k = str;
            return this;
        }

        public AndroidClientInfo.Builder setModel(@Nullable String str) {
            this.f13489b = str;
            return this;
        }

        public AndroidClientInfo.Builder setOsBuild(@Nullable String str) {
            this.f13493f = str;
            return this;
        }

        public AndroidClientInfo.Builder setProduct(@Nullable String str) {
            this.f13492e = str;
            return this;
        }

        public AndroidClientInfo.Builder setSdkVersion(@Nullable Integer num) {
            this.f13488a = num;
            return this;
        }
    }

    public a(Integer num, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, C0211a aVar) {
        this.f13476a = num;
        this.f13477b = str;
        this.f13478c = str2;
        this.f13479d = str3;
        this.f13480e = str4;
        this.f13481f = str5;
        this.f13482g = str6;
        this.f13483h = str7;
        this.f13484i = str8;
        this.f13485j = str9;
        this.f13486k = str10;
        this.f13487l = str11;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof AndroidClientInfo)) {
            return false;
        }
        AndroidClientInfo androidClientInfo = (AndroidClientInfo) obj;
        Integer num = this.f13476a;
        if (num != null ? num.equals(androidClientInfo.getSdkVersion()) : androidClientInfo.getSdkVersion() == null) {
            String str = this.f13477b;
            if (str != null ? str.equals(androidClientInfo.getModel()) : androidClientInfo.getModel() == null) {
                String str2 = this.f13478c;
                if (str2 != null ? str2.equals(androidClientInfo.getHardware()) : androidClientInfo.getHardware() == null) {
                    String str3 = this.f13479d;
                    if (str3 != null ? str3.equals(androidClientInfo.getDevice()) : androidClientInfo.getDevice() == null) {
                        String str4 = this.f13480e;
                        if (str4 != null ? str4.equals(androidClientInfo.getProduct()) : androidClientInfo.getProduct() == null) {
                            String str5 = this.f13481f;
                            if (str5 != null ? str5.equals(androidClientInfo.getOsBuild()) : androidClientInfo.getOsBuild() == null) {
                                String str6 = this.f13482g;
                                if (str6 != null ? str6.equals(androidClientInfo.getManufacturer()) : androidClientInfo.getManufacturer() == null) {
                                    String str7 = this.f13483h;
                                    if (str7 != null ? str7.equals(androidClientInfo.getFingerprint()) : androidClientInfo.getFingerprint() == null) {
                                        String str8 = this.f13484i;
                                        if (str8 != null ? str8.equals(androidClientInfo.getLocale()) : androidClientInfo.getLocale() == null) {
                                            String str9 = this.f13485j;
                                            if (str9 != null ? str9.equals(androidClientInfo.getCountry()) : androidClientInfo.getCountry() == null) {
                                                String str10 = this.f13486k;
                                                if (str10 != null ? str10.equals(androidClientInfo.getMccMnc()) : androidClientInfo.getMccMnc() == null) {
                                                    String str11 = this.f13487l;
                                                    if (str11 == null) {
                                                        if (androidClientInfo.getApplicationBuild() == null) {
                                                            return true;
                                                        }
                                                    } else if (str11.equals(androidClientInfo.getApplicationBuild())) {
                                                        return true;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    @Nullable
    public String getApplicationBuild() {
        return this.f13487l;
    }

    @Nullable
    public String getCountry() {
        return this.f13485j;
    }

    @Nullable
    public String getDevice() {
        return this.f13479d;
    }

    @Nullable
    public String getFingerprint() {
        return this.f13483h;
    }

    @Nullable
    public String getHardware() {
        return this.f13478c;
    }

    @Nullable
    public String getLocale() {
        return this.f13484i;
    }

    @Nullable
    public String getManufacturer() {
        return this.f13482g;
    }

    @Nullable
    public String getMccMnc() {
        return this.f13486k;
    }

    @Nullable
    public String getModel() {
        return this.f13477b;
    }

    @Nullable
    public String getOsBuild() {
        return this.f13481f;
    }

    @Nullable
    public String getProduct() {
        return this.f13480e;
    }

    @Nullable
    public Integer getSdkVersion() {
        return this.f13476a;
    }

    public int hashCode() {
        Integer num = this.f13476a;
        int i10 = 0;
        int hashCode = ((num == null ? 0 : num.hashCode()) ^ 1000003) * 1000003;
        String str = this.f13477b;
        int hashCode2 = (hashCode ^ (str == null ? 0 : str.hashCode())) * 1000003;
        String str2 = this.f13478c;
        int hashCode3 = (hashCode2 ^ (str2 == null ? 0 : str2.hashCode())) * 1000003;
        String str3 = this.f13479d;
        int hashCode4 = (hashCode3 ^ (str3 == null ? 0 : str3.hashCode())) * 1000003;
        String str4 = this.f13480e;
        int hashCode5 = (hashCode4 ^ (str4 == null ? 0 : str4.hashCode())) * 1000003;
        String str5 = this.f13481f;
        int hashCode6 = (hashCode5 ^ (str5 == null ? 0 : str5.hashCode())) * 1000003;
        String str6 = this.f13482g;
        int hashCode7 = (hashCode6 ^ (str6 == null ? 0 : str6.hashCode())) * 1000003;
        String str7 = this.f13483h;
        int hashCode8 = (hashCode7 ^ (str7 == null ? 0 : str7.hashCode())) * 1000003;
        String str8 = this.f13484i;
        int hashCode9 = (hashCode8 ^ (str8 == null ? 0 : str8.hashCode())) * 1000003;
        String str9 = this.f13485j;
        int hashCode10 = (hashCode9 ^ (str9 == null ? 0 : str9.hashCode())) * 1000003;
        String str10 = this.f13486k;
        int hashCode11 = (hashCode10 ^ (str10 == null ? 0 : str10.hashCode())) * 1000003;
        String str11 = this.f13487l;
        if (str11 != null) {
            i10 = str11.hashCode();
        }
        return hashCode11 ^ i10;
    }

    public String toString() {
        StringBuilder a10 = d.a.a("AndroidClientInfo{sdkVersion=");
        a10.append(this.f13476a);
        a10.append(", model=");
        a10.append(this.f13477b);
        a10.append(", hardware=");
        a10.append(this.f13478c);
        a10.append(", device=");
        a10.append(this.f13479d);
        a10.append(", product=");
        a10.append(this.f13480e);
        a10.append(", osBuild=");
        a10.append(this.f13481f);
        a10.append(", manufacturer=");
        a10.append(this.f13482g);
        a10.append(", fingerprint=");
        a10.append(this.f13483h);
        a10.append(", locale=");
        a10.append(this.f13484i);
        a10.append(", country=");
        a10.append(this.f13485j);
        a10.append(", mccMnc=");
        a10.append(this.f13486k);
        a10.append(", applicationBuild=");
        return h.b.a(a10, this.f13487l, "}");
    }
}
