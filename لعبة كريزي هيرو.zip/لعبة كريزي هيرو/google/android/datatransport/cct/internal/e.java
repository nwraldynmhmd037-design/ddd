package com.google.android.datatransport.cct.internal;

import androidx.annotation.Nullable;
import com.google.android.datatransport.cct.internal.NetworkConnectionInfo;

/* compiled from: AutoValue_NetworkConnectionInfo */
public final class e extends NetworkConnectionInfo {

    /* renamed from: a  reason: collision with root package name */
    public final NetworkConnectionInfo.NetworkType f13532a;

    /* renamed from: b  reason: collision with root package name */
    public final NetworkConnectionInfo.MobileSubtype f13533b;

    /* compiled from: AutoValue_NetworkConnectionInfo */
    public static final class b extends NetworkConnectionInfo.Builder {

        /* renamed from: a  reason: collision with root package name */
        public NetworkConnectionInfo.NetworkType f13534a;

        /* renamed from: b  reason: collision with root package name */
        public NetworkConnectionInfo.MobileSubtype f13535b;

        public NetworkConnectionInfo build() {
            return new e(this.f13534a, this.f13535b, (a) null);
        }

        public NetworkConnectionInfo.Builder setMobileSubtype(@Nullable NetworkConnectionInfo.MobileSubtype mobileSubtype) {
            this.f13535b = mobileSubtype;
            return this;
        }

        public NetworkConnectionInfo.Builder setNetworkType(@Nullable NetworkConnectionInfo.NetworkType networkType) {
            this.f13534a = networkType;
            return this;
        }
    }

    public e(NetworkConnectionInfo.NetworkType networkType, NetworkConnectionInfo.MobileSubtype mobileSubtype, a aVar) {
        this.f13532a = networkType;
        this.f13533b = mobileSubtype;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof NetworkConnectionInfo)) {
            return false;
        }
        NetworkConnectionInfo networkConnectionInfo = (NetworkConnectionInfo) obj;
        NetworkConnectionInfo.NetworkType networkType = this.f13532a;
        if (networkType != null ? networkType.equals(networkConnectionInfo.getNetworkType()) : networkConnectionInfo.getNetworkType() == null) {
            NetworkConnectionInfo.MobileSubtype mobileSubtype = this.f13533b;
            if (mobileSubtype == null) {
                if (networkConnectionInfo.getMobileSubtype() == null) {
                    return true;
                }
            } else if (mobileSubtype.equals(networkConnectionInfo.getMobileSubtype())) {
                return true;
            }
        }
        return false;
    }

    @Nullable
    public NetworkConnectionInfo.MobileSubtype getMobileSubtype() {
        return this.f13533b;
    }

    @Nullable
    public NetworkConnectionInfo.NetworkType getNetworkType() {
        return this.f13532a;
    }

    public int hashCode() {
        NetworkConnectionInfo.NetworkType networkType = this.f13532a;
        int i10 = 0;
        int hashCode = ((networkType == null ? 0 : networkType.hashCode()) ^ 1000003) * 1000003;
        NetworkConnectionInfo.MobileSubtype mobileSubtype = this.f13533b;
        if (mobileSubtype != null) {
            i10 = mobileSubtype.hashCode();
        }
        return hashCode ^ i10;
    }

    public String toString() {
        StringBuilder a10 = d.a.a("NetworkConnectionInfo{networkType=");
        a10.append(this.f13532a);
        a10.append(", mobileSubtype=");
        a10.append(this.f13533b);
        a10.append("}");
        return a10.toString();
    }
}
