package com.google.android.datatransport.cct.internal;

import androidx.annotation.Nullable;
import com.google.android.datatransport.cct.internal.LogRequest;
import com.google.firebase.encoders.annotations.Encodable;
import java.util.List;

/* compiled from: AutoValue_LogRequest */
public final class d extends LogRequest {

    /* renamed from: a  reason: collision with root package name */
    public final long f13518a;

    /* renamed from: b  reason: collision with root package name */
    public final long f13519b;

    /* renamed from: c  reason: collision with root package name */
    public final ClientInfo f13520c;

    /* renamed from: d  reason: collision with root package name */
    public final Integer f13521d;

    /* renamed from: e  reason: collision with root package name */
    public final String f13522e;

    /* renamed from: f  reason: collision with root package name */
    public final List<LogEvent> f13523f;

    /* renamed from: g  reason: collision with root package name */
    public final QosTier f13524g;

    /* compiled from: AutoValue_LogRequest */
    public static final class b extends LogRequest.Builder {

        /* renamed from: a  reason: collision with root package name */
        public Long f13525a;

        /* renamed from: b  reason: collision with root package name */
        public Long f13526b;

        /* renamed from: c  reason: collision with root package name */
        public ClientInfo f13527c;

        /* renamed from: d  reason: collision with root package name */
        public Integer f13528d;

        /* renamed from: e  reason: collision with root package name */
        public String f13529e;

        /* renamed from: f  reason: collision with root package name */
        public List<LogEvent> f13530f;

        /* renamed from: g  reason: collision with root package name */
        public QosTier f13531g;

        public LogRequest build() {
            String str = this.f13525a == null ? " requestTimeMs" : "";
            if (this.f13526b == null) {
                str = l.a.a(str, " requestUptimeMs");
            }
            if (str.isEmpty()) {
                return new d(this.f13525a.longValue(), this.f13526b.longValue(), this.f13527c, this.f13528d, this.f13529e, this.f13530f, this.f13531g, (a) null);
            }
            throw new IllegalStateException(l.a.a("Missing required properties:", str));
        }

        public LogRequest.Builder setClientInfo(@Nullable ClientInfo clientInfo) {
            this.f13527c = clientInfo;
            return this;
        }

        public LogRequest.Builder setLogEvents(@Nullable List<LogEvent> list) {
            this.f13530f = list;
            return this;
        }

        public LogRequest.Builder setLogSource(@Nullable Integer num) {
            this.f13528d = num;
            return this;
        }

        public LogRequest.Builder setLogSourceName(@Nullable String str) {
            this.f13529e = str;
            return this;
        }

        public LogRequest.Builder setQosTier(@Nullable QosTier qosTier) {
            this.f13531g = qosTier;
            return this;
        }

        public LogRequest.Builder setRequestTimeMs(long j10) {
            this.f13525a = Long.valueOf(j10);
            return this;
        }

        public LogRequest.Builder setRequestUptimeMs(long j10) {
            this.f13526b = Long.valueOf(j10);
            return this;
        }
    }

    public d(long j10, long j11, ClientInfo clientInfo, Integer num, String str, List list, QosTier qosTier, a aVar) {
        this.f13518a = j10;
        this.f13519b = j11;
        this.f13520c = clientInfo;
        this.f13521d = num;
        this.f13522e = str;
        this.f13523f = list;
        this.f13524g = qosTier;
    }

    public boolean equals(Object obj) {
        ClientInfo clientInfo;
        Integer num;
        String str;
        List<LogEvent> list;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof LogRequest)) {
            return false;
        }
        LogRequest logRequest = (LogRequest) obj;
        if (this.f13518a == logRequest.getRequestTimeMs() && this.f13519b == logRequest.getRequestUptimeMs() && ((clientInfo = this.f13520c) != null ? clientInfo.equals(logRequest.getClientInfo()) : logRequest.getClientInfo() == null) && ((num = this.f13521d) != null ? num.equals(logRequest.getLogSource()) : logRequest.getLogSource() == null) && ((str = this.f13522e) != null ? str.equals(logRequest.getLogSourceName()) : logRequest.getLogSourceName() == null) && ((list = this.f13523f) != null ? list.equals(logRequest.getLogEvents()) : logRequest.getLogEvents() == null)) {
            QosTier qosTier = this.f13524g;
            if (qosTier == null) {
                if (logRequest.getQosTier() == null) {
                    return true;
                }
            } else if (qosTier.equals(logRequest.getQosTier())) {
                return true;
            }
        }
        return false;
    }

    @Nullable
    public ClientInfo getClientInfo() {
        return this.f13520c;
    }

    @Nullable
    @Encodable.Field(name = "logEvent")
    public List<LogEvent> getLogEvents() {
        return this.f13523f;
    }

    @Nullable
    public Integer getLogSource() {
        return this.f13521d;
    }

    @Nullable
    public String getLogSourceName() {
        return this.f13522e;
    }

    @Nullable
    public QosTier getQosTier() {
        return this.f13524g;
    }

    public long getRequestTimeMs() {
        return this.f13518a;
    }

    public long getRequestUptimeMs() {
        return this.f13519b;
    }

    public int hashCode() {
        long j10 = this.f13518a;
        long j11 = this.f13519b;
        int i10 = (((((int) (j10 ^ (j10 >>> 32))) ^ 1000003) * 1000003) ^ ((int) ((j11 >>> 32) ^ j11))) * 1000003;
        ClientInfo clientInfo = this.f13520c;
        int i11 = 0;
        int hashCode = (i10 ^ (clientInfo == null ? 0 : clientInfo.hashCode())) * 1000003;
        Integer num = this.f13521d;
        int hashCode2 = (hashCode ^ (num == null ? 0 : num.hashCode())) * 1000003;
        String str = this.f13522e;
        int hashCode3 = (hashCode2 ^ (str == null ? 0 : str.hashCode())) * 1000003;
        List<LogEvent> list = this.f13523f;
        int hashCode4 = (hashCode3 ^ (list == null ? 0 : list.hashCode())) * 1000003;
        QosTier qosTier = this.f13524g;
        if (qosTier != null) {
            i11 = qosTier.hashCode();
        }
        return hashCode4 ^ i11;
    }

    public String toString() {
        StringBuilder a10 = d.a.a("LogRequest{requestTimeMs=");
        a10.append(this.f13518a);
        a10.append(", requestUptimeMs=");
        a10.append(this.f13519b);
        a10.append(", clientInfo=");
        a10.append(this.f13520c);
        a10.append(", logSource=");
        a10.append(this.f13521d);
        a10.append(", logSourceName=");
        a10.append(this.f13522e);
        a10.append(", logEvents=");
        a10.append(this.f13523f);
        a10.append(", qosTier=");
        a10.append(this.f13524g);
        a10.append("}");
        return a10.toString();
    }
}
