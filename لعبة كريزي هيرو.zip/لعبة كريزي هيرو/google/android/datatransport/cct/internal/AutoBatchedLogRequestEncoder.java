package com.google.android.datatransport.cct.internal;

import com.applovin.sdk.AppLovinEventTypes;
import com.google.firebase.encoders.FieldDescriptor;
import com.google.firebase.encoders.ObjectEncoder;
import com.google.firebase.encoders.ObjectEncoderContext;
import com.google.firebase.encoders.config.Configurator;
import com.google.firebase.encoders.config.EncoderConfig;
import com.ironsource.mediationsdk.impressionData.ImpressionData;
import com.ironsource.sdk.constants.a;
import java.io.IOException;

public final class AutoBatchedLogRequestEncoder implements Configurator {
    public static final int CODEGEN_VERSION = 2;
    public static final Configurator CONFIG = new AutoBatchedLogRequestEncoder();

    public static final class a implements ObjectEncoder<AndroidClientInfo> {

        /* renamed from: a  reason: collision with root package name */
        public static final a f13439a = new a();

        /* renamed from: b  reason: collision with root package name */
        public static final FieldDescriptor f13440b = FieldDescriptor.of("sdkVersion");

        /* renamed from: c  reason: collision with root package name */
        public static final FieldDescriptor f13441c = FieldDescriptor.of(com.ironsource.environment.globaldata.a.f21985u);

        /* renamed from: d  reason: collision with root package name */
        public static final FieldDescriptor f13442d = FieldDescriptor.of("hardware");

        /* renamed from: e  reason: collision with root package name */
        public static final FieldDescriptor f13443e = FieldDescriptor.of(a.h.G);

        /* renamed from: f  reason: collision with root package name */
        public static final FieldDescriptor f13444f = FieldDescriptor.of(AppLovinEventTypes.USER_VIEWED_PRODUCT);

        /* renamed from: g  reason: collision with root package name */
        public static final FieldDescriptor f13445g = FieldDescriptor.of("osBuild");

        /* renamed from: h  reason: collision with root package name */
        public static final FieldDescriptor f13446h = FieldDescriptor.of("manufacturer");

        /* renamed from: i  reason: collision with root package name */
        public static final FieldDescriptor f13447i = FieldDescriptor.of("fingerprint");

        /* renamed from: j  reason: collision with root package name */
        public static final FieldDescriptor f13448j = FieldDescriptor.of("locale");

        /* renamed from: k  reason: collision with root package name */
        public static final FieldDescriptor f13449k = FieldDescriptor.of(ImpressionData.IMPRESSION_DATA_KEY_COUNTRY);

        /* renamed from: l  reason: collision with root package name */
        public static final FieldDescriptor f13450l = FieldDescriptor.of("mccMnc");

        /* renamed from: m  reason: collision with root package name */
        public static final FieldDescriptor f13451m = FieldDescriptor.of("applicationBuild");

        public void encode(Object obj, Object obj2) throws IOException {
            AndroidClientInfo androidClientInfo = (AndroidClientInfo) obj;
            ObjectEncoderContext objectEncoderContext = (ObjectEncoderContext) obj2;
            objectEncoderContext.add(f13440b, (Object) androidClientInfo.getSdkVersion());
            objectEncoderContext.add(f13441c, (Object) androidClientInfo.getModel());
            objectEncoderContext.add(f13442d, (Object) androidClientInfo.getHardware());
            objectEncoderContext.add(f13443e, (Object) androidClientInfo.getDevice());
            objectEncoderContext.add(f13444f, (Object) androidClientInfo.getProduct());
            objectEncoderContext.add(f13445g, (Object) androidClientInfo.getOsBuild());
            objectEncoderContext.add(f13446h, (Object) androidClientInfo.getManufacturer());
            objectEncoderContext.add(f13447i, (Object) androidClientInfo.getFingerprint());
            objectEncoderContext.add(f13448j, (Object) androidClientInfo.getLocale());
            objectEncoderContext.add(f13449k, (Object) androidClientInfo.getCountry());
            objectEncoderContext.add(f13450l, (Object) androidClientInfo.getMccMnc());
            objectEncoderContext.add(f13451m, (Object) androidClientInfo.getApplicationBuild());
        }
    }

    public static final class b implements ObjectEncoder<BatchedLogRequest> {

        /* renamed from: a  reason: collision with root package name */
        public static final b f13452a = new b();

        /* renamed from: b  reason: collision with root package name */
        public static final FieldDescriptor f13453b = FieldDescriptor.of("logRequest");

        public void encode(Object obj, Object obj2) throws IOException {
            ((ObjectEncoderContext) obj2).add(f13453b, (Object) ((BatchedLogRequest) obj).getLogRequests());
        }
    }

    public static final class c implements ObjectEncoder<ClientInfo> {

        /* renamed from: a  reason: collision with root package name */
        public static final c f13454a = new c();

        /* renamed from: b  reason: collision with root package name */
        public static final FieldDescriptor f13455b = FieldDescriptor.of("clientType");

        /* renamed from: c  reason: collision with root package name */
        public static final FieldDescriptor f13456c = FieldDescriptor.of("androidClientInfo");

        public void encode(Object obj, Object obj2) throws IOException {
            ClientInfo clientInfo = (ClientInfo) obj;
            ObjectEncoderContext objectEncoderContext = (ObjectEncoderContext) obj2;
            objectEncoderContext.add(f13455b, (Object) clientInfo.getClientType());
            objectEncoderContext.add(f13456c, (Object) clientInfo.getAndroidClientInfo());
        }
    }

    public static final class d implements ObjectEncoder<LogEvent> {

        /* renamed from: a  reason: collision with root package name */
        public static final d f13457a = new d();

        /* renamed from: b  reason: collision with root package name */
        public static final FieldDescriptor f13458b = FieldDescriptor.of("eventTimeMs");

        /* renamed from: c  reason: collision with root package name */
        public static final FieldDescriptor f13459c = FieldDescriptor.of("eventCode");

        /* renamed from: d  reason: collision with root package name */
        public static final FieldDescriptor f13460d = FieldDescriptor.of("eventUptimeMs");

        /* renamed from: e  reason: collision with root package name */
        public static final FieldDescriptor f13461e = FieldDescriptor.of("sourceExtension");

        /* renamed from: f  reason: collision with root package name */
        public static final FieldDescriptor f13462f = FieldDescriptor.of("sourceExtensionJsonProto3");

        /* renamed from: g  reason: collision with root package name */
        public static final FieldDescriptor f13463g = FieldDescriptor.of("timezoneOffsetSeconds");

        /* renamed from: h  reason: collision with root package name */
        public static final FieldDescriptor f13464h = FieldDescriptor.of("networkConnectionInfo");

        public void encode(Object obj, Object obj2) throws IOException {
            LogEvent logEvent = (LogEvent) obj;
            ObjectEncoderContext objectEncoderContext = (ObjectEncoderContext) obj2;
            objectEncoderContext.add(f13458b, logEvent.getEventTimeMs());
            objectEncoderContext.add(f13459c, (Object) logEvent.getEventCode());
            objectEncoderContext.add(f13460d, logEvent.getEventUptimeMs());
            objectEncoderContext.add(f13461e, (Object) logEvent.getSourceExtension());
            objectEncoderContext.add(f13462f, (Object) logEvent.getSourceExtensionJsonProto3());
            objectEncoderContext.add(f13463g, logEvent.getTimezoneOffsetSeconds());
            objectEncoderContext.add(f13464h, (Object) logEvent.getNetworkConnectionInfo());
        }
    }

    public static final class e implements ObjectEncoder<LogRequest> {

        /* renamed from: a  reason: collision with root package name */
        public static final e f13465a = new e();

        /* renamed from: b  reason: collision with root package name */
        public static final FieldDescriptor f13466b = FieldDescriptor.of("requestTimeMs");

        /* renamed from: c  reason: collision with root package name */
        public static final FieldDescriptor f13467c = FieldDescriptor.of("requestUptimeMs");

        /* renamed from: d  reason: collision with root package name */
        public static final FieldDescriptor f13468d = FieldDescriptor.of("clientInfo");

        /* renamed from: e  reason: collision with root package name */
        public static final FieldDescriptor f13469e = FieldDescriptor.of("logSource");

        /* renamed from: f  reason: collision with root package name */
        public static final FieldDescriptor f13470f = FieldDescriptor.of("logSourceName");

        /* renamed from: g  reason: collision with root package name */
        public static final FieldDescriptor f13471g = FieldDescriptor.of("logEvent");

        /* renamed from: h  reason: collision with root package name */
        public static final FieldDescriptor f13472h = FieldDescriptor.of("qosTier");

        public void encode(Object obj, Object obj2) throws IOException {
            LogRequest logRequest = (LogRequest) obj;
            ObjectEncoderContext objectEncoderContext = (ObjectEncoderContext) obj2;
            objectEncoderContext.add(f13466b, logRequest.getRequestTimeMs());
            objectEncoderContext.add(f13467c, logRequest.getRequestUptimeMs());
            objectEncoderContext.add(f13468d, (Object) logRequest.getClientInfo());
            objectEncoderContext.add(f13469e, (Object) logRequest.getLogSource());
            objectEncoderContext.add(f13470f, (Object) logRequest.getLogSourceName());
            objectEncoderContext.add(f13471g, (Object) logRequest.getLogEvents());
            objectEncoderContext.add(f13472h, (Object) logRequest.getQosTier());
        }
    }

    public static final class f implements ObjectEncoder<NetworkConnectionInfo> {

        /* renamed from: a  reason: collision with root package name */
        public static final f f13473a = new f();

        /* renamed from: b  reason: collision with root package name */
        public static final FieldDescriptor f13474b = FieldDescriptor.of("networkType");

        /* renamed from: c  reason: collision with root package name */
        public static final FieldDescriptor f13475c = FieldDescriptor.of("mobileSubtype");

        public void encode(Object obj, Object obj2) throws IOException {
            NetworkConnectionInfo networkConnectionInfo = (NetworkConnectionInfo) obj;
            ObjectEncoderContext objectEncoderContext = (ObjectEncoderContext) obj2;
            objectEncoderContext.add(f13474b, (Object) networkConnectionInfo.getNetworkType());
            objectEncoderContext.add(f13475c, (Object) networkConnectionInfo.getMobileSubtype());
        }
    }

    private AutoBatchedLogRequestEncoder() {
    }

    public void configure(EncoderConfig<?> encoderConfig) {
        b bVar = b.f13452a;
        encoderConfig.registerEncoder((Class<U>) BatchedLogRequest.class, (ObjectEncoder<? super U>) bVar);
        encoderConfig.registerEncoder((Class<U>) a5.a.class, (ObjectEncoder<? super U>) bVar);
        e eVar = e.f13465a;
        encoderConfig.registerEncoder((Class<U>) LogRequest.class, (ObjectEncoder<? super U>) eVar);
        encoderConfig.registerEncoder((Class<U>) d.class, (ObjectEncoder<? super U>) eVar);
        c cVar = c.f13454a;
        encoderConfig.registerEncoder((Class<U>) ClientInfo.class, (ObjectEncoder<? super U>) cVar);
        encoderConfig.registerEncoder((Class<U>) b.class, (ObjectEncoder<? super U>) cVar);
        a aVar = a.f13439a;
        encoderConfig.registerEncoder((Class<U>) AndroidClientInfo.class, (ObjectEncoder<? super U>) aVar);
        encoderConfig.registerEncoder((Class<U>) a.class, (ObjectEncoder<? super U>) aVar);
        d dVar = d.f13457a;
        encoderConfig.registerEncoder((Class<U>) LogEvent.class, (ObjectEncoder<? super U>) dVar);
        encoderConfig.registerEncoder((Class<U>) c.class, (ObjectEncoder<? super U>) dVar);
        f fVar = f.f13473a;
        encoderConfig.registerEncoder((Class<U>) NetworkConnectionInfo.class, (ObjectEncoder<? super U>) fVar);
        encoderConfig.registerEncoder((Class<U>) e.class, (ObjectEncoder<? super U>) fVar);
    }
}
