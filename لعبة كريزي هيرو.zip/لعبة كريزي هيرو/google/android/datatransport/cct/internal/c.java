package com.google.android.datatransport.cct.internal;

import androidx.annotation.Nullable;
import com.google.android.datatransport.cct.internal.LogEvent;
import java.util.Arrays;

/* compiled from: AutoValue_LogEvent */
public final class c extends LogEvent {

    /* renamed from: a  reason: collision with root package name */
    public final long f13504a;

    /* renamed from: b  reason: collision with root package name */
    public final Integer f13505b;

    /* renamed from: c  reason: collision with root package name */
    public final long f13506c;

    /* renamed from: d  reason: collision with root package name */
    public final byte[] f13507d;

    /* renamed from: e  reason: collision with root package name */
    public final String f13508e;

    /* renamed from: f  reason: collision with root package name */
    public final long f13509f;

    /* renamed from: g  reason: collision with root package name */
    public final NetworkConnectionInfo f13510g;

    /* compiled from: AutoValue_LogEvent */
    public static final class b extends LogEvent.Builder {

        /* renamed from: a  reason: collision with root package name */
        public Long f13511a;

        /* renamed from: b  reason: collision with root package name */
        public Integer f13512b;

        /* renamed from: c  reason: collision with root package name */
        public Long f13513c;

        /* renamed from: d  reason: collision with root package name */
        public byte[] f13514d;

        /* renamed from: e  reason: collision with root package name */
        public String f13515e;

        /* renamed from: f  reason: collision with root package name */
        public Long f13516f;

        /* renamed from: g  reason: collision with root package name */
        public NetworkConnectionInfo f13517g;

        public LogEvent build() {
            String str = this.f13511a == null ? " eventTimeMs" : "";
            if (this.f13513c == null) {
                str = l.a.a(str, " eventUptimeMs");
            }
            if (this.f13516f == null) {
                str = l.a.a(str, " timezoneOffsetSeconds");
            }
            if (str.isEmpty()) {
                return new c(this.f13511a.longValue(), this.f13512b, this.f13513c.longValue(), this.f13514d, this.f13515e, this.f13516f.longValue(), this.f13517g, (a) null);
            }
            throw new IllegalStateException(l.a.a("Missing required properties:", str));
        }

        public LogEvent.Builder setEventCode(@Nullable Integer num) {
            this.f13512b = num;
            return this;
        }

        public LogEvent.Builder setEventTimeMs(long j10) {
            this.f13511a = Long.valueOf(j10);
            return this;
        }

        public LogEvent.Builder setEventUptimeMs(long j10) {
            this.f13513c = Long.valueOf(j10);
            return this;
        }

        public LogEvent.Builder setNetworkConnectionInfo(@Nullable NetworkConnectionInfo networkConnectionInfo) {
            this.f13517g = networkConnectionInfo;
            return this;
        }

        public LogEvent.Builder setSourceExtension(@Nullable byte[] bArr) {
            this.f13514d = bArr;
            return this;
        }

        public LogEvent.Builder setSourceExtensionJsonProto3(@Nullable String str) {
            this.f13515e = str;
            return this;
        }

        public LogEvent.Builder setTimezoneOffsetSeconds(long j10) {
            this.f13516f = Long.valueOf(j10);
            return this;
        }
    }

    public c(long j10, Integer num, long j11, byte[] bArr, String str, long j12, NetworkConnectionInfo networkConnectionInfo, a aVar) {
        this.f13504a = j10;
        this.f13505b = num;
        this.f13506c = j11;
        this.f13507d = bArr;
        this.f13508e = str;
        this.f13509f = j12;
        this.f13510g = networkConnectionInfo;
    }

    public boolean equals(Object obj) {
        Integer num;
        String str;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof LogEvent)) {
            return false;
        }
        LogEvent logEvent = (LogEvent) obj;
        if (this.f13504a == logEvent.getEventTimeMs() && ((num = this.f13505b) != null ? num.equals(logEvent.getEventCode()) : logEvent.getEventCode() == null) && this.f13506c == logEvent.getEventUptimeMs()) {
            if (Arrays.equals(this.f13507d, logEvent instanceof c ? ((c) logEvent).f13507d : logEvent.getSourceExtension()) && ((str = this.f13508e) != null ? str.equals(logEvent.getSourceExtensionJsonProto3()) : logEvent.getSourceExtensionJsonProto3() == null) && this.f13509f == logEvent.getTimezoneOffsetSeconds()) {
                NetworkConnectionInfo networkConnectionInfo = this.f13510g;
                if (networkConnectionInfo == null) {
                    if (logEvent.getNetworkConnectionInfo() == null) {
                        return true;
                    }
                } else if (networkConnectionInfo.equals(logEvent.getNetworkConnectionInfo())) {
                    return true;
                }
            }
        }
        return false;
    }

    @Nullable
    public Integer getEventCode() {
        return this.f13505b;
    }

    public long getEventTimeMs() {
        return this.f13504a;
    }

    public long getEventUptimeMs() {
        return this.f13506c;
    }

    @Nullable
    public NetworkConnectionInfo getNetworkConnectionInfo() {
        return this.f13510g;
    }

    @Nullable
    public byte[] getSourceExtension() {
        return this.f13507d;
    }

    @Nullable
    public String getSourceExtensionJsonProto3() {
        return this.f13508e;
    }

    public long getTimezoneOffsetSeconds() {
        return this.f13509f;
    }

    public int hashCode() {
        long j10 = this.f13504a;
        int i10 = (((int) (j10 ^ (j10 >>> 32))) ^ 1000003) * 1000003;
        Integer num = this.f13505b;
        int i11 = 0;
        int hashCode = num == null ? 0 : num.hashCode();
        long j11 = this.f13506c;
        int hashCode2 = (((((i10 ^ hashCode) * 1000003) ^ ((int) (j11 ^ (j11 >>> 32)))) * 1000003) ^ Arrays.hashCode(this.f13507d)) * 1000003;
        String str = this.f13508e;
        int hashCode3 = str == null ? 0 : str.hashCode();
        long j12 = this.f13509f;
        int i12 = (((hashCode2 ^ hashCode3) * 1000003) ^ ((int) ((j12 >>> 32) ^ j12))) * 1000003;
        NetworkConnectionInfo networkConnectionInfo = this.f13510g;
        if (networkConnectionInfo != null) {
            i11 = networkConnectionInfo.hashCode();
        }
        return i12 ^ i11;
    }

    public String toString() {
        StringBuilder a10 = d.a.a("LogEvent{eventTimeMs=");
        a10.append(this.f13504a);
        a10.append(", eventCode=");
        a10.append(this.f13505b);
        a10.append(", eventUptimeMs=");
        a10.append(this.f13506c);
        a10.append(", sourceExtension=");
        a10.append(Arrays.toString(this.f13507d));
        a10.append(", sourceExtensionJsonProto3=");
        a10.append(this.f13508e);
        a10.append(", timezoneOffsetSeconds=");
        a10.append(this.f13509f);
        a10.append(", networkConnectionInfo=");
        a10.append(this.f13510g);
        a10.append("}");
        return a10.toString();
    }
}
