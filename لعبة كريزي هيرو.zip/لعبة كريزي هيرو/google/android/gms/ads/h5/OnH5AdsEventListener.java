package com.google.android.gms.ads.h5;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

@RequiresApi(api = 21)
/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public interface OnH5AdsEventListener {
    void onH5AdsEvent(@NonNull String str);
}
