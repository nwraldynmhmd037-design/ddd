package com.google.android.gms.ads;

public final class R {

    public static final class attr {
        public static final int adSize = 2130968613;
        public static final int adSizes = 2130968614;
        public static final int adUnitId = 2130968615;

        private attr() {
        }
    }

    public static final class id {
        public static final int layout = 2131362316;

        private id() {
        }
    }

    public static final class layout {
        public static final int admob_empty_layout = 2131558449;

        private layout() {
        }
    }

    public static final class style {
        public static final int Theme_IAPTheme = 2131952117;

        private style() {
        }
    }

    public static final class styleable {
        public static final int[] AdsAttrs = {com.crazyhero.android.R.attr.adSize, com.crazyhero.android.R.attr.adSizes, com.crazyhero.android.R.attr.adUnitId};
        public static final int AdsAttrs_adSize = 0;
        public static final int AdsAttrs_adSizes = 1;
        public static final int AdsAttrs_adUnitId = 2;

        private styleable() {
        }
    }

    public static final class xml {
        public static final int gma_ad_services_config = 2132082694;

        private xml() {
        }
    }

    private R() {
    }
}
