package com.google.android.gms.ads.admanager;

import androidx.annotation.NonNull;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public interface AppEventListener {
    void onAppEvent(@NonNull String str, @NonNull String str2);
}
