package com.google.android.gms.ads;

import android.os.Bundle;
import android.os.RemoteException;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzdn;
import com.google.android.gms.ads.internal.client.zzu;
import com.google.android.gms.internal.ads.zzcat;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public final class ResponseInfo {
    @Nullable
    private final zzdn zza;
    private final List zzb = new ArrayList();
    @Nullable
    private AdapterResponseInfo zzc;

    private ResponseInfo(@Nullable zzdn zzdn) {
        this.zza = zzdn;
        if (zzdn != null) {
            try {
                List<zzu> zzj = zzdn.zzj();
                if (zzj != null) {
                    for (zzu zza2 : zzj) {
                        AdapterResponseInfo zza3 = AdapterResponseInfo.zza(zza2);
                        if (zza3 != null) {
                            this.zzb.add(zza3);
                        }
                    }
                }
            } catch (RemoteException e10) {
                zzcat.zzh("Could not forward getAdapterResponseInfo to ResponseInfo.", e10);
            }
        }
        zzdn zzdn2 = this.zza;
        if (zzdn2 != null) {
            try {
                zzu zzf = zzdn2.zzf();
                if (zzf != null) {
                    this.zzc = AdapterResponseInfo.zza(zzf);
                }
            } catch (RemoteException e11) {
                zzcat.zzh("Could not forward getLoadedAdapterResponse to ResponseInfo.", e11);
            }
        }
    }

    @Nullable
    public static ResponseInfo zza(@Nullable zzdn zzdn) {
        if (zzdn != null) {
            return new ResponseInfo(zzdn);
        }
        return null;
    }

    @NonNull
    public static ResponseInfo zzb(@Nullable zzdn zzdn) {
        return new ResponseInfo(zzdn);
    }

    @NonNull
    public List<AdapterResponseInfo> getAdapterResponses() {
        return this.zzb;
    }

    @Nullable
    public AdapterResponseInfo getLoadedAdapterResponseInfo() {
        return this.zzc;
    }

    @Nullable
    public String getMediationAdapterClassName() {
        try {
            zzdn zzdn = this.zza;
            if (zzdn != null) {
                return zzdn.zzg();
            }
            return null;
        } catch (RemoteException e10) {
            zzcat.zzh("Could not forward getMediationAdapterClassName to ResponseInfo.", e10);
            return null;
        }
    }

    @NonNull
    public Bundle getResponseExtras() {
        try {
            zzdn zzdn = this.zza;
            if (zzdn != null) {
                return zzdn.zze();
            }
        } catch (RemoteException e10) {
            zzcat.zzh("Could not forward getResponseExtras to ResponseInfo.", e10);
        }
        return new Bundle();
    }

    @Nullable
    public String getResponseId() {
        try {
            zzdn zzdn = this.zza;
            if (zzdn != null) {
                return zzdn.zzi();
            }
            return null;
        } catch (RemoteException e10) {
            zzcat.zzh("Could not forward getResponseId to ResponseInfo.", e10);
            return null;
        }
    }

    @NonNull
    public String toString() {
        try {
            return zzd().toString(2);
        } catch (JSONException unused) {
            return "Error forming toString output.";
        }
    }

    @VisibleForTesting
    @Nullable
    public final zzdn zzc() {
        return this.zza;
    }

    @NonNull
    public final JSONObject zzd() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        String responseId = getResponseId();
        if (responseId == null) {
            jSONObject.put("Response ID", "null");
        } else {
            jSONObject.put("Response ID", responseId);
        }
        String mediationAdapterClassName = getMediationAdapterClassName();
        if (mediationAdapterClassName == null) {
            jSONObject.put("Mediation Adapter Class Name", "null");
        } else {
            jSONObject.put("Mediation Adapter Class Name", mediationAdapterClassName);
        }
        JSONArray jSONArray = new JSONArray();
        for (AdapterResponseInfo zzb2 : this.zzb) {
            jSONArray.put(zzb2.zzb());
        }
        jSONObject.put("Adapter Responses", jSONArray);
        AdapterResponseInfo adapterResponseInfo = this.zzc;
        if (adapterResponseInfo != null) {
            jSONObject.put("Loaded Adapter Response", adapterResponseInfo.zzb());
        }
        Bundle responseExtras = getResponseExtras();
        if (responseExtras != null) {
            jSONObject.put("Response Extras", zzay.zzb().zzh(responseExtras));
        }
        return jSONObject;
    }
}
