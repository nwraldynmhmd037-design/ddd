package com.google.android.gms.ads.internal.overlay;

import com.google.android.gms.internal.ads.zzfrc;
import com.google.android.gms.internal.ads.zzfrd;

/* compiled from: com.google.android.gms:play-services-ads@@22.5.0 */
public final class zzv implements zzfrd {
    public final /* synthetic */ zzw zza;

    public zzv(zzw zzw) {
        this.zza = zzw;
    }

    public final void zza(zzfrc zzfrc) {
        this.zza.zzi(zzfrc);
    }
}
