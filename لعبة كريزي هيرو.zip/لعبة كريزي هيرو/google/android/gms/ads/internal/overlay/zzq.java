package com.google.android.gms.ads.internal.overlay;

/* compiled from: com.google.android.gms:play-services-ads@@22.5.0 */
public final class zzq {
    public int zza = 0;
    public int zzb = 0;
    public int zzc = 0;
    public int zzd = 32;
}
