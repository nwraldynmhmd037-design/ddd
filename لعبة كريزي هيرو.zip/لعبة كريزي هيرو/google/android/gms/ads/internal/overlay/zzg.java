package com.google.android.gms.ads.internal.overlay;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.RelativeLayout;
import androidx.annotation.VisibleForTesting;
import com.google.android.gms.ads.internal.util.zzau;

@VisibleForTesting
/* compiled from: com.google.android.gms:play-services-ads@@22.5.0 */
public final class zzg extends RelativeLayout {
    @VisibleForTesting
    public final zzau zza;
    @VisibleForTesting
    public boolean zzb;

    public zzg(Context context, String str, String str2, String str3) {
        super(context);
        zzau zzau = new zzau(context, str);
        this.zza = zzau;
        zzau.zzo(str2);
        zzau.zzn(str3);
    }

    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (this.zzb) {
            return false;
        }
        this.zza.zzm(motionEvent);
        return false;
    }
}
