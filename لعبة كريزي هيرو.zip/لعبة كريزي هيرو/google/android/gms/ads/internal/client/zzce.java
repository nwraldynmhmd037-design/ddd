package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzbfs;
import com.google.android.gms.internal.ads.zzbfy;
import com.google.android.gms.internal.ads.zzbkh;
import com.google.android.gms.internal.ads.zzbkk;
import com.google.android.gms.internal.ads.zzbox;
import com.google.android.gms.internal.ads.zzbso;
import com.google.android.gms.internal.ads.zzbsv;
import com.google.android.gms.internal.ads.zzbvz;
import com.google.android.gms.internal.ads.zzbwp;
import com.google.android.gms.internal.ads.zzbzk;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public interface zzce extends IInterface {
    zzbq zzb(IObjectWrapper iObjectWrapper, String str, zzbox zzbox, int i10) throws RemoteException;

    zzbu zzc(IObjectWrapper iObjectWrapper, zzq zzq, String str, zzbox zzbox, int i10) throws RemoteException;

    zzbu zzd(IObjectWrapper iObjectWrapper, zzq zzq, String str, zzbox zzbox, int i10) throws RemoteException;

    zzbu zze(IObjectWrapper iObjectWrapper, zzq zzq, String str, zzbox zzbox, int i10) throws RemoteException;

    zzbu zzf(IObjectWrapper iObjectWrapper, zzq zzq, String str, int i10) throws RemoteException;

    zzco zzg(IObjectWrapper iObjectWrapper, int i10) throws RemoteException;

    zzdj zzh(IObjectWrapper iObjectWrapper, zzbox zzbox, int i10) throws RemoteException;

    zzbfs zzi(IObjectWrapper iObjectWrapper, IObjectWrapper iObjectWrapper2) throws RemoteException;

    zzbfy zzj(IObjectWrapper iObjectWrapper, IObjectWrapper iObjectWrapper2, IObjectWrapper iObjectWrapper3) throws RemoteException;

    zzbkk zzk(IObjectWrapper iObjectWrapper, zzbox zzbox, int i10, zzbkh zzbkh) throws RemoteException;

    zzbso zzl(IObjectWrapper iObjectWrapper, zzbox zzbox, int i10) throws RemoteException;

    zzbsv zzm(IObjectWrapper iObjectWrapper) throws RemoteException;

    zzbvz zzn(IObjectWrapper iObjectWrapper, zzbox zzbox, int i10) throws RemoteException;

    zzbwp zzo(IObjectWrapper iObjectWrapper, String str, zzbox zzbox, int i10) throws RemoteException;

    zzbzk zzp(IObjectWrapper iObjectWrapper, zzbox zzbox, int i10) throws RemoteException;
}
