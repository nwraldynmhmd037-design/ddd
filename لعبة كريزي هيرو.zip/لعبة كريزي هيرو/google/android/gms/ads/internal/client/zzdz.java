package com.google.android.gms.ads.internal.client;

import com.google.android.gms.ads.LoadAdError;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public final class zzdz extends zzaz {
    public final /* synthetic */ zzea zza;

    public zzdz(zzea zzea) {
        this.zza = zzea;
    }

    public final void onAdFailedToLoad(LoadAdError loadAdError) {
        zzea zzea = this.zza;
        zzea.zze.zzb(zzea.zzi());
        super.onAdFailedToLoad(loadAdError);
    }

    public final void onAdLoaded() {
        zzea zzea = this.zza;
        zzea.zze.zzb(zzea.zzi());
        super.onAdLoaded();
    }
}
