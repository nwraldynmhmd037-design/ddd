package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;
import androidx.annotation.Nullable;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public interface zzbn extends IInterface {
    @Nullable
    String zze() throws RemoteException;

    @Nullable
    String zzf() throws RemoteException;

    void zzg(zzl zzl) throws RemoteException;

    void zzh(zzl zzl, int i10) throws RemoteException;

    boolean zzi() throws RemoteException;
}
