package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.RemoteException;
import androidx.annotation.Nullable;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbci;
import com.google.android.gms.internal.ads.zzbox;
import com.google.android.gms.internal.ads.zzbty;
import com.google.android.gms.internal.ads.zzcaw;
import com.google.android.gms.internal.ads.zzcax;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public final class zzac extends zzax {
    public final /* synthetic */ Context zza;
    public final /* synthetic */ zzbox zzb;

    public zzac(zzaw zzaw, Context context, zzbox zzbox) {
        this.zza = context;
        this.zzb = zzbox;
    }

    @Nullable
    public final /* bridge */ /* synthetic */ Object zza() {
        zzaw.zzt(this.zza, "out_of_context_tester");
        return null;
    }

    @Nullable
    public final /* bridge */ /* synthetic */ Object zzb(zzce zzce) throws RemoteException {
        Context context = this.zza;
        IObjectWrapper wrap = ObjectWrapper.wrap(context);
        zzbci.zza(context);
        if (((Boolean) zzba.zzc().zzb(zzbci.zzje)).booleanValue()) {
            return zzce.zzh(wrap, this.zzb, 233702000);
        }
        return null;
    }

    @Nullable
    public final /* bridge */ /* synthetic */ Object zzc() throws RemoteException {
        Context context = this.zza;
        IObjectWrapper wrap = ObjectWrapper.wrap(context);
        zzbci.zza(context);
        if (!((Boolean) zzba.zzc().zzb(zzbci.zzje)).booleanValue()) {
            return null;
        }
        try {
            return ((zzdk) zzcax.zzb(this.zza, "com.google.android.gms.ads.DynamiteOutOfContextTesterCreatorImpl", zzab.zza)).zze(wrap, this.zzb, 233702000);
        } catch (RemoteException | zzcaw | NullPointerException e10) {
            zzbty.zza(this.zza).zzf(e10, "ClientApiBroker.getOutOfContextTester");
            return null;
        }
    }
}
