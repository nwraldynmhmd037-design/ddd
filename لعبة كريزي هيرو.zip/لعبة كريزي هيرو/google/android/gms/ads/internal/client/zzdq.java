package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;
import androidx.annotation.Nullable;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public interface zzdq extends IInterface {
    float zze() throws RemoteException;

    float zzf() throws RemoteException;

    float zzg() throws RemoteException;

    int zzh() throws RemoteException;

    @Nullable
    zzdt zzi() throws RemoteException;

    void zzj(boolean z10) throws RemoteException;

    void zzk() throws RemoteException;

    void zzl() throws RemoteException;

    void zzm(@Nullable zzdt zzdt) throws RemoteException;

    void zzn() throws RemoteException;

    boolean zzo() throws RemoteException;

    boolean zzp() throws RemoteException;

    boolean zzq() throws RemoteException;
}
