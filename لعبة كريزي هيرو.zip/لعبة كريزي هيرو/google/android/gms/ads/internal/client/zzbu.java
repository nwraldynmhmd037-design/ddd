package com.google.android.gms.ads.internal.client;

import android.os.Bundle;
import android.os.IInterface;
import android.os.RemoteException;
import androidx.annotation.Nullable;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzaws;
import com.google.android.gms.internal.ads.zzbdg;
import com.google.android.gms.internal.ads.zzbte;
import com.google.android.gms.internal.ads.zzbth;
import com.google.android.gms.internal.ads.zzbwc;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public interface zzbu extends IInterface {
    void zzA() throws RemoteException;

    void zzB() throws RemoteException;

    void zzC(@Nullable zzbe zzbe) throws RemoteException;

    void zzD(@Nullable zzbh zzbh) throws RemoteException;

    void zzE(@Nullable zzby zzby) throws RemoteException;

    void zzF(zzq zzq) throws RemoteException;

    void zzG(@Nullable zzcb zzcb) throws RemoteException;

    void zzH(zzaws zzaws) throws RemoteException;

    void zzI(zzw zzw) throws RemoteException;

    void zzJ(zzci zzci) throws RemoteException;

    void zzK(@Nullable zzdu zzdu) throws RemoteException;

    void zzL(boolean z10) throws RemoteException;

    void zzM(zzbte zzbte) throws RemoteException;

    void zzN(boolean z10) throws RemoteException;

    void zzO(@Nullable zzbdg zzbdg) throws RemoteException;

    void zzP(zzdg zzdg) throws RemoteException;

    void zzQ(zzbth zzbth, String str) throws RemoteException;

    void zzR(String str) throws RemoteException;

    void zzS(@Nullable zzbwc zzbwc) throws RemoteException;

    void zzT(String str) throws RemoteException;

    void zzU(@Nullable zzfl zzfl) throws RemoteException;

    void zzW(IObjectWrapper iObjectWrapper) throws RemoteException;

    void zzX() throws RemoteException;

    boolean zzY() throws RemoteException;

    boolean zzZ() throws RemoteException;

    boolean zzaa(zzl zzl) throws RemoteException;

    void zzab(zzcf zzcf) throws RemoteException;

    Bundle zzd() throws RemoteException;

    zzq zzg() throws RemoteException;

    zzbh zzi() throws RemoteException;

    zzcb zzj() throws RemoteException;

    zzdn zzk() throws RemoteException;

    zzdq zzl() throws RemoteException;

    IObjectWrapper zzn() throws RemoteException;

    String zzr() throws RemoteException;

    String zzs() throws RemoteException;

    String zzt() throws RemoteException;

    void zzx() throws RemoteException;

    void zzy(zzl zzl, zzbk zzbk) throws RemoteException;

    void zzz() throws RemoteException;
}
