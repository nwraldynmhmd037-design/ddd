package com.google.android.gms.ads.internal.client;

import android.app.Activity;
import android.os.RemoteException;
import androidx.annotation.Nullable;
import com.google.android.gms.dynamic.ObjectWrapper;
import com.google.android.gms.internal.ads.zzbci;
import com.google.android.gms.internal.ads.zzbsu;
import com.google.android.gms.internal.ads.zzbsy;
import com.google.android.gms.internal.ads.zzbty;
import com.google.android.gms.internal.ads.zzcaw;
import com.google.android.gms.internal.ads.zzcax;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public final class zzaa extends zzax {
    public final /* synthetic */ Activity zza;
    public final /* synthetic */ zzaw zzb;

    public zzaa(zzaw zzaw, Activity activity) {
        this.zzb = zzaw;
        this.zza = activity;
    }

    @Nullable
    public final /* bridge */ /* synthetic */ Object zza() {
        zzaw.zzt(this.zza, "ad_overlay");
        return null;
    }

    public final /* bridge */ /* synthetic */ Object zzb(zzce zzce) throws RemoteException {
        return zzce.zzm(ObjectWrapper.wrap(this.zza));
    }

    @Nullable
    public final /* bridge */ /* synthetic */ Object zzc() throws RemoteException {
        zzbci.zza(this.zza);
        if (((Boolean) zzba.zzc().zzb(zzbci.zzjQ)).booleanValue()) {
            try {
                return zzbsu.zzI(((zzbsy) zzcax.zzb(this.zza, "com.google.android.gms.ads.ChimeraAdOverlayCreatorImpl", zzz.zza)).zze(ObjectWrapper.wrap(this.zza)));
            } catch (RemoteException | zzcaw | NullPointerException e10) {
                this.zzb.zzh = zzbty.zza(this.zza.getApplicationContext());
                this.zzb.zzh.zzf(e10, "ClientApiBroker.createAdOverlay");
                return null;
            }
        } else {
            zzaw zzaw = this.zzb;
            return zzaw.zzf.zza(this.zza);
        }
    }
}
