package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import androidx.annotation.Nullable;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzbln;
import com.google.android.gms.internal.ads.zzbox;
import com.google.android.gms.internal.ads.zzcam;
import com.google.android.gms.internal.ads.zzcat;
import java.util.Collections;
import java.util.List;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public final class zzey extends zzcn {
    private zzbln zza;

    public final /* synthetic */ void zzb() {
        zzbln zzbln = this.zza;
        if (zzbln != null) {
            try {
                zzbln.zzb(Collections.emptyList());
            } catch (RemoteException e10) {
                zzcat.zzk("Could not notify onComplete event.", e10);
            }
        }
    }

    public final float zze() throws RemoteException {
        return 1.0f;
    }

    public final String zzf() {
        return "";
    }

    public final List zzg() throws RemoteException {
        return Collections.emptyList();
    }

    public final void zzh(@Nullable String str) throws RemoteException {
    }

    public final void zzi() {
    }

    public final void zzj(boolean z10) throws RemoteException {
    }

    public final void zzk() throws RemoteException {
        zzcat.zzg("The initialization is not processed because MobileAdsSettingsManager is not created successfully.");
        zzcam.zza.post(new zzex(this));
    }

    public final void zzl(@Nullable String str, IObjectWrapper iObjectWrapper) throws RemoteException {
    }

    public final void zzm(zzda zzda) {
    }

    public final void zzn(IObjectWrapper iObjectWrapper, String str) throws RemoteException {
    }

    public final void zzo(zzbox zzbox) throws RemoteException {
    }

    public final void zzp(boolean z10) throws RemoteException {
    }

    public final void zzq(float f10) throws RemoteException {
    }

    public final void zzr(String str) throws RemoteException {
    }

    public final void zzs(zzbln zzbln) throws RemoteException {
        this.zza = zzbln;
    }

    public final void zzt(String str) {
    }

    public final void zzu(zzff zzff) throws RemoteException {
    }

    public final boolean zzv() throws RemoteException {
        return false;
    }
}
