package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import androidx.annotation.Nullable;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzbfx;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public final class zzfa extends zzbfx {
    public final void zzb(IObjectWrapper iObjectWrapper) {
    }

    public final void zzc(@Nullable IObjectWrapper iObjectWrapper) throws RemoteException {
    }

    public final void zzd() throws RemoteException {
    }
}
