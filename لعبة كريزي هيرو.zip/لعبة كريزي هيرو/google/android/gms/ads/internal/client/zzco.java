package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;
import androidx.annotation.Nullable;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.ads.zzbln;
import com.google.android.gms.internal.ads.zzbox;
import java.util.List;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public interface zzco extends IInterface {
    float zze() throws RemoteException;

    String zzf() throws RemoteException;

    List zzg() throws RemoteException;

    void zzh(@Nullable String str) throws RemoteException;

    void zzi() throws RemoteException;

    void zzj(boolean z10) throws RemoteException;

    void zzk() throws RemoteException;

    void zzl(@Nullable String str, IObjectWrapper iObjectWrapper) throws RemoteException;

    void zzm(zzda zzda) throws RemoteException;

    void zzn(IObjectWrapper iObjectWrapper, String str) throws RemoteException;

    void zzo(zzbox zzbox) throws RemoteException;

    void zzp(boolean z10) throws RemoteException;

    void zzq(float f10) throws RemoteException;

    void zzr(String str) throws RemoteException;

    void zzs(zzbln zzbln) throws RemoteException;

    void zzt(String str) throws RemoteException;

    void zzu(zzff zzff) throws RemoteException;

    boolean zzv() throws RemoteException;
}
