package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import androidx.annotation.Nullable;
import com.google.android.gms.internal.ads.zzcam;
import com.google.android.gms.internal.ads.zzcat;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public final class zzet extends zzbm {
    public final /* synthetic */ zzeu zza;

    public /* synthetic */ zzet(zzeu zzeu, zzes zzes) {
        this.zza = zzeu;
    }

    @Nullable
    public final String zze() throws RemoteException {
        return null;
    }

    @Nullable
    public final String zzf() throws RemoteException {
        return null;
    }

    public final void zzg(zzl zzl) throws RemoteException {
        zzh(zzl, 1);
    }

    public final void zzh(zzl zzl, int i10) throws RemoteException {
        zzcat.zzg("This app is using a lightweight version of the Google Mobile Ads SDK that requires the latest Google Play services to be installed, but Google Play services is either missing or out of date.");
        zzcam.zza.post(new zzer(this));
    }

    public final boolean zzi() throws RemoteException {
        return false;
    }
}
