package com.google.android.gms.ads.internal.client;

import android.os.RemoteException;
import androidx.annotation.Nullable;
import com.google.android.gms.ads.formats.AdManagerAdViewOptions;
import com.google.android.gms.ads.formats.PublisherAdViewOptions;
import com.google.android.gms.internal.ads.zzbfc;
import com.google.android.gms.internal.ads.zzbgm;
import com.google.android.gms.internal.ads.zzbgp;
import com.google.android.gms.internal.ads.zzbgs;
import com.google.android.gms.internal.ads.zzbgv;
import com.google.android.gms.internal.ads.zzbgz;
import com.google.android.gms.internal.ads.zzbhc;
import com.google.android.gms.internal.ads.zzbls;
import com.google.android.gms.internal.ads.zzbmb;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public final class zzeu extends zzbp {
    /* access modifiers changed from: private */
    public zzbh zza;

    public final zzbn zzc() {
        return new zzet(this, (zzes) null);
    }

    public final zzbn zze() throws RemoteException {
        return new zzet(this, (zzes) null);
    }

    public final void zzf(zzbgm zzbgm) throws RemoteException {
    }

    public final void zzg(zzbgp zzbgp) throws RemoteException {
    }

    public final void zzh(String str, zzbgv zzbgv, @Nullable zzbgs zzbgs) throws RemoteException {
    }

    public final void zzi(zzbmb zzbmb) throws RemoteException {
    }

    public final void zzj(zzbgz zzbgz, zzq zzq) throws RemoteException {
    }

    public final void zzk(zzbhc zzbhc) throws RemoteException {
    }

    public final void zzl(zzbh zzbh) throws RemoteException {
        this.zza = zzbh;
    }

    public final void zzm(AdManagerAdViewOptions adManagerAdViewOptions) throws RemoteException {
    }

    public final void zzn(zzbls zzbls) throws RemoteException {
    }

    public final void zzo(zzbfc zzbfc) throws RemoteException {
    }

    public final void zzp(PublisherAdViewOptions publisherAdViewOptions) throws RemoteException {
    }

    public final void zzq(zzcf zzcf) throws RemoteException {
    }
}
