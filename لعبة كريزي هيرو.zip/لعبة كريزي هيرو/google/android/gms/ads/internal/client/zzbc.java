package com.google.android.gms.ads.internal.client;

import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzaum;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public final class zzbc extends zzaum implements zzbe {
    public zzbc(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.client.IAdClickListener");
    }

    public final void zzb() throws RemoteException {
        zzbh(1, zza());
    }
}
