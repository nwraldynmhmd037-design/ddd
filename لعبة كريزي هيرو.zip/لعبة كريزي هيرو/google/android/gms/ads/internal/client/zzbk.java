package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public interface zzbk extends IInterface {
    void zzb(zze zze) throws RemoteException;

    void zzc() throws RemoteException;
}
