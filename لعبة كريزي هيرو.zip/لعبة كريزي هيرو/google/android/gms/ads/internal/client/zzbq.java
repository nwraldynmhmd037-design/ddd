package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;
import androidx.annotation.Nullable;
import com.google.android.gms.ads.formats.AdManagerAdViewOptions;
import com.google.android.gms.ads.formats.PublisherAdViewOptions;
import com.google.android.gms.internal.ads.zzbfc;
import com.google.android.gms.internal.ads.zzbgm;
import com.google.android.gms.internal.ads.zzbgp;
import com.google.android.gms.internal.ads.zzbgs;
import com.google.android.gms.internal.ads.zzbgv;
import com.google.android.gms.internal.ads.zzbgz;
import com.google.android.gms.internal.ads.zzbhc;
import com.google.android.gms.internal.ads.zzbls;
import com.google.android.gms.internal.ads.zzbmb;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public interface zzbq extends IInterface {
    zzbn zze() throws RemoteException;

    void zzf(zzbgm zzbgm) throws RemoteException;

    void zzg(zzbgp zzbgp) throws RemoteException;

    void zzh(String str, zzbgv zzbgv, @Nullable zzbgs zzbgs) throws RemoteException;

    void zzi(zzbmb zzbmb) throws RemoteException;

    void zzj(zzbgz zzbgz, zzq zzq) throws RemoteException;

    void zzk(zzbhc zzbhc) throws RemoteException;

    void zzl(zzbh zzbh) throws RemoteException;

    void zzm(AdManagerAdViewOptions adManagerAdViewOptions) throws RemoteException;

    void zzn(zzbls zzbls) throws RemoteException;

    void zzo(zzbfc zzbfc) throws RemoteException;

    void zzp(PublisherAdViewOptions publisherAdViewOptions) throws RemoteException;

    void zzq(zzcf zzcf) throws RemoteException;
}
