package com.google.android.gms.ads.internal.client;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.internal.ads.zzbox;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public interface zzcl extends IInterface {
    zzbox getAdapterCreator() throws RemoteException;

    zzen getLiteSdkVersion() throws RemoteException;
}
