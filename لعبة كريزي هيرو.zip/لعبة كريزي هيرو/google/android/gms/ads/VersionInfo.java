package com.google.android.gms.ads;

import androidx.annotation.NonNull;
import java.util.Locale;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public class VersionInfo {
    public final int zza;
    public final int zzb;
    public final int zzc;

    public VersionInfo(int i10, int i11, int i12) {
        this.zza = i10;
        this.zzb = i11;
        this.zzc = i12;
    }

    public int getMajorVersion() {
        return this.zza;
    }

    public int getMicroVersion() {
        return this.zzc;
    }

    public int getMinorVersion() {
        return this.zzb;
    }

    @NonNull
    public String toString() {
        return String.format(Locale.US, "%d.%d.%d", new Object[]{Integer.valueOf(this.zza), Integer.valueOf(this.zzb), Integer.valueOf(this.zzc)});
    }
}
