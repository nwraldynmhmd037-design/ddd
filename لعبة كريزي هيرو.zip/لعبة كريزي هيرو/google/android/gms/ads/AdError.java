package com.google.android.gms.ads;

import android.os.IBinder;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.gms.ads.internal.client.zze;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public class AdError {
    @NonNull
    public static final String UNDEFINED_DOMAIN = "undefined";
    private final int zza;
    @NonNull
    private final String zzb;
    @NonNull
    private final String zzc;
    @Nullable
    private final AdError zzd;

    public AdError(int i10, @NonNull String str, @NonNull String str2) {
        this(i10, str, str2, (AdError) null);
    }

    public AdError(int i10, @NonNull String str, @NonNull String str2, @Nullable AdError adError) {
        this.zza = i10;
        this.zzb = str;
        this.zzc = str2;
        this.zzd = adError;
    }

    @Nullable
    public AdError getCause() {
        return this.zzd;
    }

    public int getCode() {
        return this.zza;
    }

    @NonNull
    public String getDomain() {
        return this.zzc;
    }

    @NonNull
    public String getMessage() {
        return this.zzb;
    }

    @NonNull
    public String toString() {
        try {
            return zzb().toString(2);
        } catch (JSONException unused) {
            return "Error forming toString output.";
        }
    }

    @NonNull
    public final zze zza() {
        zze zze;
        AdError adError = this.zzd;
        if (adError == null) {
            zze = null;
        } else {
            String str = adError.zzc;
            zze = new zze(adError.zza, adError.zzb, str, (zze) null, (IBinder) null);
        }
        return new zze(this.zza, this.zzb, this.zzc, zze, (IBinder) null);
    }

    @NonNull
    public JSONObject zzb() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("Code", this.zza);
        jSONObject.put("Message", this.zzb);
        jSONObject.put("Domain", this.zzc);
        AdError adError = this.zzd;
        if (adError == null) {
            jSONObject.put("Cause", "null");
        } else {
            jSONObject.put("Cause", adError.zzb());
        }
        return jSONObject;
    }
}
