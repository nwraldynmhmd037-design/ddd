package com.google.android.gms.ads.impl;

public final class R {

    public static final class drawable {
        public static final int admob_close_button_black_circle_white_cross = 2131230817;
        public static final int admob_close_button_white_circle_black_cross = 2131230818;

        private drawable() {
        }
    }

    public static final class string {
        public static final int native_body = 2131886386;
        public static final int native_headline = 2131886387;
        public static final int native_media_view = 2131886388;
        public static final int notifications_permission_confirm = 2131886390;
        public static final int notifications_permission_decline = 2131886391;
        public static final int notifications_permission_title = 2131886392;
        public static final int offline_notification_text = 2131886393;
        public static final int offline_notification_title = 2131886394;
        public static final int offline_opt_in_confirm = 2131886395;
        public static final int offline_opt_in_confirmation = 2131886396;
        public static final int offline_opt_in_decline = 2131886397;
        public static final int offline_opt_in_message = 2131886398;
        public static final int offline_opt_in_title = 2131886399;

        /* renamed from: s1  reason: collision with root package name */
        public static final int f13622s1 = 2131886447;

        /* renamed from: s2  reason: collision with root package name */
        public static final int f13623s2 = 2131886448;

        /* renamed from: s3  reason: collision with root package name */
        public static final int f13624s3 = 2131886449;

        /* renamed from: s4  reason: collision with root package name */
        public static final int f13625s4 = 2131886450;

        /* renamed from: s5  reason: collision with root package name */
        public static final int f13626s5 = 2131886451;

        /* renamed from: s6  reason: collision with root package name */
        public static final int f13627s6 = 2131886452;

        /* renamed from: s7  reason: collision with root package name */
        public static final int f13628s7 = 2131886453;
        public static final int watermark_label_prefix = 2131886641;

        private string() {
        }
    }

    private R() {
    }
}
