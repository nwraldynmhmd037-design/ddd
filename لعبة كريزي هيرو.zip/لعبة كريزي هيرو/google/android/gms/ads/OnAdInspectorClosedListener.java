package com.google.android.gms.ads;

import androidx.annotation.Nullable;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public interface OnAdInspectorClosedListener {
    void onAdInspectorClosed(@Nullable AdInspectorError adInspectorError);
}
