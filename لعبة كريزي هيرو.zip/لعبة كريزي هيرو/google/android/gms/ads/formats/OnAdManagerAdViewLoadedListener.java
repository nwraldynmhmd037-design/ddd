package com.google.android.gms.ads.formats;

import androidx.annotation.NonNull;
import com.google.android.gms.ads.admanager.AdManagerAdView;

/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public interface OnAdManagerAdViewLoadedListener {
    void onAdManagerAdViewLoaded(@NonNull AdManagerAdView adManagerAdView);
}
