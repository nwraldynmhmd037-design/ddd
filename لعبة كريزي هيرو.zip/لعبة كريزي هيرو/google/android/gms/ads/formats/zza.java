package com.google.android.gms.ads.formats;

import android.content.Context;
import android.widget.RelativeLayout;

@Deprecated
/* compiled from: com.google.android.gms:play-services-ads-lite@@22.5.0 */
public final class zza extends RelativeLayout {
    public zza(Context context) {
        super(context);
    }
}
