package com.com.bytedance.overseas.sdk.b;

import android.text.TextUtils;
import com.bytedance.sdk.openadsdk.core.c;
import com.bytedance.sdk.openadsdk.core.n;

/* compiled from: AdvertisingIdHelper */
public class a {

    /* renamed from: b  reason: collision with root package name */
    private static volatile a f9021b;

    /* renamed from: a  reason: collision with root package name */
    private String f9022a = "";

    private a() {
    }

    public static a a() {
        if (f9021b == null) {
            synchronized (a.class) {
                if (f9021b == null) {
                    f9021b = new a();
                }
            }
        }
        return f9021b;
    }

    public String b() {
        if (!n.d().z(com.ironsource.environment.globaldata.a.f21988v0)) {
            return "";
        }
        if (!TextUtils.isEmpty(this.f9022a)) {
            return this.f9022a;
        }
        String b10 = c.a(n.a()).b(com.ironsource.environment.globaldata.a.f21988v0, "");
        this.f9022a = b10;
        return b10;
    }

    public void b(String str) {
        this.f9022a = str;
    }

    public static void a(String str) {
        if (!TextUtils.isEmpty(str)) {
            c.a(n.a()).a(com.ironsource.environment.globaldata.a.f21988v0, str);
        }
    }
}
