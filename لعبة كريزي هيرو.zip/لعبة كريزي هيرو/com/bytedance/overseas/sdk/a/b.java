package com.com.bytedance.overseas.sdk.a;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.text.TextUtils;
import com.bytedance.sdk.component.utils.l;
import com.bytedance.sdk.openadsdk.core.model.c;
import com.bytedance.sdk.openadsdk.core.model.p;
import com.bytedance.sdk.openadsdk.core.n;
import com.bytedance.sdk.openadsdk.core.z;
import com.bytedance.sdk.openadsdk.o.ab;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import l.a;

/* compiled from: GPDownLoader */
public class b implements c {

    /* renamed from: e  reason: collision with root package name */
    public static Boolean f9013e;

    /* renamed from: a  reason: collision with root package name */
    public c f9014a;

    /* renamed from: b  reason: collision with root package name */
    public p f9015b;

    /* renamed from: c  reason: collision with root package name */
    public String f9016c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f9017d = false;

    /* renamed from: f  reason: collision with root package name */
    public final AtomicBoolean f9018f = new AtomicBoolean(false);

    /* renamed from: g  reason: collision with root package name */
    private WeakReference<Context> f9019g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f9020h = false;

    public b(Context context, p pVar, String str) {
        this.f9019g = new WeakReference<>(context);
        this.f9015b = pVar;
        this.f9014a = pVar.ag();
        this.f9016c = str;
        l.b("GPDownLoader", str, a.a("====tag===", str));
        if (n.a() == null) {
            n.a(context);
        }
    }

    public void a(boolean z10) {
        this.f9020h = z10;
    }

    public boolean b() {
        if (this.f9015b.ah() == null) {
            return false;
        }
        String a10 = this.f9015b.ah().a();
        if (!TextUtils.isEmpty(a10)) {
            Uri parse = Uri.parse(a10);
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(parse);
            if (ab.a(c(), intent)) {
                if (!(c() instanceof Activity)) {
                    intent.addFlags(268435456);
                }
                try {
                    HashMap hashMap = new HashMap();
                    a((Map<String, Object>) hashMap);
                    com.bytedance.sdk.openadsdk.c.c.e(n.a(), this.f9015b, this.f9016c, "open_url_app", hashMap);
                    c().startActivity(intent);
                    com.bytedance.sdk.openadsdk.c.l.a().a(this.f9015b, this.f9016c);
                    return true;
                } catch (Throwable th2) {
                    th2.printStackTrace();
                }
            }
        }
        if (this.f9017d && !this.f9018f.get()) {
            return false;
        }
        this.f9017d = true;
        HashMap hashMap2 = new HashMap();
        a((Map<String, Object>) hashMap2);
        com.bytedance.sdk.openadsdk.c.c.e(c(), this.f9015b, this.f9016c, "open_fallback_url", hashMap2);
        return false;
    }

    public Context c() {
        WeakReference<Context> weakReference = this.f9019g;
        return (weakReference == null || weakReference.get() == null) ? n.a() : (Context) this.f9019g.get();
    }

    public void d() {
        if (c() != null) {
            if (b()) {
                this.f9018f.set(true);
                this.f9015b.c(true);
            } else if (a()) {
                this.f9015b.c(true);
            } else if (e()) {
                this.f9015b.c(true);
            } else if (this.f9015b.ag() == null && this.f9015b.V() != null) {
                z.a(c(), this.f9015b.V(), this.f9015b, ab.a(this.f9016c), this.f9016c, true);
                this.f9015b.c(true);
            }
        }
    }

    public boolean e() {
        this.f9018f.set(true);
        if (this.f9014a == null || !a(c(), this.f9014a.a(), this.f9014a.c())) {
            return false;
        }
        return true;
    }

    public boolean a(Context context, String str, String str2) {
        return a(context, str, str2, this.f9016c, this.f9015b);
    }

    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:38:0x0117 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean a(android.content.Context r16, java.lang.String r17, java.lang.String r18, java.lang.String r19, com.bytedance.sdk.openadsdk.core.model.p r20) {
        /*
            r0 = r16
            r1 = r17
            r2 = r18
            r3 = r19
            r4 = r20
            java.lang.String r5 = "com.android.vending"
            java.util.HashMap r6 = new java.util.HashMap
            r6.<init>()
            java.lang.Boolean r7 = f9013e
            java.lang.String r8 = "app"
            java.lang.String r9 = "webview"
            if (r7 == 0) goto L_0x0021
            boolean r7 = r7.booleanValue()
            if (r7 == 0) goto L_0x0021
            r7 = r8
            goto L_0x0022
        L_0x0021:
            r7 = r9
        L_0x0022:
            java.lang.String r10 = "storeOpenType"
            r6.put(r10, r7)
            boolean r7 = android.text.TextUtils.isEmpty(r19)
            if (r7 != 0) goto L_0x003b
            java.lang.String r7 = "_landingpage"
            boolean r11 = r3.contains(r7)
            if (r11 == 0) goto L_0x003b
            java.lang.String r11 = ""
            java.lang.String r3 = r3.replace(r7, r11)
        L_0x003b:
            boolean r7 = android.text.TextUtils.isEmpty(r17)
            java.lang.String r11 = "store_open"
            r12 = 268435456(0x10000000, float:2.5243549E-29)
            java.lang.String r15 = "GPDownLoader"
            java.lang.String r14 = "android.intent.action.VIEW"
            if (r7 != 0) goto L_0x008e
            java.lang.String r7 = "play.google.com/store/apps/details?id="
            boolean r7 = r1.contains(r7)
            if (r7 == 0) goto L_0x008e
            android.content.Intent r7 = new android.content.Intent     // Catch:{ all -> 0x008d }
            android.net.Uri r13 = android.net.Uri.parse(r17)     // Catch:{ all -> 0x008d }
            r7.<init>(r14, r13)     // Catch:{ all -> 0x008d }
            r7.setFlags(r12)     // Catch:{ all -> 0x008d }
            r0.startActivity(r7)     // Catch:{ all -> 0x008d }
            java.lang.String r7 = "Goto Google Play"
            com.bytedance.sdk.component.utils.l.c((java.lang.String) r15, (java.lang.String) r7)     // Catch:{ all -> 0x008d }
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ all -> 0x008d }
            r7.<init>()     // Catch:{ all -> 0x008d }
            java.lang.String r13 = "download_url is : ->"
            r7.append(r13)     // Catch:{ all -> 0x008d }
            r7.append(r1)     // Catch:{ all -> 0x008d }
            java.lang.String r1 = r7.toString()     // Catch:{ all -> 0x008d }
            com.bytedance.sdk.component.utils.l.c((java.lang.String) r15, (java.lang.String) r1)     // Catch:{ all -> 0x008d }
            com.bytedance.sdk.openadsdk.c.c.b((android.content.Context) r0, (com.bytedance.sdk.openadsdk.core.model.p) r4, (java.lang.String) r3, (java.lang.String) r11, (java.util.Map<java.lang.String, java.lang.Object>) r6)     // Catch:{ all -> 0x008d }
            r1 = 2
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch:{ all -> 0x008d }
            r7 = 0
            r1[r7] = r3     // Catch:{ all -> 0x008d }
            java.lang.String r7 = r6.toString()     // Catch:{ all -> 0x008d }
            r13 = 1
            r1[r13] = r7     // Catch:{ all -> 0x008d }
            com.bytedance.sdk.component.utils.l.b((java.lang.String) r15, (java.lang.Object[]) r1)     // Catch:{ all -> 0x008d }
            return r13
        L_0x008d:
        L_0x008e:
            if (r0 == 0) goto L_0x0141
            if (r2 == 0) goto L_0x0141
            boolean r1 = android.text.TextUtils.isEmpty(r18)
            if (r1 == 0) goto L_0x009a
            goto L_0x0141
        L_0x009a:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r7 = "gotoGooglePlay :market://details?id="
            r1.append(r7)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            com.bytedance.sdk.component.utils.l.c((java.lang.String) r15, (java.lang.String) r1)
            android.content.Intent r1 = new android.content.Intent     // Catch:{ all -> 0x0117 }
            r1.<init>(r14)     // Catch:{ all -> 0x0117 }
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ all -> 0x0117 }
            r7.<init>()     // Catch:{ all -> 0x0117 }
            java.lang.String r13 = "market://details?id="
            r7.append(r13)     // Catch:{ all -> 0x0117 }
            r7.append(r2)     // Catch:{ all -> 0x0117 }
            java.lang.String r7 = r7.toString()     // Catch:{ all -> 0x0117 }
            android.net.Uri r7 = android.net.Uri.parse(r7)     // Catch:{ all -> 0x0117 }
            r1.setData(r7)     // Catch:{ all -> 0x0117 }
            android.content.pm.PackageManager r13 = r16.getPackageManager()     // Catch:{ all -> 0x0117 }
            r15 = 65536(0x10000, float:9.18355E-41)
            java.util.List r1 = r13.queryIntentActivities(r1, r15)     // Catch:{ all -> 0x0117 }
            java.util.Iterator r1 = r1.iterator()     // Catch:{ all -> 0x0117 }
        L_0x00d9:
            boolean r13 = r1.hasNext()     // Catch:{ all -> 0x0117 }
            if (r13 == 0) goto L_0x0117
            java.lang.Object r13 = r1.next()     // Catch:{ all -> 0x0117 }
            android.content.pm.ResolveInfo r13 = (android.content.pm.ResolveInfo) r13     // Catch:{ all -> 0x0117 }
            android.content.pm.ActivityInfo r13 = r13.activityInfo     // Catch:{ all -> 0x0117 }
            java.lang.String r13 = r13.packageName     // Catch:{ all -> 0x0117 }
            boolean r13 = r13.equals(r5)     // Catch:{ all -> 0x0117 }
            if (r13 == 0) goto L_0x00d9
            android.content.pm.PackageManager r13 = r16.getPackageManager()     // Catch:{ all -> 0x0117 }
            android.content.Intent r13 = r13.getLaunchIntentForPackage(r5)     // Catch:{ all -> 0x0117 }
            if (r13 != 0) goto L_0x00fa
            goto L_0x00d9
        L_0x00fa:
            android.content.Intent r1 = new android.content.Intent     // Catch:{ all -> 0x0117 }
            r1.<init>(r14)     // Catch:{ all -> 0x0117 }
            r1.setData(r7)     // Catch:{ all -> 0x0117 }
            r1.setPackage(r5)     // Catch:{ all -> 0x0117 }
            boolean r5 = r0 instanceof android.app.Activity     // Catch:{ all -> 0x0117 }
            if (r5 != 0) goto L_0x010c
            r1.setFlags(r12)     // Catch:{ all -> 0x0117 }
        L_0x010c:
            r0.startActivity(r1)     // Catch:{ all -> 0x0117 }
            r6.put(r10, r8)     // Catch:{ all -> 0x0117 }
            com.bytedance.sdk.openadsdk.c.c.b((android.content.Context) r0, (com.bytedance.sdk.openadsdk.core.model.p) r4, (java.lang.String) r3, (java.lang.String) r11, (java.util.Map<java.lang.String, java.lang.Object>) r6)     // Catch:{ all -> 0x0117 }
            r0 = 1
            return r0
        L_0x0117:
            android.content.Intent r1 = new android.content.Intent     // Catch:{ all -> 0x013f }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ all -> 0x013f }
            r5.<init>()     // Catch:{ all -> 0x013f }
            java.lang.String r7 = "https://play.google.com/store/apps/details?id="
            r5.append(r7)     // Catch:{ all -> 0x013f }
            r5.append(r2)     // Catch:{ all -> 0x013f }
            java.lang.String r2 = r5.toString()     // Catch:{ all -> 0x013f }
            android.net.Uri r2 = android.net.Uri.parse(r2)     // Catch:{ all -> 0x013f }
            r1.<init>(r14, r2)     // Catch:{ all -> 0x013f }
            r1.setFlags(r12)     // Catch:{ all -> 0x013f }
            r0.startActivity(r1)     // Catch:{ all -> 0x013f }
            r6.put(r10, r9)     // Catch:{ all -> 0x013f }
            com.bytedance.sdk.openadsdk.c.c.b((android.content.Context) r0, (com.bytedance.sdk.openadsdk.core.model.p) r4, (java.lang.String) r3, (java.lang.String) r11, (java.util.Map<java.lang.String, java.lang.Object>) r6)     // Catch:{ all -> 0x013f }
            r0 = 1
            return r0
        L_0x013f:
            r0 = 0
            return r0
        L_0x0141:
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.com.bytedance.overseas.sdk.a.b.a(android.content.Context, java.lang.String, java.lang.String, java.lang.String, com.bytedance.sdk.openadsdk.core.model.p):boolean");
    }

    public static void a(Context context) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("market://details"));
        try {
            for (ResolveInfo resolveInfo : context.getPackageManager().queryIntentActivities(intent, 65536)) {
                if (resolveInfo.activityInfo.packageName.equals("com.android.vending")) {
                    f9013e = Boolean.TRUE;
                    return;
                }
            }
        } catch (Throwable unused) {
            f9013e = Boolean.FALSE;
        }
        f9013e = Boolean.FALSE;
    }

    private void a(Map<String, Object> map) {
        p pVar = this.f9015b;
        if (pVar != null && !pVar.aC()) {
            p pVar2 = this.f9015b;
            map.put("auto_click", Boolean.valueOf(pVar2 != null && !pVar2.a()));
        }
    }

    public boolean a() {
        Intent a10;
        if (this.f9014a == null) {
            return false;
        }
        p pVar = this.f9015b;
        if (pVar != null && pVar.ay() == 0) {
            return false;
        }
        String c10 = this.f9014a.c();
        if (TextUtils.isEmpty(c10) || !ab.b(c(), c10) || (a10 = ab.a(c(), c10)) == null) {
            return false;
        }
        a10.putExtra("START_ONLY_FOR_ANDROID", true);
        try {
            c().startActivity(a10);
            HashMap hashMap = new HashMap();
            a((Map<String, Object>) hashMap);
            com.bytedance.sdk.openadsdk.c.c.e(c(), this.f9015b, this.f9016c, "click_open", hashMap);
            return true;
        } catch (Throwable th2) {
            th2.printStackTrace();
            return false;
        }
    }
}
