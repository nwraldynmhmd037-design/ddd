package com.com.bytedance.overseas.sdk.a;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import com.bytedance.sdk.openadsdk.c.l;
import com.bytedance.sdk.openadsdk.core.model.c;
import com.bytedance.sdk.openadsdk.core.model.p;
import com.bytedance.sdk.openadsdk.core.n;
import com.bytedance.sdk.openadsdk.o.ab;
import java.util.HashMap;
import java.util.Map;

/* compiled from: AndroidRGPDownLoader */
public class a extends b {
    public a(Context context, p pVar, String str) {
        super(context, pVar, str);
    }

    public boolean a() {
        c cVar = this.f9014a;
        if (cVar == null) {
            return false;
        }
        return a(this.f9015b, cVar.c(), c(), this.f9016c);
    }

    public boolean b() {
        if (this.f9015b.ah() == null) {
            return false;
        }
        if (a(this.f9015b.ah().a(), c(), this.f9016c, this.f9015b)) {
            return true;
        }
        if (this.f9017d && !this.f9018f.get()) {
            return false;
        }
        this.f9017d = true;
        HashMap hashMap = new HashMap();
        a(this.f9015b, hashMap);
        com.bytedance.sdk.openadsdk.c.c.e(c(), this.f9015b, this.f9016c, "open_fallback_url", hashMap);
        return false;
    }

    public static boolean a(p pVar, String str, Context context, String str2) {
        Intent a10;
        if (pVar != null && pVar.ay() == 0) {
            return false;
        }
        try {
            if (TextUtils.isEmpty(str) || (a10 = ab.a(context, str)) == null) {
                return false;
            }
            a10.putExtra("START_ONLY_FOR_ANDROID", true);
            if (!(context instanceof Activity)) {
                a10.addFlags(268435456);
            }
            context.startActivity(a10);
            HashMap hashMap = new HashMap();
            a(pVar, hashMap);
            com.bytedance.sdk.openadsdk.c.c.e(context, pVar, str2, "click_open", hashMap);
            return true;
        } catch (Throwable unused) {
        }
        return false;
    }

    private static void a(p pVar, Map<String, Object> map) {
        if (pVar != null && !pVar.aC()) {
            map.put("auto_click", Boolean.valueOf(!pVar.a()));
        }
    }

    public static boolean a(String str, Context context, String str2, p pVar) {
        try {
            if (TextUtils.isEmpty(str)) {
                return false;
            }
            Uri parse = Uri.parse(str);
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(parse);
            if (!(context instanceof Activity)) {
                intent.addFlags(268435456);
            }
            HashMap hashMap = new HashMap();
            a(pVar, hashMap);
            com.bytedance.sdk.openadsdk.c.c.e(n.a(), pVar, str2, "open_url_app", hashMap);
            context.startActivity(intent);
            l.a().a(pVar, str2);
            return true;
        } catch (Throwable unused) {
            return false;
        }
    }
}
