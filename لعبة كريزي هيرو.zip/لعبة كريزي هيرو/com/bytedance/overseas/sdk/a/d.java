package com.com.bytedance.overseas.sdk.a;

import android.content.Context;
import com.bytedance.sdk.openadsdk.core.model.p;
import com.bytedance.sdk.openadsdk.o.ab;

/* compiled from: TTDownloadFactory */
public class d {
    public static c a(Context context, p pVar, String str) {
        if (ab.i(context)) {
            return new b(context, pVar, str);
        }
        return new a(context, pVar, str);
    }
}
