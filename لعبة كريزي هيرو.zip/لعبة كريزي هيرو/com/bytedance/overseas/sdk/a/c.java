package com.com.bytedance.overseas.sdk.a;

/* compiled from: ITTDownloadAdapter */
public interface c {
    void a(boolean z10);

    boolean a();

    void d();

    boolean e();
}
