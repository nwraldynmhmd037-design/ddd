package com.android.walnut;

public class DopraKit {
    static {
        System.loadLibrary("dopra");
    }

    public static native int checkva();
}
